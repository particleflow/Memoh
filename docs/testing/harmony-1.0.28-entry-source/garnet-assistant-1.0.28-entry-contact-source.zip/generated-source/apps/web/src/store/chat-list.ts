import { routerKey } from 'vue-router'
import { CHAT_ROUTE_NAMES } from '@/constants/chat-routes'
import { defineStore, storeToRefs } from 'pinia'
import { computed, hasInjectionContext, inject, onScopeDispose, ref } from 'vue'
import { toast } from '@felinic/ui'
import { useChatSelectionStore } from '@/store/chat-selection'
import { useWorkdirsStore } from '@/store/workdirs'
import { onAuthSessionCleared } from '@/lib/auth-session'
import { resolveApiErrorMessage } from '@/utils/api-error'
import { createInvocationId } from './chat-list.normalize'
import { createFsChangeBeacon } from './chat/fs-beacon'
import { createCommandEventRegistry } from './chat/command-events'
import { createSessionList } from './chat/session-list'
import { createExternalAgentController } from './chat/external-agent-controller'
import { createChatRefreshCoordinator } from './chat/refresh-coordinator'
import { createChatSend } from './chat/send'
import { createStartupSendFailures } from './chat/send-startup'
import { createChatCommands } from './chat/commands'
import { createChatBootstrap } from './chat/bootstrap'
import { createChatRuntimeLayer } from './chat/runtime-layer'
import { createChatViews } from './chat/views'
import { createChatTargets } from './chat/targets'
import { createChatBots } from './chat/bots'
import { createSessionActivity } from './chat/session-activity'
import { createWorkdirSessions } from './chat/workdir-sessions'
import { createSessionActions } from './chat/session-actions'
import {
  commandErrorMessage,
  forkFailedMessage,
  sendFailedMessage,
  userInputConnectionLostMessage, workdirMismatchMessage, sendOutcomeUnknownMessage,
} from './chat/messages'
import { createBackgroundTaskTracker } from './chat/background-tasks'
import { fetchSessions } from '@/composables/api/useChat'
import { bindBotIdInitializeWatch, createInitializeRecovery, createSessionListSnapshot } from './chat/session-list-init-recovery'

import type {
  ChatAssistantTurn,
  ChatMessage,
  ChatUserTurn,
} from './chat/types'

export type {
  ExternalAgentSessionInput, ActiveChatTarget, AttachmentBlock, AttachmentItem,
  BackgroundTask, ChatAssistantTurn, ChatMessage, ChatSystemTurn, ChatUserTurn,
  ChatWorkspaceTargetSnapshot, ContentBlock, ErrorBlock, SendMessageOptions,
  SendMessageResult, SendMessageStage, TextBlock, ThinkingBlock, ToolCallBlock,
} from './chat/types'
export type { FsChangeBatch, FsChangeEvent, FsToolKind } from './chat/fs-beacon'
export type { ChatViewEntry, ChatViewTarget } from './chat/view-registry'

export const useChatStore = defineStore('chat', () => {
  const router = hasInjectionContext() ? inject(routerKey, null) : null
  const selectionStore = useChatSelectionStore()
  const workdirsStore = useWorkdirsStore()
  const { currentBotId, sessionId, draftIntent, explicitSelection: explicitSessionSelection } = storeToRefs(selectionStore)
  const fsBeacon = createFsChangeBeacon({ currentBotId, sessionId })
  const {
    fsChangedAt,
    markFsChanged,
    affectsPath,
    fsEventForPath,
    bumpFsChangedAtIfFsMutation,
    resetFsBeacon,
    clearFsForBotSwitch,
  } = fsBeacon
  const backgroundTasks = createBackgroundTaskTracker()
  const {
    rememberBackgroundTask,
    applyPendingBackgroundEventsToTool,
    backgroundTaskFor,
  } = backgroundTasks
  const views = createChatViews({
    currentBotId,
    sessionId,
    rememberBackgroundTask,
    applyPendingBackgroundEventsToTool,
    bumpFsChangedAtIfFsMutation,
  })
  const {
    focusedViewId: focusedChatViewId,
    draftPromoted,
    projectionVersion: runtimeProjectionVersion,
    chatViews, assistantStreams, firstSend, draftSessionCreations,
    draftCreationKey: draftSessionCreationKey,
    isCreatingDraft: isChatViewCreatingSession,
    normalizeTarget: normalizedChatViewTarget,
    isFocusedTarget: isFocusedChatTarget,
    chatView, transcriptForTarget, sessionTranscript, transcriptForTurn,
    messages, loadingMessages, loadingOlder, hasMoreOlder, hasLoadedOlder,
    clearHistoryView, prepareForInitialization, markHistoryEmpty,
    refreshCurrentSession, resyncRuntimeTranscript, loadInitialMessages, fetchSessionWindow,
    loadOlderMessages, findMessageIdByExternalId, locateMessageByExternalId,
    isSessionStreaming, streamingSessionId, streamingSessionIds, streaming, isChatViewStreaming,
    workspaceTargetSelectionFor, setWorkspaceTargetSelection,
    initializeWorkspaceTargetSelection, resetWorkspaceTargetSelection,
    releaseHiddenSessionView, bindChatView, setChatViewVisible, unbindChatView,
    focusChatView, promoteDraftChatView,
    configure: configureChatViews,
    reset: resetTranscriptUserScope,
  } = views
  const reattachTurnToSession = (botId: string, targetSessionId: string, turn: ChatMessage) => sessionTranscript(botId, targetSessionId).reattachTurnToSession(botId, targetSessionId, turn)
  const removeTurnFromSession = (botId: string, targetSessionId: string, turn: ChatMessage) => {
    const transcript = targetSessionId.trim()
      ? sessionTranscript(botId, targetSessionId)
      : transcriptForTurn(turn)
    transcript?.removeTurnFromSession(botId, targetSessionId, turn)
  }
  const restoreTailFromOptimistic = (botId: string, targetSessionId: string, optimisticUserTurn: ChatUserTurn | null, assistantTurn: ChatAssistantTurn, replacedTurns: ChatMessage[]) => sessionTranscript(botId, targetSessionId).restoreTailFromOptimistic(botId, targetSessionId, optimisticUserTurn, assistantTurn, replacedTurns)
  const hasVisibleAssistantBlocks = (turn: ChatAssistantTurn) => transcriptForTurn(turn)?.hasVisibleAssistantBlocks(turn) ?? false
  const finalizeStreamFailure = (assistantTurn: ChatAssistantTurn, botId: string, targetSessionId: string, error: Error, keepTurn = false) => {
    transcriptForTurn(assistantTurn)?.finalizeStreamFailure(assistantTurn, botId, targetSessionId, error, keepTurn)
  }
  const {
    trackAssistantStream, discardAssistantStream,
    createdSessionIdForInvocation, forgetCreatedSession, clearStreamHistory,
  } = assistantStreams

  let userScopeGeneration = 0
  let selectSessionRequestId = 0
  const sessionList = createSessionList({ currentBotId, sessionId, messages })
  const {
    sessions, sessionsCursor, hasMoreSessions, loadingMoreSessions,
    activeSession, knownSessions, activeChatReadOnly, activeChatCanFork,
    currentSessionListRevision,
    updateForkAnchorForReplacedMessage,
    replaceSessions, appendSessions, upsertSession, rememberSession,
    knownSessionSummary, hasListedSession, patchSessionInList,
    updateKnownSessionTitle, removeSessionFromList, touchSessionInList,
    touchKnownSession, markSessionDeleted,
    clearDeletedSessionIds, clearRememberedSessions,
  } = sessionList
  const {
    workdirSessionsFor, workdirSessionsState, ensureWorkdirSessions,
    loadMoreWorkdirSessions, reset: resetWorkdirSessions,
  } = createWorkdirSessions({
    currentBotId, sessions, rememberSession,
    userScopeGeneration: () => userScopeGeneration,
    knownSession: knownSessionSummary,
  })
  const { applySessionsSnapshot } = createSessionListSnapshot({
    replaceSessions, sessionsCursor, hasMoreSessions,
  })
  const refreshCoordinator = createChatRefreshCoordinator({
    currentBotId,
    fetchSessions,
    currentSessionListRevision,
    applySessionsSnapshot,
  })
  const { refreshSessionsList, resetRefreshCoordinator } = refreshCoordinator
  const {
    ensureSessionSummary, ensureVisibleSessionSummary, loadMoreSessions,
    handleActivity: handleBotSessionsActivityEvent,
    scheduleActivityRevisions,
    isSessionCompacting, beginSessionCompaction,
    reset: resetSessionActivity,
  } = createSessionActivity({
    currentBotId,
    sessionId,
    userScopeGeneration: () => userScopeGeneration,
    currentSessionListRevision,
    currentSelectRequest: () => selectSessionRequestId,
    knownSession: knownSessionSummary,
    rememberSession,
    sessionsCursor,
    hasMoreSessions,
    loadingMoreSessions,
    appendSessions,
    hasListedSession,
    touchKnownSession,
    updateKnownSessionTitle,
    refreshSessionsList,
    refreshSessionMessages: async (botId, targetSessionId) => {
      if (chatViews.getSession(botId, targetSessionId)) {
        await refreshCurrentSession(botId, targetSessionId)
      }
    },
    markSessionViewStale: chatViews.markSessionStale,
    markAllSessionViewsStale: chatViews.markAllSessionsStale,
  })
  // `loadingChats` covers the bot-level boot path (sessions list fetch), so
  // the sidebar can show its skeleton + suppress its empty-state placeholder
  // exactly while the sessions list is in flight.
  // `loadingMessages` covers the per-session transcript fetch — the sidebar
  // never reacts to it, only the chat pane uses it to keep its own empty
  // placeholders hidden while a fresh transcript is on its way.
  const {
    bots, ensureBot, refreshBots, reset: resetBots,
  } = createChatBots({
    currentBotId,
    userScopeGeneration: () => userScopeGeneration,
    selectBot: botId => selectBot(botId),
  })
  const {
    activeFailure: startupSendFailure,
    failureFor: startupSendFailureFor,
    remember: rememberStartupSendFailure,
    clear: clearStartupSendFailure,
    reset: resetStartupSendFailures,
  } = createStartupSendFailures({
    currentBotId,
    focusedViewId: focusedChatViewId,
    normalizeTarget: normalizedChatViewTarget,
  })
  const commandEventRegistry = createCommandEventRegistry({ currentBotId, sessionId })
  const {
    commandEvent, commandEventForScope, rememberCommandEvent, beginCommandEvent, showCommandError,
    clearCommandEvent, rescopeSessionCommandEventToComposer, resetCommandEvents,
  } = commandEventRegistry
  const userSentInSession = ref<{
    id: string
    botId: string
    viewId: string
    wasDraft: boolean
    seq: number
  } | null>(null)
  let userSendSeq = 0
  function recordUserSent(botId: string, targetSessionId: string, viewId: string, wasDraft: boolean) {
    userSentInSession.value = {
      id: targetSessionId,
      botId,
      viewId,
      wasDraft,
      seq: ++userSendSeq,
    }
  }
  const { realtime, decisions, integration: runtimeIntegration } =
    createChatRuntimeLayer({
    currentBotId,
    sessionId,
    explicitSessionSelection, draftIntent,
    focusedViewId: focusedChatViewId,
    firstSend, workdirMismatchMessage,
    assistantStreams,
    sessionList,
    chatViews,
    bumpProjectionVersion: () => { runtimeProjectionVersion.value += 1 },
    normalizeTarget: normalizedChatViewTarget,
    promoteDraftView: promoteDraftChatView,
    recordUserSent,
    rescopeSessionCommandEventToComposer,
    rememberCommandEvent,
    removeTurnFromSession,
    hasVisibleAssistantBlocks,
    finalizeStreamFailure,
    refreshCurrentSession,
    resyncRuntimeTranscript,
    releaseHiddenSessionView: (botId, targetSessionId) => {
      releaseHiddenSessionView(chatViews.getSession(botId, targetSessionId) ?? null)
    },
    loadInitialMessages,
    reattachTurnToSession,
    sendFailedMessage,
    touchSessionInList,
    transcriptForTarget,
    createControlId: createInvocationId,
    connectionLostMessage: userInputConnectionLostMessage,
    sendOutcomeUnknownMessage,
    resolveErrorMessage: resolveApiErrorMessage,
    showError: message => toast.error(message),
    onBotSessionsActivityEvent: handleBotSessionsActivityEvent,
    onActivityStreamCoverageChanged: chatViews.setActivityStreamCoverage,
  })
  const {
    startWebSocket,
    stopWebSocket,
    ensureWebSocket,
    sendWebSocketMessage,
    startSessionRuntime,
    stopSessionRuntime,
    startBotSessionsActivityStream,
    stopStreams,
  } = realtime
  const {
    respondToolApproval,
    respondUserInput,
    reset: resetDecisions,
  } = decisions
  const {
    abort,
    abortAllAssistantStreams,
    watchFirstSendConfirmation,
  } = runtimeIntegration

  const hasExplicitSessionSelection = computed(() => explicitSessionSelection.value)
  const externalAgents = createExternalAgentController({
    currentBotId,
    sessionId,
    draftIntent,
    explicitSessionSelection,
    focusedViewId: focusedChatViewId,
    userScopeGeneration: () => userScopeGeneration,
    bumpSelectSessionRequest: () => ++selectSessionRequestId,
    currentSelectSessionRequest: () => selectSessionRequestId,
    normalizeTarget: normalizedChatViewTarget,
    isFocusedTarget: isFocusedChatTarget,
    chatView,
    draftCreationKey: draftSessionCreationKey,
    draftSessionCreations,
    stopSessionRuntime,
    clearHistoryView,
    resetWorkspaceTargetSelection,
    upsertSession,
    rememberSession,
    promoteDraftView: promoteDraftChatView,
    markSessionDeleted,
    removeSessionView: (botId, targetSessionId) => {
      chatViews.removeSession(botId, targetSessionId)
    },
    removeSessionFromList,
    ensureBot,
    knownSession: knownSessionSummary,
    draftWorkdirIdFor: (botId, opts) => workdirsStore.sessionWorkdirIdFor(botId, opts),
  })
  const {
    acpRuntimeStatuses, acpRuntimePending, acpRuntimeKey, clearACPRuntimeStatus, ensureACPRuntime,
    refreshACPRuntimeFor,
    setACPRuntimeMode, setACPRuntimeModel, setACPRuntimeReasoning,
  } = externalAgents.runtimeRegistry
  const { cacheDefaultExternalAgentSession, clearPendingExternalAgentSession } = externalAgents.staging
  const {
    pendingExternalAgentSessionInput, pendingACPRuntimeId, pendingExternalAgentSessionMetadata,
    pendingACPRuntimeStatus, pendingACPRuntimeEnsuring, pendingExternalAgentStateFor,
    pendingExternalAgentMatchesInput,
    stageExternalAgentSession, stageDefaultExternalAgentSession, resetToEmptyComposer,
    ensurePendingACPRuntime, setPendingACPModel, setPendingACPMode, setPendingRuntimeMode, setPendingACPReasoning,
    saveLiveDraftExternalAgentStage, activateDraftExternalAgentStage, discardEvictedDraft,
  } = externalAgents.orchestration
  const {
    settingsForAgent: defaultExternalAgentSettingsForAgent,
    stageFromSettings: stageDefaultExternalAgentFromSettings,
  } = externalAgents.defaults
  const {
    createExternalAgentSession, updateCurrentSessionAgent,
    updateCurrentSessionToMemoh, ensureChatViewSession,
  } = externalAgents.sessions
  const {
    draftViewRequested, applyDraftViewRequest, requestDraftView,
    invalidateDraftViewCommand, beginDraftViewCommand,
    reset: resetExternalAgent,
  } = externalAgents
  configureChatViews({
    runtimeProjection: realtime.runtimeProjection,
    startSessionRuntime,
    stopSessionRuntime,
    discardDraft: discardEvictedDraft,
    invalidateDraftCommand: invalidateDraftViewCommand,
    saveDraftExternalAgent: saveLiveDraftExternalAgentStage,
    activateDraftExternalAgent: activateDraftExternalAgentStage,
    refreshAppliedHook: (_view, targetSessionId, latestTimestamp) => {
      touchSessionInList(targetSessionId, latestTimestamp)
    },
    ensureVisibleSummary: (botId, targetSessionId) => {
      void ensureVisibleSessionSummary(botId, targetSessionId)
    },
  })
  const {
    targetFor: chatTargetFor,
    activeTarget: activeChatTarget,
    readOnlyFor: chatReadOnlyFor,
    canForkFor: chatCanForkFor,
  } = createChatTargets({
    currentBotId,
    focusedViewId: focusedChatViewId,
    explicitSessionSelection,
    normalizeTarget: normalizedChatViewTarget,
    knownSession: knownSessionSummary,
    pendingExternalAgentState: pendingExternalAgentStateFor,
  })


  function resetUserScopedState(options: { clearSelection?: boolean } = {}) {
    userScopeGeneration += 1
    stopStreams()
    abortAllAssistantStreams('auth_reset')
    stopWebSocket()

    resetRefreshCoordinator()

    replaceSessions([])
    clearDeletedSessionIds()
    sessionsCursor.value = null
    hasMoreSessions.value = false
    loadingMoreSessions.value = false
    resetWorkdirSessions()
    resetBots()
    sessionId.value = null
    explicitSessionSelection.value = false
    if (options.clearSelection && currentBotId.value) {
      currentBotId.value = null
    }
    resetTranscriptUserScope()
    resetExternalAgent()
    resetBootstrap()
    resetStartupSendFailures()
    resetSessionActions()
    resetSessionActivity()
    draftSessionCreations.clear()
    resetCommandEvents()
    resetFsBeacon()

    clearStreamHistory()
    resetDecisions()
    backgroundTasks.clearBackgroundTasks()
  }

  const {
    loadingChats, contactChoice, contactBusy, contactOpenRequested, contactNavigationPending, completeContactOpen,
    openContact, confirmContact, loadContactCandidates, cancelContactChoice,
    initialize,
    selectBot,
    selectSession,
    createNewSession,
    selectDraft,
    reset: resetBootstrap,
  } = createChatBootstrap({
    hasHistoryEntry: () => !!router?.currentRoute.value.query.session,
    hasContactEntry: () => !!router && CHAT_ROUTE_NAMES.has(router.currentRoute.value.name as string) && !router.currentRoute.value.query.session,
    currentBotId,
    sessionId,
    draftIntent,
    explicitSessionSelection,
    userScopeGeneration: () => userScopeGeneration,
    bumpSelectSessionRequest: () => ++selectSessionRequestId,
    currentSelectSessionRequest: () => selectSessionRequestId,
    prepareForInitialization,
    resetRefreshCoordinator,
    resetSessionActivity,
    stopStreams,
    stopWebSocket,
    ensureBot,
    replaceSessions,
    sessionsCursor,
    hasMoreSessions,
    ensureSessionSummary,
    pendingExternalAgentSessionInput,
    clearPendingExternalAgentSession,
    clearHistoryView,
    markHistoryEmpty,
    knownSessionSummary,
    startWebSocket,
    startBotSessionsActivityStream,
    startSessionRuntime,
    releasePreviousSession: (botId, targetSessionId) => {
      releaseHiddenSessionView(chatViews.getSession(botId, targetSessionId) ?? null)
    },
    abort,
    abortAllAssistantStreams,
    clearFsForBotSwitch,
    // Folder rows resolve through the remembered-session map, so dropping it
    // must drop the folders' paging state too, or a folder reads as empty.
    clearRememberedSessions: () => { clearRememberedSessions(); resetWorkdirSessions() },
    resetToEmptyComposer,
    stageDefaultExternalAgentFromSettings,
  })
  const {
    deletedSession,
    forkedSessionRequested,
    cleanupFailedDeferredSession,
    removeSession, removeSessions,
    renameSession,
    forkTurn,
    reset: resetSessionActions,
  } = createSessionActions({
    currentBotId,
    sessionId,
    draftIntent,
    explicitSessionSelection,
    focusedViewId: focusedChatViewId,
    userScopeGeneration: () => userScopeGeneration,
    normalizeTarget: normalizedChatViewTarget,
    isFocusedTarget: isFocusedChatTarget,
    chatView,
    readOnlyFor: chatReadOnlyFor,
    canForkFor: chatCanForkFor,
    isStreaming: target => isChatViewStreaming(target),
    abort: target => abort(target),
    stopSessionRuntime,
    clearRuntimeStatus: clearACPRuntimeStatus,
    removeSessionView: (botId, targetSessionId) => {
      chatViews.removeSession(botId, targetSessionId)
    },
    pruneViews: chatViews.prune,
    clearHistoryView,
    markSessionDeleted,
    removeSessionFromList,
    patchSessionInList,
    upsertSession,
    rememberSession,
    refreshSessionsList,
    fetchSessionWindow,
    replaceSessionHistory: (botId, targetSessionId, turns) => {
      sessionTranscript(botId, targetSessionId)
        .replaceHistoryView(turns, targetSessionId)
    },
    rescopeCommandToComposer: rescopeSessionCommandEventToComposer,
    forkFailedMessage,
  })

  bindBotIdInitializeWatch({
    currentBotId, initialize, resetUserScopedState,
  })
  // First-open recovery for the no-bot-selected entry (bare home route); the
  // watch above only fires once a bot id exists.
  const { initializeWithRecovery } = createInitializeRecovery({
    currentBotId, initialize,
  })

  const stopAuthSessionListener = onAuthSessionCleared(() => {
    resetUserScopedState({ clearSelection: true })
  })
  onScopeDispose(() => {
    stopAuthSessionListener()
    stopStreams()
    stopWebSocket()
  })

  const {
    handleWebNewCommand,
    isWebSlashInput,
    quickActionIDForSlash,
    handleWebSlashCommand,
  } = createChatCommands({
    currentBotId,
    userScopeGeneration: () => userScopeGeneration,
    isFocusedTarget: isFocusedChatTarget,
    beginDraftCommand: beginDraftViewCommand,
    requestDraftView,
    ensureBot,
    defaultExternalAgentSettingsForAgent,
    normalizeTarget: normalizedChatViewTarget,
    chatTargetFor,
    commandErrorMessage,
    showCommandError,
    rememberCommandEvent,
    refreshACPRuntime: refreshACPRuntimeFor,
  })

  const { sendMessage, retryLatestAssistant, editLatestUser } = createChatSend({
    currentBotId,
    sessionId,
    focusedChatViewId,
    normalizeTarget: normalizedChatViewTarget,
    chatView,
    transcriptForTarget,
    isWebSlashInput,
    quickActionIDForSlash,
    isExternalAgentTarget: target => chatTargetFor(normalizedChatViewTarget(target)).isExternalAgent,
    handleWebNewCommand,
    handleWebSlashCommand,
    commandErrorMessage,
    showCommandError,
    clearCommandEvent,
    chatReadOnlyFor,
    isChatViewStreaming,
    isChatViewCreatingSession,
    pendingExternalAgentStateFor,
    ensureChatViewSession,
    startSessionRuntime,
    recordUserSent: (target, targetSessionId, wasDraft) => {
      recordUserSent(target.botId, targetSessionId, target.viewId, wasDraft)
    },
    ensureWebSocket,
    trackAssistantStream,
    sendWebSocketMessage,
    createdSessionIdForInvocation,
    forgetCreatedSession,
    refreshCurrentSession,
    hasVisibleAssistantBlocks,
    finalizeStreamFailure,
    removeTurnFromSession,
    cleanupFailedDeferredSession,
    discardAssistantStream,
    rememberStartupSendFailure,
    draftWorkdirIdFor: botId => workdirsStore.sessionWorkdirIdFor(botId, { externalAgent: false }),
    firstSend,
    watchFirstSendConfirmation,
    sendFailedMessage,
    updateForkAnchorForReplacedMessage,
    restoreTailFromOptimistic,
  })

  return {
    messages, chatView, bindChatView, setChatViewVisible, unbindChatView,
    runtimeObservationFor: realtime.runtimeObservation, focusChatView, promoteDraftChatView, chatTargetFor,
    workspaceTargetSelectionFor, setWorkspaceTargetSelection,
    initializeWorkspaceTargetSelection, resetWorkspaceTargetSelection,
    chatReadOnlyFor, chatCanForkFor, isChatViewStreaming,
    isChatViewCreatingSession, streaming, streamingSessionId, streamingSessionIds,
    isSessionCompacting, beginSessionCompaction,
    sessions, sessionsCursor, hasMoreSessions, loadingMoreSessions,
    scheduleActivityRevisions,
    loadMoreSessions, activeSession, knownSessions, knownSessionSummary,
    workdirSessionsFor, workdirSessionsState,
    ensureWorkdirSessions, loadMoreWorkdirSessions,
    activeChatReadOnly, activeChatCanFork,
    acpRuntimeStatuses, acpRuntimePending, pendingExternalAgentSessionInput,
    pendingExternalAgentSessionMetadata, pendingACPRuntimeId, pendingACPRuntimeStatus,
    pendingACPRuntimeEnsuring, pendingExternalAgentStateFor,
    pendingExternalAgentMatchesInput,
    sessionId, hasExplicitSessionSelection, currentBotId, bots,
    activeChatTarget, isSessionStreaming,
    contactChoice, contactBusy, contactOpenRequested, contactNavigationPending, completeContactOpen,
    openContact, confirmContact, loadContactCandidates, cancelContactChoice,
    loadingChats, loadingMessages, loadingOlder, hasMoreOlder,
    // Exposed for tests only — do not branch on this in components. The
    // leading underscore reflects the test-only contract at the call site.
    _hasLoadedOlder: hasLoadedOlder,

    startupSendFailure, startupSendFailureFor,
    firstSendFor: firstSend.entryFor, isSessionTentative: firstSend.isSessionTentative,
    commandEvent, commandEventForScope, rememberCommandEvent, beginCommandEvent, showCommandError,
    fsChangedAt, markFsChanged, affectsPath, fsEventForPath,
    backgroundTaskFor,
    initialize, initializeWithRecovery, refreshBots, selectBot, selectSession, createNewSession,
    selectDraft, userSentInSession, draftPromoted, draftViewRequested, applyDraftViewRequest,
    forkedSessionRequested, deletedSession,
    stageExternalAgentSession, stageDefaultExternalAgentSession, cacheDefaultExternalAgentSession,
    resetToEmptyComposer, ensurePendingACPRuntime,
    setPendingACPModel, setPendingACPMode, setPendingRuntimeMode, setPendingACPReasoning, clearPendingExternalAgentSession,
    createExternalAgentSession, updateCurrentSessionAgent, updateCurrentSessionToMemoh,
    acpRuntimeKey, ensureACPRuntime, setACPRuntimeMode, setACPRuntimeModel, setACPRuntimeReasoning,
    removeSession, removeSessions, renameSession, forkTurn,
    sendMessage, retryLatestAssistant, editLatestUser,
    respondToolApproval, respondUserInput,
    loadOlderMessages, findMessageIdByExternalId, locateMessageByExternalId,
    clearStartupSendFailure, clearCommandEvent, abort,
  }
})
