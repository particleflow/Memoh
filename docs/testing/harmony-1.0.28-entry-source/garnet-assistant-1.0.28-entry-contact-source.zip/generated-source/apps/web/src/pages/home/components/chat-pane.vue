<template>
  <div
    ref="rootEl"
    class="flex-1 flex flex-col h-full min-w-0 relative"
    v-on="dropHandlers"
  >
    <div
      v-if="!currentBotId"
      class="flex-1"
    >
      <PanePlaceholder :title="$t('chat.selectBot')">
        {{ $t('chat.selectBotHint') }}
      </PanePlaceholder>
    </div>

    <template v-else>
      <section class="flex-1 relative w-full px-3 sm:px-5 lg:px-8">
        <section class="absolute inset-0">
          <PanePlaceholder
            v-if="taskAnchor && taskRunAnchor.status.value !== 'located'"
            :title="taskRunAnchor.status.value === 'unavailable' ? $t('chat.taskDirectory.historyUnavailable') : $t('common.loading')"
          />
          <ScrollArea
            v-show="!taskAnchor || taskRunAnchor.status.value === 'located'"
            ref="scrollContainer"
            class="h-full"
          >
            <!-- Same horizontal rhythm as the composer below (px-4 sm:px-6
                 lg:px-10) so the input box and the message column share one
                 width at every pane size — they must never diverge. The
                 bottom padding tracks the dock's measured height (composer,
                 ask_user capsule, approval panel) instead of a fixed rung, so
                 the last message can always scroll clear of it. -->
            <div
              class="w-full max-w-[840px] mx-auto px-4 pt-6 space-y-6 sm:px-6 lg:px-10"
              :style="{ paddingBottom: messagesBottomPad }"
            >
              <div
                ref="loadMoreSentinel"
                aria-hidden="true"
                class="h-px w-full"
              />
              <div
                v-if="loadingOlder"
                class="flex justify-center py-2"
              >
                <Spinner class="size-3.5" />
              </div>

              <!-- A session with a live run but no messages yet (a subagent
                   that has not produced output) reads as starting, not empty.
                   A first send waiting on welcome already shows its spinner
                   on the send button. -->
              <div
                v-if="messages.length === 0 && !loadingChats && !loadingMessages && streaming && !isWelcome"
                class="flex items-center justify-center min-h-75"
              >
                <Spinner class="size-3.5" />
              </div>

              <!-- Read-only sessions (system / synced channel threads) can't
                   take new input, so an empty one states why it has nothing.
                   A fresh, writable chat instead gets the centered welcome
                   composer below, never a stray line in a blank pane. -->
              <div
                v-else-if="messages.length === 0 && !loadingChats && !loadingMessages && activeChatReadOnly"
                class="flex items-center justify-center min-h-75"
              >
                <p class="text-muted-foreground text-xs">
                  {{ $t('chat.emptySystemSession') }}
                </p>
              </div>

              <!-- Cold-open placeholder while a session's first page is on the
                   wire — Arkloop's ChatSkeleton shape, re-derived on Memoh
                   geometry: chat text is 16px at --chat-leading 1.48 ≈ 24px
                   line pitch, so a real one-line user bubble is py-3 + 24px =
                   48px tall and ~10 CJK chars + px-4 ≈ 192px wide; each reply
                   bar (12px + 12px gap) occupies one text line's 24px pitch.
                   The shared Skeleton primitive owns the loading motion and
                   base tone; only the width stagger is kept from the old
                   hand-rolled version. -->
              <div
                v-if="skeletonVisible"
                class="flex flex-col gap-6"
                aria-hidden="true"
              >
                <div class="flex justify-end">
                  <Skeleton class="h-12 w-48 rounded-2xl" />
                </div>
                <div class="flex flex-col gap-3">
                  <Skeleton
                    v-for="w in CHAT_SKELETON_BAR_WIDTHS"
                    :key="w"
                    class="h-3 rounded"
                    :style="{ width: w }"
                  />
                </div>
              </div>

              <!-- One persistent container per turn, keyed by the turn's
                   opening message id — a send APPENDS a container; previous
                   turns' DOM is never re-parented (see messageTurns for why
                   that is load-bearing). The send pin reserves viewport space
                   by setting an inline min-height on the LAST turn's container
                   (see tryApplyPin in useChatScroll). -->
              <div
                v-for="(turn, turnIndex) in messageTurns"
                :key="turn.id"
                :ref="turnIndex === messageTurns.length - 1 ? setLastTurnEl : undefined"
                :style="turnReserveStyle(turn.id)"
                data-chat-turn
              >
                <div
                  data-turn-motion
                  class="space-y-6"
                >
                  <template
                    v-for="(msg, msgIndex) in turn.messages"
                    :key="msg.id"
                  >
                    <ForkSourceDivider
                      v-if="showForkSourceDividerBefore(turn.start + msgIndex)"
                      :title="forkSourceTitle"
                      :disabled="openingForkSource"
                      @open-source="handleForkSourceClick"
                    />

                    <ContextMenu>
                      <ContextMenuTrigger
                        as-child
                        :disabled="!readAloud.canReplay(msg)"
                      >
                        <div
                          :data-message-id="msg.id"
                          :data-external-message-id="(msg.role === 'user' || msg.role === 'assistant') ? msg.externalMessageId : undefined"
                          class="transition-[background-color] duration-500 scroll-mt-2 px-2 -mx-2"
                          :class="highlightedMessageId === msg.id ? 'bg-muted/45' : ''"
                          :data-anchor="msg.id"
                          @click.capture="readAloud.stop()"
                        >
                          <MessageItem
                            :message="msg"
                            :hide-process-activity="contactView && activeChatTarget.runtimeType === 'model'"
                            :bot-id="currentBotId"
                            :session-id="activeSessionId"
                            :recovery-original-run-id="originalFailedRunId(msg)"
                            :recovery-enabled="!activeChatReadOnly && !isChannelThread"
                            :recovery-visible="isVisible"
                            :channel-thread="isChannelThread"
                            :channel-platform="channelPlatform"
                            :bot-name="currentBot?.name"
                            :bot-avatar-url="currentBot?.avatar_url"
                            :on-open-media="galleryOpenBySrc"
                            :on-reply-click="handleReplyJump"
                            :on-retry-message="handleRetryMessage"
                            :can-retry-latest-assistant="isRetryableTurn(msg)"
                            :can-edit-latest-user="isEditableTurn(msg)"
                            :can-fork-assistant="isForkableTurn(msg)"
                            :inline-actions="isDirectBotAgentRuntime(activeChatTarget.runtimeType)"
                            :goal-runtime="activeChatTarget.runtimeType"
                            :is-scrolling="isScrolling"
                            :is-last-message="msg.id === lastMessageId"
                            :speech-enabled="readAloud.enabled.value"
                            :speech-status="readAloud.status(msg)"
                            @replay-speech="readAloud.replay(msg)"
                            @active="onMessageActive"
                            @edit-message="handleEditMessage"
                            @fork-message="handleForkMessage"
                          />
                        </div>
                      </ContextMenuTrigger>
                      <ContextMenuContent v-if="readAloud.canReplay(msg)">
                        <ContextMenuItem @select="readAloud.replay(msg)">
                          {{ $t('chat.readAloud.replay') }}
                        </ContextMenuItem>
                        <ContextMenuItem
                          v-if="readAloud.status(msg) !== 'idle'"
                          @select="readAloud.stop()"
                        >
                          {{ $t('chat.readAloud.stop') }}
                        </ContextMenuItem>
                      </ContextMenuContent>
                    </ContextMenu>

                    <ForkSourceDivider
                      v-if="showForkSourceDividerAfter(msg, turn.start + msgIndex)"
                      :title="forkSourceTitle"
                      :disabled="openingForkSource"
                      @open-source="handleForkSourceClick"
                    />
                  </template>
                </div>
              </div>
            </div>
          </ScrollArea>

          <ChatScrollRail
            :messages="messages"
            :scroll-el="scrollEl"
            :enabled="isVisible && !loadingChats"
            @jump="handleRailJump"
          />
        </section>
      </section>

      <MediaGalleryLightbox
        :items="galleryItems"
        :open-index="galleryOpenIndex"
        :origin="galleryOrigin"
        @update:open-index="gallerySetOpenIndex"
      />

      <MediaGalleryLightbox
        :items="composerPreviewItems"
        :open-index="composerPreviewIndex"
        :origin="composerPreviewOrigin"
        appearance="frost"
        @update:open-index="composerPreviewIndex = $event"
      />

      <Dialog v-model:open="pastedViewerOpen">
        <DialogContent class="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{{ $t('common.preview') }}</DialogTitle>
          </DialogHeader>
          <pre class="max-h-[60vh] overflow-auto whitespace-pre-wrap break-words rounded-lg border border-border bg-surface-composer p-3 text-caption leading-relaxed text-foreground">{{ pastedViewerText }}</pre>
        </DialogContent>
      </Dialog>

      <ChatForkDialog
        v-model:open="forkDialogOpen"
        :turn-id="pendingForkTurnId"
      />

      <!-- Asked before a usage example or App "Try it" replaces unsent text. -->
      <ConfirmDeleteDialog
        :open="replaceDraftConfirm.open.value"
        :title="$t('chatExamples.replaceDraft.title')"
        :description="$t('chatExamples.replaceDraft.description')"
        :cancel-label="$t('common.cancel')"
        :confirm-label="$t('chatExamples.replaceDraft.confirm')"
        @update:open="replaceDraftConfirm.setOpen"
        @confirm="replaceDraftConfirm.answer(true)"
      />

      <!-- The composer is a single instance reused in both layouts: pinned to
           the bottom once a conversation exists, or lifted to the vertical
           centre (with a greeting above it) while the chat is still empty, so a
           fresh chat opens on an inviting page instead of a near-blank pane. -->
      <!-- No outer horizontal gutter here on purpose: the message list lives in a
           `section.absolute.inset-0` layer that fills its parent's padding box, so
           it bypasses the section's px-3/sm:px-5/lg:px-8 gutter and only carries the
           inner px-4/sm:px-6/lg:px-10. The composer must drop the same outer gutter
           so its inner padding is the ONLY horizontal inset — matching the message
           column edge-for-edge at every width. -->
      <div
        v-if="!activeChatReadOnly"
        class="pointer-events-none absolute z-(--z-panel)"
        :class="[
          isWelcome
            ? 'inset-0 flex flex-col items-center justify-start'
            : 'inset-x-0 bottom-0 pt-2',
          { invisible: composerPlacementPending },
        ]"
        :style="composerLiftPx > 0 ? { bottom: `${composerLiftPx}px` } : undefined"
      >
        <!-- Opaque backdrop, bottom-anchored, rising only to the box's widest point
             (its vertical centre). The box is solid and sits above the messages, so
             above that line its rounded top simply floats over whatever is there —
             that area is left unmasked on purpose. From the widest point down (where
             the box curves back in and would leave gaps by its bottom corners, plus
             the strip beneath it) this fill hides everything, so nothing bleeds out
             below the box. No fade: the top edge meets the box where it is already
             full width, so the seam is hidden behind the box itself. -->
        <div
          v-if="!isWelcome"
          aria-hidden="true"
          class="absolute inset-x-0 bottom-0 bg-surface-editor"
          :style="{ height: dockMaskHeight }"
        />
        <!-- welcome: top-anchored column — the greeting and the composer's top
             edge stay pinned at the spacer's pane-relative anchor, so a growing
             composer (text or attachments) only extends downward and never
             pushes the greeting up; normal: display:contents removes this from
             layout. The welcome arm is ALSO the size container the height-keyed
             degradation tiers query (style.css, [data-welcome-column]): flex-1
             min-h-0 makes its height track the space actually left to it, and
             container-type:size lets descendants read that height — without
             min-h-0 the box would stay content-sized and the queries would
             measure the content, never the pane. -->
        <div
          :class="isWelcome
            ? 'flex w-full flex-1 min-h-0 flex-col items-center gap-8 md:-translate-x-3 [container-type:size] [container-name:welcome-col]'
            : 'contents'"
          :data-welcome-column="isWelcome ? '' : undefined"
        >
          <!-- Anchor spacer: together with the wrapper's gap-8 it parks the
               greeting's top edge at 28% of the column's height (= the
               pane's), capped at 16rem, collapsible to 0. It is the FIRST
               thing that yields when the pane gets short — the greeting +
               composer rise to the top before anything clips; the degradation
               tiers (style.css) take over below that. Must not become a
               vh/dvh padding again: viewport units ignore the pane's own
               height, and in short panes (vertical splits) the offset alone
               can push the composer past the group's overflow-hidden edge,
               where the next pane's tab strip reads as covering it. No floor
               either: a minimum offset would push content out of a tiny
               pane. (h- + default shrink, not flex-none + basis: the flex
               shorthand would reset flex-basis to auto.) -->
          <div
            v-if="isWelcome"
            aria-hidden="true"
            class="h-[clamp(0rem,calc(28%_-_2rem),16rem)] w-px"
          />
          <div
            v-if="isWelcome"
            class="mx-auto w-full max-w-[44rem] px-4 text-left sm:px-6 lg:px-10"
          >
            <h1
              data-welcome-heading
              class="px-4 text-balance text-foreground"
            >
              {{ welcomeGreeting }}
            </h1>
          </div>
          <!-- A fresh chat uses a focused content measure; once conversation starts,
               the composer expands to the message column. Both keep the same responsive
               gutters (px-4 sm:px-6 lg:px-10), so their internal alignment does not
               change — the inner gutter still relaxes on a cramped pane, but both
               edges move together. The -translate-x-0.5 is a 2px optical nudge:
               the column math is centered, but the eye reads the composer a hair
               right of the message column (the scroll rail eats the right edge),
               so the whole dock unit shifts left a touch to sit where it looks
               centered. Desktop only — mobile has no scroll rail, so there the
               nudge would just push the composer off centre. -->
          <div
            ref="composerPlacementEl"
            class="pointer-events-auto relative mx-auto w-full px-4 sm:px-6 lg:px-10 md:-translate-x-0.5"
            :class="isWelcome ? 'max-w-[44rem]' : 'max-w-[840px]'"
          >
            <Transition
              enter-active-class="motion-safe:transition-opacity motion-safe:duration-150 ease-out"
              enter-from-class="motion-safe:opacity-0"
              enter-to-class="opacity-100"
              leave-active-class="motion-safe:transition-opacity motion-safe:duration-150 ease-in"
              leave-from-class="opacity-100"
              leave-to-class="motion-safe:opacity-0"
            >
              <BgTaskPill
                v-if="bgTaskPill"
                :pill="bgTaskPill"
                class="absolute left-0 bottom-full z-(--z-sticky) mb-2 max-w-[calc(50%-2rem)]"
                @jump="scrollToOffscreen"
              />
            </Transition>

            <Transition
              enter-active-class="transition-opacity duration-150 ease-out"
              enter-from-class="opacity-0"
              enter-to-class="opacity-100"
              leave-active-class="transition-opacity duration-150 ease-in"
              leave-from-class="opacity-100"
              leave-to-class="opacity-0"
            >
              <Button
                v-if="showJumpToBottom"
                type="button"
                size="icon"
                variant="ghost"
                class="absolute left-1/2 bottom-full z-(--z-sticky) mb-4 size-9 -translate-x-1/2 rounded-full border border-border bg-card text-foreground"
                aria-label="Scroll to latest message"
                @click="scrollToBottom"
              >
                <ArrowDown class="size-4" />
              </Button>
            </Transition>

            <HarmonyAttachments
              ref="harmonyAttachmentPicker"
              v-model="pendingNativeAttachments"
              :bot-id="currentBotId || ''"
              :scope="nativeAttachmentScope"
              :active="isActive && isVisible"
              :disabled="!isActive || !isVisible || !currentBotId || activeChatReadOnly || streaming || loadingMessages || attachmentPreparing"
            />
            <input ref="harmonyPhotoInput" type="file" accept="image/*" multiple class="hidden" @change="handleFileInputChange">
            <input
              ref="fileInput"
              type="file"
              multiple
              class="hidden"
              @change="handleFileInputChange"
            >
            <Transition
              enter-active-class="transition-opacity duration-150 ease-out"
              enter-from-class="opacity-0"
              enter-to-class="opacity-100"
              leave-active-class="transition-opacity duration-100 ease-in"
              leave-from-class="opacity-100"
              leave-to-class="opacity-0"
            >
              <Command
                v-if="slashPanelOpen"
                class="absolute inset-x-4 bottom-full z-(--z-panel) mb-2 h-auto w-auto"
              >
                <CommandKeyBridge ref="slashPickerBridge">
                  <CommandList class="max-h-[min(20rem,45dvh)] overscroll-contain [scrollbar-gutter:stable]">
                    <CommandGroup
                      v-if="visibleSlashQuickActions.length"
                      :heading="$t('chat.slash.quickActions')"
                    >
                      <CommandItem
                        v-for="action in visibleSlashQuickActions"
                        :key="action.id"
                        :value="action.label"
                        :disabled="action.id === 'goal' && !!goalExecutionBlockedReason"
                        @select="selectSlashQuickAction(action)"
                      >
                        <component
                          :is="action.icon"
                          class="size-4 shrink-0 text-muted-foreground"
                        />
                        <span class="min-w-0 flex-1">
                          <span class="block truncate text-control">{{ action.id === 'plan' ? $t('chat.planMode.commandLabel') : action.id === 'goal' ? $t('chat.goal.label') : action.label }}</span>
                          <span class="block truncate text-caption text-muted-foreground">{{ action.description }}</span>
                        </span>
                      </CommandItem>
                    </CommandGroup>
                    <CommandSeparator
                      v-if="visibleSlashQuickActions.length && (visibleRuntimeAgentCommands.length || visibleSlashSkills.length)"
                    />
                    <CommandGroup
                      v-if="visibleRuntimeAgentCommands.length"
                      :heading="$t('chat.slash.agentCommands')"
                    >
                      <CommandItem
                        v-for="command in visibleRuntimeAgentCommands"
                        :key="command.name"
                        :value="`/${command.name}`"
                        @select="selectRuntimeCommand(command)"
                      >
                        <span class="min-w-0 flex-1">
                          <span class="block truncate text-control">/{{ command.name }}</span>
                          <span
                            v-if="command.description"
                            class="block truncate text-caption text-muted-foreground"
                          >{{ command.description }}</span>
                          <span
                            v-if="command.input_hint"
                            class="block truncate text-caption text-muted-foreground"
                          >{{ $t('chat.slash.agentCommandInputHint', { hint: command.input_hint }) }}</span>
                        </span>
                      </CommandItem>
                    </CommandGroup>
                    <CommandSeparator v-if="visibleRuntimeAgentCommands.length && visibleSlashSkills.length" />
                    <CommandGroup
                      v-if="visibleSlashSkills.length"
                      :heading="$t('chat.slash.skills')"
                    >
                      <CommandItem
                        v-for="skill in visibleSlashSkills"
                        :key="skill.name"
                        :value="skill.name"
                        @select="addRequestedSkill(skill)"
                      >
                        <Sparkles class="size-4 shrink-0 text-muted-foreground" />
                        <span class="min-w-0 flex-1">
                          <span class="block truncate text-control">{{ skill.display_name || skill.name }}</span>
                          <span
                            v-if="skill.description"
                            class="block truncate text-caption text-muted-foreground"
                          >{{ skill.description }}</span>
                        </span>
                      </CommandItem>
                    </CommandGroup>
                    <div
                      v-if="safeSkillCatalogLoading"
                      class="py-6 text-center text-body text-muted-foreground"
                    >
                      {{ $t('chat.slash.loadingSkills') }}
                    </div>
                    <div
                      v-else-if="!slashPanelHasResults"
                      class="py-6 text-center text-body text-muted-foreground"
                    >
                      {{ $t('chat.slash.noResults') }}
                    </div>
                  </CommandList>
                </CommandKeyBridge>
              </Command>
            </Transition>
            <ComposerDock
              ref="dockEl"
              :approvals="pendingApprovals"
              :command-panel="composerCommandPanel"
              :error-message="composerPanelError"
              :pending-user-input="pendingUserInput"
              :usage-notice="composerUsageNotice"
              @select-command-item="selectCommandResultItem"
              @dismiss-command="clearCurrentCommandEvent"
              @dismiss-usage="dismissCodexUsageNotice"
              @dismiss-error="dismissComposerPanelError"
              @reveal-composer="handleDockRevealComposer"
            >
              <CodexGoalBar
                v-if="runtimeControls.goal.value || visibleRuntimeGoalError"
                :key="runtimeModeScope"
                class="mx-3 mb-2"
                :goal="runtimeControls.goal.value"
                :error="visibleRuntimeGoalError"
                :disabled="goalControlsDisabled"
                :resume-disabled="goalResumeDisabled"
                :resume-disabled-reason="goalExecutionBlockedReason"
                :streaming="streaming"
                @pause="controlGoal('pause')"
                @clear="controlGoal('clear')"
                @resume="controlGoal('resume')"
                @dismiss-error="dismissedRuntimeGoalError = runtimeGoalError"
              />
              <!-- The composer is ALWAYS a two-row card (textarea on top,
                   controls below) — no pill↔multiline morph: a fixed rounded-2xl
                   box, so its shape never depends on the content and nothing
                   animates mid-typing.
                   Docked (non-welcome) state compresses and quiets: no min
                   height + tighter padding (p-2.5) + a shorter textarea row
                   (min-h-10) pull the two rows together — the centered welcome
                   card keeps the full presence (min-h-28, wider --composer-pad); docked it sits
                   under the conversation and should read lighter, with the edge
                   softened to --border-soft (.chat-composer-docked, style.css).
                   Mobile radius is DERIVED from the control circles inside:
                   radius tracks the control radius — 44px controls → 22, i.e.
                   rounded-3xl (24, nearest rung); the same rule on desktop
                   (32px controls → 16) is exactly the rounded-2xl the card
                   already wears. (The concentric alternative, control radius +
                   padding = 32, read as too round in QA.) -->
              <div
                ref="composerEl"
                data-slot="input-group"
                role="group"
                class="chat-composer-edge @container/composer relative flex w-full flex-wrap content-between items-end gap-1 rounded-2xl bg-surface-composer cursor-text p-(--composer-pad) max-md:rounded-3xl"
                :class="[
                  isWelcome ? 'min-h-28' : 'chat-composer-docked',
                  voiceInputState !== 'idle' ? 'chat-composer-voice' : '',
                ]"
                @pointerdown.capture="stopReadAloudForNativeInput"
                @click="handleComposerClick"
              >
                <SessionFollowUpQueue
                  v-if="hasRenderedSession && currentBotId && activeSessionId"
                  :bot-id="currentBotId"
                  :session-id="activeSessionId"
                  :active="streaming"
                  :refresh-key="queueRefreshKey"
                />
                <!-- The attachment row reveals via a grid 0fr↔1fr track so a card
                   is unveiled in place — it never translates and is always
                   clipped, so it can't overflow the box — while the composer
                   grows around it. The inner min-h-0 + overflow-hidden is what
                   lets the grid track actually collapse below content height. -->
                <Transition
                  enter-active-class="transition-[grid-template-rows] motion-reduce:transition-none"
                  enter-from-class="grid-rows-[0fr]"
                  enter-to-class="grid-rows-[1fr]"
                  leave-active-class="transition-[grid-template-rows] motion-reduce:transition-none"
                  leave-from-class="grid-rows-[1fr]"
                  leave-to-class="grid-rows-[0fr]"
                  :duration="ATTACHMENT_ANIM_MS"
                >
                  <div
                    v-if="showAttachmentGrid"
                    class="order-first grid w-full basis-full"
                    :style="{ transitionDuration: `${ATTACHMENT_ANIM_MS}ms`, transitionTimingFunction: 'cubic-bezier(0.25, 0.1, 0.25, 1)' }"
                  >
                    <div class="min-h-0 overflow-hidden">
                      <div class="flex flex-wrap gap-2 pb-1.5">
                        <template v-for="preview in pendingPreviews" :key="preview.key">
                        <HarmonyVoicePlayer v-if="preview.file.type.startsWith('audio/')" :file="preview.file" removable @remove="removeAttachment(preview.i)" />
                        <ChatAttachmentCard
                          v-else
                          :kind="preview.isPasted ? 'pasted' : (preview.isMedia ? 'media' : 'file')"
                          :src="preview.url"
                          :video="preview.isVideo"
                          :name="preview.file.name"
                          :ext="preview.ext"
                          :lines="preview.lines"
                          :text="preview.pastedText"
                          :size="preview.size"
                          :loading="preview.loading"
                          removable
                          :clickable="preview.isPasted || preview.isText || (preview.isMedia && !!preview.url)"
                          @remove="removeAttachment(preview.i)"
                          @preview="preview.isPasted ? (pastedViewerText = preview.pastedText) : openComposerPreview(preview.url, $event, preview.file).catch(error => { composerError = error instanceof Error ? error.message : String(error) })"
                        />
                        </template>
                      </div>
                      <div
                        v-if="attachmentUploading"
                        class="flex items-center justify-between gap-2"
                        role="status"
                      >
                        <InlineLoadingRow>{{ $t('chat.uploadingAttachments') }}</InlineLoadingRow>
                        <TextButton @click="cancelAttachmentUpload">
                          {{ $t('common.cancel') }}
                        </TextButton>
                      </div>
                    </div>
                  </div>
                </Transition>

                <Transition
                  enter-active-class="transition-opacity duration-150 ease-out"
                  enter-from-class="opacity-0"
                  enter-to-class="opacity-100"
                  leave-active-class="transition-opacity duration-100 ease-in"
                  leave-from-class="opacity-100"
                  leave-to-class="opacity-0"
                >
                  <div
                    v-if="skillSlashEnabled && requestedSkills.length"
                    class="order-first flex w-full basis-full flex-wrap gap-1.5 pb-1.5"
                  >
                    <div
                      v-for="skill in requestedSkills"
                      :key="requestedSkillKey(skill)"
                      class="flex min-h-8 max-w-full items-center gap-1.5 rounded-full bg-accent py-0.5 pl-2.5 pr-0.5 text-label text-foreground"
                    >
                      <Sparkles class="size-3.5 shrink-0 text-muted-foreground" />
                      <span class="min-w-0 truncate">{{ skill.display_name || skill.name }}</span>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon-sm"
                        :aria-label="$t('chat.slash.removeSkill', { name: skill.display_name || skill.name })"
                        class="shrink-0"
                        @click="removeRequestedSkill(skill)"
                      >
                        <X class="size-3.5" />
                      </Button>
                    </div>
                  </div>
                </Transition>

                <!-- While a voice recording/transcription is in flight the
                     composer's input row IS the voice surface: live level
                     bars + elapsed time take the textarea's place (same
                     min-height, so the box never jumps), and the controls row
                     below sheds everything except the voice pair.
                     A11y: role="status" is an implicit polite+atomic live
                     region, so every text change inside re-announces the
                     whole strip — the per-second timer would chatter for the
                     entire recording. Bars and timer are aria-hidden; only
                     the sr-only state line announces, once per transition. -->
                <div
                  v-if="voiceInputState !== 'idle'"
                  role="status"
                  :aria-label="$t('chat.voiceInput.barLabel')"
                  class="order-none flex w-full basis-full items-center gap-2 pl-2 pr-1"
                  :class="isWelcome ? 'min-h-12' : 'min-h-10'"
                >
                  <!-- Level history fills the whole row and pushes in from
                       the RIGHT: the window length tracks the strip's pixel
                       width, newest sample lands on the right edge, quiet
                       history fades to dots on the left. Bar count derives
                       from measured width (2px bar + 3px gap); heights are
                       runtime audio data, so both stay inline px. -->
                  <div
                    ref="voiceStripEl"
                    aria-hidden="true"
                    class="flex h-8 min-w-0 flex-1 items-center gap-[3px] overflow-hidden"
                  >
                    <div
                      v-for="(level, index) in voiceBars"
                      :key="index"
                      class="w-0.5 shrink-0 rounded-full motion-safe:transition-[height] motion-safe:duration-75"
                      :class="level > VOICE_BAR_ACTIVE_LEVEL ? 'bg-foreground' : 'bg-muted-foreground'"
                      :style="{ height: `${Math.max(2, Math.round(level * VOICE_BAR_MAX_PX))}px` }"
                    />
                  </div>
                  <span
                    aria-hidden="true"
                    class="shrink-0 text-control tabular-nums text-muted-foreground"
                  >{{ formattedVoiceSeconds }}</span>
                  <span class="sr-only">{{ voiceInputState === 'transcribing' ? $t('chat.voiceInput.transcribing') : $t('chat.voiceInput.barLabel') }}</span>
                </div>
                <textarea
                  v-else
                  ref="textareaEl"
                  v-model="inputText"
                  rows="1"
                  :placeholder="composerPreviewShown ? '' : composerPlaceholder"
                  :disabled="!currentBotId || activeChatReadOnly || loadingMessages || firstSendAwaiting || attachmentUploading || attachmentPreparing"
                  class="order-none max-h-52 w-full basis-full field-sizing-content resize-none break-words bg-transparent pl-2 pr-1 pt-2 pb-1.5 text-base leading-[var(--chat-leading)] outline-none placeholder:text-[var(--field-placeholder)] disabled:cursor-not-allowed"
                  :class="[isWelcome ? 'min-h-12' : 'min-h-10', composerPreviewShown ? 'text-transparent' : 'text-foreground']"
                  @input="readAloud.stop()"
                  @keydown="handleComposerKeydown"
                  @paste="handlePaste"
                />
                <!-- The suggestion preview: laid exactly over the textarea's
                     text box (same padding, size and leading), so it wraps line
                     for line like the text it becomes. Out of flow, so the
                     composer never resizes while a row is hovered. -->
                <div
                  v-if="composerPreviewShown && composerPreviewBox"
                  :key="composerPreview?.text"
                  data-composer-preview
                  :data-landing="composerPreview?.landing || undefined"
                  aria-hidden="true"
                  class="pointer-events-none absolute line-clamp-2 break-words pl-2 pr-1 pt-2 text-base leading-[var(--chat-leading)] max-md:line-clamp-1"
                  :style="composerPreviewBox"
                >
                  {{ composerPreview?.text }}
                </div>

                <!-- max-md size bumps on the composer controls (the ＋ and voice
                     buttons, the model trigger, and the send ring below) grow the
                     tap targets to the 44px touch floor on phones; desktop keeps
                     the compact size. -->
                <DropdownMenu>
                  <DropdownMenuTrigger as-child>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon-sm"
                      shape="circle"
                      :disabled="!currentBotId || activeChatReadOnly || composerConfigPending || voiceInputState !== 'idle'"
                      :class="runtimeModeChanging && !!currentBotId && !activeChatReadOnly && !composerAgentConfigPending && voiceInputState === 'idle' ? 'disabled:opacity-100' : undefined"
                      :title="$t('chat.composerActions')"
                      tone="muted"
                      class="order-1 self-end max-md:size-11"
                      :aria-label="$t('chat.composerActions')"
                    >
                      <AddIcon
                        class="size-4 max-md:size-5"
                      />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent
                    class="w-56"
                    align="start"
                    :side="isWelcome ? 'bottom' : 'top'"
                  >
                    <DropdownMenuItem
                      :disabled="!currentBotId || activeChatReadOnly || streaming || loadingMessages"
                      @select="nativeAttachmentsAvailable ? harmonyAttachmentPicker?.select(true) : harmonyPhotoInput?.click()"
                    >
                      <ImagePlus />
                      <span class="min-w-0 flex-1 truncate">{{ $t('chat.attachPhotos') }}</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      :disabled="!currentBotId || activeChatReadOnly || streaming || loadingMessages"
                      @select="nativeAttachmentsAvailable ? harmonyAttachmentPicker?.select(false) : fileInput?.click()"
                    >
                      <UploadIcon />
                      <span class="min-w-0 flex-1 truncate">{{ $t('chat.attachFiles') }}</span>
                    </DropdownMenuItem>
                    <ComposerConnectorsMenu
                      :bot-id="currentBotId || ''"
                      :bot-name="currentBot?.name || currentBotId || ''"
                    />
                  </DropdownMenuContent>
                </DropdownMenu>

                <!-- The model selector truncates within the input controls row. -->
                <div class="order-3 flex min-w-0 flex-1 basis-48 items-center justify-end gap-1 self-end">
                  <DropdownMenu
                    v-if="(!activeUsesExternalAgentComposer || activeUsesACPRuntime || activeUsesDirectRuntime) && voiceInputState === 'idle'"
                    v-model:open="modelPopoverOpen"
                    :modal="false"
                  >
                    <DropdownMenuTrigger as-child>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        shape="circle"
                        :disabled="!currentBotId || activeChatReadOnly || composerConfigPending"
                        :class="runtimeModeChanging && !!currentBotId && !activeChatReadOnly && !composerAgentConfigPending ? 'disabled:opacity-100' : undefined"
                        class="composer-pill-press min-w-0 shrink max-md:h-11"
                        :style="{ maxWidth: `${modelTriggerMaxWidth}px` }"
                        :title="modelTriggerLabel"
                        :aria-label="modelTriggerLabel"
                      >
                        <!-- One transformable wrapper for the press squish —
                             same contract as composer-continue-on's pill. -->
                        <span class="composer-pill-content inline-flex min-w-0 items-center gap-2">
                          <span class="min-w-0 truncate text-label text-composer-control-label">{{ modelTriggerLabel }}</span>
                          <ChevronDown
                            class="size-3.5 shrink-0 text-muted-foreground"
                            :stroke-width="1.5"
                          />
                        </span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent
                      class="w-72 max-w-[calc(100vw-2rem)]"
                      position-strategy="absolute"
                      align="end"
                      side="top"
                      :collision-padding="8"
                    >
                      <ComposerModelMenu
                        :model-value="composerModelId"
                        :model-label="selectedModelLabel || $t('chat.modelDefault')"
                        :default-model-id="composerDefaultModelId"
                        :reasoning-effort="composerReasoningEffort"
                        :reasoning-options="composerReasoningOptions"
                        :models="composerModels"
                        :providers="composerModelProviders"
                        :none-label="activeUsesDirectRuntime && composerDefaultModelId && composerDefaultModelId !== 'default' ? composerDefaultModelLabel : undefined"
                        :show-reasoning="!activeUsesDirectRuntime || !!composerReasoningOptions?.length"
                        :loading="composerModelsLoading"
                        :error="modelCatalogMenuError"
                        :auth-required="directRuntimeAuthRequired"
                        @update:model-value="onComposerModelValueSelected"
                        @update:reasoning-effort="onComposerReasoningEffortSelected"
                        @retry="retryDirectModelCatalog"
                        @settings="openAgentSettings(false)"
                      />
                    </DropdownMenuContent>
                  </DropdownMenu>

                  <HarmonyVoiceInput
                    v-if="nativeVoiceAvailable"
                    :key="inputDraftKey"
                    :disabled="!currentBotId || activeChatReadOnly || streaming || loadingMessages || composerConfigPending || composerHasNoModel || goalSubmissionBlocked || !!runtimeModeUnavailableReason"
                    :editor-target="harmonyVoiceEditorTarget"
                    :send="sendComposer"
                    @transcribe="insertHarmonyVoiceText"
                    @error="composerError = $event instanceof Error ? $event.message : $t('chat.sendFailed')"
                  />
                  <!-- While voice owns the composer the trailing slot holds
                       the voice pair instead of mic/send: ✗ cancels (also
                       aborts an in-flight transcription), ✓ stops and
                       transcribes — the ✓ keeps the mic's filled-primary
                       circle language so the control the user started with is
                       the one they commit with. -->
                  <div
                    v-if="voiceInputState !== 'idle'"
                    class="flex shrink-0 items-center gap-2"
                  >
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon-sm"
                      shape="circle"
                      :aria-label="$t('chat.voiceInput.cancel')"
                      class="text-muted-foreground max-md:size-11"
                      @click="cancelVoiceInput"
                    >
                      <X class="size-4 max-md:size-5" />
                    </Button>
                    <Button
                      type="button"
                      variant="primary"
                      size="icon-sm"
                      shape="circle"
                      :disabled="voiceInputState === 'transcribing'"
                      :aria-label="$t('chat.voiceInput.confirm')"
                      class="max-md:size-11"
                      @click="stopVoiceInput"
                    >
                      <Spinner
                        v-if="voiceInputState === 'transcribing'"
                        class="size-4 max-md:size-5"
                      />
                      <Check
                        v-else
                        class="size-4 max-md:size-5"
                      />
                    </Button>
                  </div>
                  <div
                    v-else
                    v-show="!nativeVoiceAvailable || !inactiveSlotVisible"
                    class="relative size-8 max-md:size-11 shrink-0"
                  >
                    <!-- Mic and send share this one slot (never both visible):
                         with nothing to send, voice input IS the affordance
                         here; typing (or attaching) hands it to send. Mic is a
                         filled PRIMARY circle at rest (near-black, not brand —
                         brand stays scarce, reserved for send/stop), so the
                         slot reads as one continuous filled control that swaps
                         its glyph and meaning on the same cross-fade timing.

                         Visibility (opacity / scale / pointer-events) lives on
                         WRAPPER divs around each Button, never on the Button
                         itself: the design system's disabled dimming is
                         element-level opacity-40 (packages/ui AGENTS.md
                         § Disabled), which outranks opacity-0/100 state classes
                         in the cascade — so a disabled "hidden" button still
                         painted at 0.4 and bled through its sibling (the mic
                         ghost showed under the semi-transparent send while
                         loadingMessages). Split onto two elements, the two
                         opacity systems compound instead of fight: hidden
                         stays hidden, while a VISIBLE disabled button still
                         dims as designed. The mic itself is only shelved
                         (voiceInputEnabled, see script): its wrapper stays
                         here, v-if'd out of the tree, until the default
                         transcription model lands. -->
                    <!-- Inactive stand-in while voice input is shelved: the
                         send circle's grayed self — the same primary fill the
                         mic wore, dimmed by the design system's disabled
                         opacity-40, carrying the send glyph so activation
                         reads as the SAME button waking up (it scales down
                         while brand send springs in on the original
                         cross-fade timing). `disabled` is safe here BECAUSE
                         visibility lives on the wrapper: the button's own
                         dimming never fights the fade. Delete it when
                         voiceInputEnabled flips on. -->
                    <div
                      v-if="!voiceInputEnabled"
                      class="absolute inset-0 transition-[opacity,scale] duration-[188ms] ease-[ease] motion-reduce:transition-none"
                      :class="inactiveSlotVisible ? 'scale-100 opacity-100' : 'pointer-events-none scale-70 opacity-0'"
                    >
                      <Button
                        type="button"
                        variant="primary"
                        shape="circle"
                        disabled
                        aria-hidden="true"
                        class="size-full"
                      >
                        <svg
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          stroke-width="2.5"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          class="size-[18px] max-md:size-5"
                          aria-hidden="true"
                        >
                          <path d="M12 19 V5.75" />
                          <path d="M6.5 10.5 L12 5 L17.5 10.5" />
                        </svg>
                      </Button>
                    </div>
                    <div
                      v-if="voiceInputEnabled"
                      class="absolute inset-0 transition-[opacity,scale] duration-[188ms] ease-[ease] motion-reduce:transition-none"
                      :class="inactiveSlotVisible ? 'scale-100 opacity-100' : 'pointer-events-none scale-70 opacity-0'"
                    >
                      <Button
                        type="button"
                        variant="primary"
                        shape="circle"
                        :disabled="voiceInputDisabled"
                        :title="voiceInputLabel"
                        :aria-label="voiceInputLabel"
                        class="size-full"
                        @click="handleVoiceInput"
                      >
                        <!-- Rendered only while idle (the v-else of the
                             recording/transcribing bar), so the glyph has no
                             busy states of its own. -->
                        <svg
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          stroke-width="2.5"
                          stroke-linecap="round"
                          class="size-4.5 max-md:size-5"
                          aria-hidden="true"
                        >
                          <!-- Relaxed envelope: the center bar spans only 14 of
                               the 24 viewBox units — the full-18 spike made the
                               glyph read tense. Ends are vertical ovals
                               (2.5 × 3.5 — a hair taller than pure circles), mids
                               hold half the max (7). The 4.5-unit gaps are
                               untouched: denser spacing smudges at this size. -->
                          <path d="M3 11.5v1" />
                          <path d="M7.5 8.5v7" />
                          <path d="M12 5v14" />
                          <path d="M16.5 8.5v7" />
                          <path d="M21 11.5v1" />
                        </svg>
                      </Button>
                    </div>
                    <!-- One control: a draft sends to the existing queue;
                         only an empty running composer offers stop. -->
                    <div
                      class="absolute inset-0 [transition:opacity_150ms_ease,scale_281ms_cubic-bezier(0.34,1.56,0.64,1)] motion-reduce:transition-none"
                      :class="sendButtonVisible ? 'scale-100 opacity-100' : 'pointer-events-none scale-0 opacity-0'"
                    >
                      <Button
                        type="button"
                        variant="brand"
                        shape="circle"
                        :disabled="attachmentUploading || nativeAttachmentBusy || !currentBotId || activeChatReadOnly || loadingMessages || (streaming ? showSend && (pendingFiles.length > 0 || pendingNativeAttachments.length > 0 || requestedSkills.length > 0) : !showSend || composerConfigPending || composerHasNoModel || goalSubmissionBlocked || !!runtimeModeUnavailableReason)"
                        :title="goalSubmissionBlocked ? goalExecutionBlockedReason : undefined"
                        :class="runtimeModeChanging && !streaming && showSend && !!currentBotId && !activeChatReadOnly && !loadingMessages && !composerAgentConfigPending && !composerHasNoModel ? 'disabled:opacity-100' : undefined"
                        :aria-busy="firstSendAwaiting || attachmentUploading || undefined"
                        :aria-label="streaming && showSend ? $t(composerQueueCommand?.mode === 'steer' ? 'chat.queue.enqueueSteer' : 'chat.queue.enqueueFollowUp') : $t(streaming ? 'chat.stopGenerating' : 'chat.send')"
                        class="size-full"
                        @keydown.enter="$event.repeat && $event.preventDefault()"
                        @click="handleSendButton"
                      >
                        <span
                          class="grid size-[18px] max-md:size-5 shrink-0 place-items-center"
                          aria-hidden="true"
                        >
                          <!-- The arrow, which bends into the busy ring while a
                               first send waits for the server. -->
                          <SendMorphIcon
                            :busy="firstSendAwaiting || attachmentUploading"
                            class="col-start-1 row-start-1 size-[18px] max-md:size-5 transition-opacity duration-200 ease-out motion-reduce:transition-none"
                            :class="streaming && !showSend && !firstSendAwaiting ? 'opacity-0' : 'opacity-100'"
                          />
                          <svg
                            viewBox="0 0 24 24"
                            fill="currentColor"
                            class="col-start-1 row-start-1 size-4 max-md:size-4.5 transition-opacity duration-200 ease-out motion-reduce:transition-none"
                            :class="streaming && !showSend && !firstSendAwaiting ? 'opacity-100' : 'opacity-0'"
                          >
                            <rect
                              x="4"
                              y="4"
                              width="16"
                              height="16"
                              rx="3"
                            />
                          </svg>
                        </span>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Session controls sit outside the input surface as bare text
                 triggers — no chrome at rest, the label itself shifts
                 muted→foreground on hover (Button variant="quiet"). Order:
                 Computer → Folder (+ branch) → Agent → Permission →
                 mode pills, with the context-pressure ring pinned right.
                 Keep this row's height while recording so the dock stays
                 stable. -->
              <div
                v-if="readAloud.state.value.status !== 'idle' && readAloud.state.value.status !== 'error'"
                class="pointer-events-auto flex items-center gap-2 px-2"
                role="status"
              >
                <TextButton
                  v-if="readAloud.state.value.status === 'blocked' || readAloud.state.value.status === 'paused'"
                  @click="readAloud.resume()"
                >
                  {{ $t(readAloud.state.value.status === 'blocked' ? 'chat.readAloud.enable' : 'chat.readAloud.resume') }}
                </TextButton>
                <TextButton @click="readAloud.stop()">
                  {{ $t('chat.readAloud.stop') }}
                </TextButton>
              </div>
              <p
                v-else-if="readAloud.state.value.status === 'error'"
                class="px-2 text-caption text-muted-foreground"
                role="status"
              >
                {{ $t('chat.readAloud.failed') }}
              </p>
              <div
                data-composer-context-row
                class="flex min-w-0 items-center gap-1 px-2"
                :class="isWelcome
                  ? 'mt-1 min-h-10 max-md:min-h-12'
                  : 'min-h-10.5 max-md:min-h-13.5'"
              >
                <!-- Labels shrink first; extra active controls remain reachable by scrolling. -->
                <div class="flex min-w-0 flex-1 items-center gap-1 overflow-x-auto">
                  <ComposerContinueOn
                    v-if="showComputersMenu && voiceInputState === 'idle'"
                    trigger="text"
                    :targets="workspaceTargets"
                    :selected-target-id="composerComputerTargetId"
                    :selected-missing="composerComputerTargetMissing"
                    :selected-snapshot-name="composerComputerSnapshotName"
                    :locked="computerSwitchLocked"
                    :bound-to-folder="composerFolderLocked"
                    :initial-loading="workspaceTargetsInitialLoading"
                    :load-failed="workspaceTargetsLoadFailed"
                    :bot-id="currentBotId ?? ''"
                    :bot-name="currentBot?.display_name || currentBot?.name || ''"
                    @select="selectWorkspaceTarget"
                    @menu-open="refetchWorkspaceTargets"
                  />

                  <ComposerFolderMenu
                    v-if="voiceInputState === 'idle' && (composerFolderPickable || composerFolderLocked || activeUsesDirectRuntime)"
                    :bot-id="currentBotId || ''"
                    :project="runtimeProject"
                    :projects="selectableFolders"
                    :editable="draftSetupEditable"
                    :locked="computerSwitchLocked || composerConfigPending || !canWorkspaceRead"
                    :visible="isVisible && canWorkspaceRead"
                    :streaming="streaming"
                    :git-branches="activeUsesDirectRuntime"
                    :pickable="composerFolderPickable"
                    :locked-folder="composerFolderLocked"
                    :folder-name="composerFolderName"
                    :can-execute="hasBotPermission(currentBot?.current_user_permissions, 'workspace_exec')"
                    @select="selectWorkingFolder"
                    @clear="clearWorkingFolder"
                  />

                  <DropdownMenu
                    v-if="!hasRenderedSession && (enabledBotAgents.length || canAddAgent) && voiceInputState === 'idle'"
                    v-model:open="agentPopoverOpen"
                  >
                    <DropdownMenuTrigger as-child>
                      <Button
                        type="button"
                        variant="quiet"
                        size="sm"
                        :disabled="!canChangeAgent"
                        :class="runtimeModeChanging ? 'disabled:opacity-100' : undefined"
                        :title="composerAgentName"
                        :aria-label="$t('chat.agent') + ': ' + composerAgentName"
                        class="min-w-14 shrink max-w-60 gap-1.5 px-1.5 font-normal max-md:h-11"
                      >
                        <component
                          :is="composerAgentIcon"
                          class="size-3.5 shrink-0"
                          aria-hidden="true"
                        />
                        <span class="truncate text-label">{{ composerAgentName }}</span>
                        <ChevronDown class="size-3 shrink-0 opacity-70" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent
                      align="start"
                      side="bottom"
                      :side-offset="0"
                      class="w-56"
                    >
                      <DropdownMenuLabel>{{ $t('chat.agent') }}</DropdownMenuLabel>
                      <DropdownMenuItem
                        @mouseenter="hoveredAgentChoice = 'memoh'"
                        @mouseleave="hoveredAgentChoice = ''"
                        @select="selectMemohAgent"
                      >
                        <component
                          :is="!activeUsesExternalAgentComposer || hoveredAgentChoice === 'memoh' ? MemohColor : MemohIcon"
                          class="size-4 shrink-0 text-muted-foreground"
                          aria-hidden="true"
                        />
                        <span class="min-w-0 flex-1 truncate">{{ $t('chat.agentMemoh') }}</span>
                        <Check
                          v-if="!activeUsesExternalAgentComposer"
                          class="ml-auto"
                        />
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        v-for="agent in enabledBotAgents"
                        :key="agent.id"
                        @mouseenter="hoveredAgentChoice = agent.id || ''"
                        @mouseleave="hoveredAgentChoice = ''"
                        @select="selectBotAgent(agent)"
                      >
                        <component
                          :is="botAgentIcon(agent, activeBotAgentID === agent.id || hoveredAgentChoice === agent.id)"
                          class="size-4 shrink-0 text-muted-foreground"
                        />
                        <span class="min-w-0 flex-1 truncate">{{ botAgentName(agent) }}</span>
                        <Check
                          v-if="activeBotAgentID === agent.id"
                          class="ml-auto"
                        />
                      </DropdownMenuItem>
                      <template v-if="canAddAgent">
                        <DropdownMenuSeparator />
                        <DropdownMenuItem @select="openAgentSettings(true)">
                          <AddIcon />
                          {{ $t('bots.agent.add') }}
                        </DropdownMenuItem>
                      </template>
                    </DropdownMenuContent>
                  </DropdownMenu>
                  <span
                    v-else-if="hasRenderedSession && voiceInputState === 'idle'"
                    class="inline-flex h-8 min-w-0 max-w-60 items-center gap-1.5 px-1.5 text-label font-normal text-muted-foreground max-md:h-11"
                    :title="composerAgentName"
                    :aria-label="$t('chat.agent') + ': ' + composerAgentName"
                  >
                    <component
                      :is="composerAgentIcon"
                      class="size-3.5 shrink-0"
                      aria-hidden="true"
                    />
                    <span class="truncate">{{ composerAgentName }}</span>
                  </span>

                  <DropdownMenu v-if="runtimeModes.length && voiceInputState === 'idle'">
                    <DropdownMenuTrigger as-child>
                      <Button
                        variant="quiet"
                        size="sm"
                        :disabled="runtimeModeDisabled"
                        :class="runtimeModeChanging ? 'disabled:opacity-100' : undefined"
                        class="min-w-14 shrink max-w-48 gap-1.5 px-1.5 font-normal max-md:h-11"
                        :title="currentRuntimeMode?.name || currentRuntimeModeId"
                        :aria-label="runtimeModeLabel + ': ' + (currentRuntimeMode?.name || currentRuntimeModeId)"
                      >
                        <RuntimeModeIcon
                          :icon="currentRuntimeMode?.icon"
                          :warning="currentRuntimeMode?.warning"
                          class="size-3.5"
                        />
                        <span
                          class="truncate text-label"
                          :class="currentRuntimeMode?.warning ? 'text-warning-foreground' : undefined"
                        >{{ currentRuntimeMode?.name || currentRuntimeModeId }}</span>
                        <ChevronDown class="size-3 shrink-0 opacity-70" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent
                      align="start"
                      side="bottom"
                      :side-offset="0"
                      :collision-padding="16"
                      class="w-80 max-w-[calc(100vw-2rem)] sm:w-md"
                    >
                      <DropdownMenuLabel class="text-label font-normal">
                        {{ runtimeModeLabel }}
                        <span
                          v-if="runtimeControlSnapshot?.modes?.apply_on_next_turn"
                          class="block whitespace-normal text-caption font-normal text-muted-foreground"
                        >{{ $t('chat.runtimeModeNextTurn') }}</span>
                      </DropdownMenuLabel>
                      <DropdownMenuItem
                        v-for="mode in runtimeModes"
                        :key="mode.id"
                        class="py-1 max-md:py-1.5"
                        :disabled="runtimeModeDisabled || unavailableRuntimeModes.includes(mode.id ?? '')"
                        @select="onRuntimeModeSelected(mode.id)"
                      >
                        <RuntimeModeIcon
                          :icon="mode.icon"
                          :warning="mode.warning"
                        />
                        <span
                          class="min-w-0 flex-1"
                          :class="mode.warning ? 'text-warning-foreground' : undefined"
                        >
                          <span class="block text-label">{{ mode.name || mode.id }}</span>
                          <span
                            v-if="mode.description"
                            class="block whitespace-normal text-body"
                            :class="mode.warning ? 'text-warning-foreground' : 'text-muted-foreground'"
                          >{{ unavailableRuntimeModes.includes(mode.id ?? '') ? $t('chat.runtimeModeModelUnavailable') : mode.description }}</span>
                        </span>
                        <Check v-if="mode.id === currentRuntimeModeId" />
                      </DropdownMenuItem>
                      <template v-if="planModeSupported || goalCommandAvailable">
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          v-if="planModeSupported"
                          :disabled="runtimeModeDisabled"
                          @select="togglePlanMode"
                        >
                          <Lightbulb />
                          <span class="min-w-0 flex-1 truncate">{{ $t(planModeEnabled ? 'chat.planMode.disable' : 'chat.planMode.enable') }}</span>
                          <Check v-if="planModeEnabled" />
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          v-if="goalCommandAvailable"
                          :disabled="runtimeModeDisabled || !!goalExecutionBlockedReason"
                          :title="goalExecutionBlockedReason"
                          @select="goalDraftScope = goalDraftEnabled ? '' : runtimeModeScope"
                        >
                          <Target />
                          <span class="min-w-0 flex-1 truncate">{{ $t(goalDraftEnabled ? 'chat.goal.cancelDraft' : 'chat.goal.description') }}</span>
                          <Check v-if="goalDraftEnabled" />
                        </DropdownMenuItem>
                      </template>
                    </DropdownMenuContent>
                  </DropdownMenu>

                  <Button
                    v-if="planModeEnabled && voiceInputState === 'idle'"
                    variant="quiet"
                    size="sm"
                    class="shrink-0 gap-1.5 px-1.5 font-normal max-md:h-11"
                    :disabled="runtimeModeDisabled"
                    :aria-label="$t('chat.planMode.disable')"
                    :title="$t('chat.planMode.disable')"
                    @click="togglePlanMode"
                  >
                    <Lightbulb class="size-3.5" />
                    <span class="text-label">{{ $t('chat.planMode.label') }}</span>
                    <X
                      class="size-3"
                      aria-hidden="true"
                    />
                  </Button>
                  <Button
                    v-if="goalDraftEnabled && voiceInputState === 'idle'"
                    variant="quiet"
                    size="sm"
                    class="shrink-0 gap-1.5 px-1.5 font-normal max-md:h-11"
                    :disabled="runtimeModeDisabled"
                    :aria-label="$t('chat.goal.cancelDraft')"
                    :title="$t('chat.goal.cancelDraft')"
                    @click="goalDraftScope = ''"
                  >
                    <Target class="size-3.5" />
                    <span class="text-label">{{ $t('chat.goal.label') }}</span>
                    <X
                      class="size-3"
                      aria-hidden="true"
                    />
                  </Button>
                </div>

                <!-- Brings back the hidden welcome suggestions. It lives on this
                     row so it lines up with the other session controls, in
                     the slot the context ring takes once a chat starts. -->
                <Button
                  v-if="isWelcome && welcomeDismissed && voiceInputState === 'idle'"
                  type="button"
                  variant="quiet"
                  size="sm"
                  class="ml-auto shrink-0 gap-1.5 px-1.5 font-normal max-md:h-11"
                  @click="welcomeDismissed = false"
                >
                  <Lightbulb class="size-3.5 shrink-0" />
                  <span class="text-label">{{ $t('chatExamples.tryThese') }}</span>
                </Button>
                <BotTaskDirectory
                  v-if="currentBotId && voiceInputState === 'idle'"
                  :bot-id="currentBotId"
                  :visible="isVisible"
                />
                <template v-if="currentBotId && activeSessionId && !isWelcome && voiceInputState === 'idle'">
                  <SessionActivityTrigger
                    kind="bots"
                    :bot-id="currentBotId"
                    :session-id="activeSessionId"
                    :visible="isVisible"
                  />
                </template>
                <SessionInfoRing
                  v-if="showSessionInfoRing && voiceInputState === 'idle'"
                  class="ml-auto shrink-0"
                  :visible="isVisible"
                  :override-model-id="overrideModelId"
                  :fallback-context-window="sessionFallbackContextWindow"
                />
              </div>
            </ComposerDock>
          </div>
          <!-- Usage examples under the welcome composer; they yield first
               when the pane is short (style.css welcome tiers). -->
          <ChatExampleSuggestions
            v-if="isWelcome && currentBotId"
            v-model:preview="composerPreview"
            :bot-id="currentBotId"
            :composer-replaceable="composerReplaceable"
          />
        </div>
      </div>
    </template>

    <!-- Region-scoped drop feedback. Sits OUTSIDE the v-else so it can also
         cover the "pick a bot" placeholder — where the zone is disabled, so the
         overlay stays dark and the OS shows its no-drop cursor instead of the
         drop silently doing nothing. Dropped files land in the attachment tray,
         unsent: the user still gets to type the message that goes with them. -->
    <FileDropOverlay
      :active="dropActive"
      :bounds="dropBounds"
      :icon="ImagePlus"
      :label="$t('chat.dropToAttach')"
    />
  </div>
</template>

<script setup lang="ts">
import { Memoh as MemohIcon, MemohColor } from '@memohai/icon'
import { AddIcon, UploadIcon } from '@memohai/icon/ui'

import { EXTERNAL_AGENT_DEFAULT_PROJECT_MODE, EXTERNAL_AGENT_DEFAULT_PROJECT_PATH, normalizeAgentID } from '@/utils/external-agent'
import { ref, shallowRef, reactive, computed, onBeforeUnmount, useTemplateRef, watch, onWatcherCleanup, nextTick, onActivated, onDeactivated } from 'vue'
import {
  ImagePlus,
  ChevronDown,
  ArrowDown,
  Check,
  Sparkles,
  X,
  HelpCircle,
  List,
  Package,
  SquarePen,
  ShieldCheck,
  Lightbulb,
  Target,
} from 'lucide-vue-next'
import { Button, ContextMenu, ContextMenuTrigger, ContextMenuContent, ContextMenuItem, Command, CommandGroup, CommandItem, CommandKeyBridge, CommandList, CommandSeparator, ConfirmDeleteDialog, Dialog, DialogContent, DialogHeader, DialogTitle, DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger, InlineLoadingRow, PanePlaceholder, ScrollArea, Skeleton, Spinner, TextButton, toast } from '@felinic/ui'
import { useChatStore, type ExternalAgentSessionInput, type ChatMessage, type ChatWorkspaceTargetSnapshot, type SendMessageResult } from '@/store/chat-list'
import { useWorkdirsStore } from '@/store/workdirs'
import type { BotWorkdir } from '@/composables/api/useWorkdirs'
import { useWorkspaceTabsStore } from '@/store/workspace-tabs'
import { storeToRefs } from 'pinia'
import { useElementSize, useIntersectionObserver, useLocalStorage } from '@vueuse/core'
import { useRuntimeControls } from '@/composables/useRuntimeControls'
import { useCodexUsage } from '@/composables/useCodexUsage'
import { codexUsageNotice, codexUsageNoticeKey, codexUsageResetTime, codexUsageWindowLabel } from '@/utils/codex-usage'
import { useQuery } from '@pinia/colada'
import { getAcpProfiles, getBotsByBotIdAgents, getBotsByBotIdSettings, getBotsByBotIdWorkspaceTargets, postTranscriptionModelsByIdTest } from '@memohai/sdk'
import type { AcpprofilePublicProfile, BotagentsBotAgent, WorkspaceWorkspaceTarget } from '@memohai/sdk'
import { useI18n } from 'vue-i18n'
import { useRouter } from 'vue-router'
import FileDropOverlay from '@/components/file-drop-overlay/index.vue'
import { useFileDropZone } from '@/composables/useFileDropZone'
import { registerChatFileDropTarget } from '../composables/chat-file-drop-target'
import { readDroppedFiles } from '@/utils/dropped-files'
import MessageItem from './message-item.vue'
import { useChatReadAloud } from '../composables/useChatReadAloud'
import ComposerContinueOn from './composer-continue-on.vue'
import ComposerConnectorsMenu from './composer-connectors-menu.vue'
import RuntimeModeIcon from './runtime-mode-icon.vue'
import ComposerFolderMenu from './composer-folder-menu.vue'
import CodexGoalBar from './codex-goal-bar.vue'
import ChatAttachmentCard from './chat-attachment-card.vue'
import { useChatScroll } from '../composables/useChatScroll'
import { useComposerPlacementMotion } from '../composables/useComposerPlacementMotion'
import { useQueueTurnAnchors } from '../composables/useQueueTurnAnchors'
import { isRuntimeContinuationUserTurn, isRuntimeSteerUserTurn } from '@/store/chat/types'
import { resolveCommandErrorMessage } from '@/store/chat/messages'
import { isAgentRuntimeType } from '@/store/chat-list.utils'
import BgTaskPill from './bg-task-pill.vue'
import BotTaskDirectory from './bot-task-directory.vue'
import { runtimeFailureAlreadyVisible, watchVisibleComposerFailure } from './composer-error'
import ForkSourceDivider from './fork-source-divider.vue'
import ChatForkDialog from './chat-fork-dialog.vue'
import ComposerDock from './composer-dock.vue'
import SessionFollowUpQueue from './session-follow-up-queue.vue'
import { usePendingApprovals } from '../composables/usePendingApprovals'
import ChatScrollRail, { type ScrollRailSegment } from './chat-scroll-rail.vue'
import { provideBgTaskBeacons } from '../composables/useBgTaskBeacons'
import MediaGalleryLightbox from './media-gallery-lightbox.vue'
import SessionInfoRing from './session-info-ring.vue'
import SessionActivityTrigger from '@/components/sidebar/session-activity-trigger.vue'
import { useSessionInfo } from '../composables/useSessionInfo'
import ComposerModelMenu from './composer-model-menu.vue'
import { EFFORT_LABELS, REASONING_EFFORT_DISABLE, displayedEffort, reconcileStoredEffort } from '@/pages/bots/components/reasoning-effort'
import { useMediaGallery } from '../composables/useMediaGallery'
import { prepareSubmission } from '@/lib/harmony-files'
import HarmonyAttachments from '@/lib/HarmonyAttachments.vue'
import { nativeAttachmentsAvailable, type NativeAttachment } from '@/lib/harmony-resumable'
import { nativeVoiceAvailable, type VoiceSubmission } from '@/lib/harmony-voice'
import HarmonyVoiceInput from '@/lib/HarmonyVoiceInput.vue'
import HarmonyVoicePlayer from '@/lib/HarmonyVoicePlayer.vue'
import { ATTACHMENT_ANIM_MS, attachmentToFile, useComposerAttachments } from '../composables/useComposerAttachments'

import { useComposerDrafts } from '../composables/useComposerDrafts'
import ChatExampleSuggestions from './chat-example-suggestions.vue'
import { useChatExamplesUi } from '@/components/chat-examples/use-chat-examples-ui'
import { useComposerPrefillConsumer } from '../composables/useComposerPrefillConsumer'
import { useComposerPreviewBox, type ComposerPreview } from '../composables/useComposerPreview'
import { useAsyncConfirm } from '@/composables/useAsyncConfirm'
import { useUnfocusedComposerInput } from '../composables/useUnfocusedComposerInput'
import { useComposerKeyboardFocus } from '../composables/useComposerKeyboardFocus'
import { useComposerPair } from '../composables/useComposerPair'
import { COMPOSER_MASK_BELOW_PX, useComposerLayout } from '../composables/useComposerLayout'
import { provideChatViewTarget } from '../composables/useChatViewContext'
import { provideConnectorLogos } from '../composables/useConnectorLogos'
import { enqueueSteerQueue, enqueueFollowUpQueue, fetchSafeSkillCatalog, fetchSession, type CommandActionListItem, type CommandEventResponse, type RequestedSkillSelection, type UIUserInput } from '@/composables/api/useChat'
import { parseSessionQueueCommand, SessionQueueSubmissionGate } from './session-queue-submission'
import { localizeRuntimeControls, localizeRuntimeCommandResult } from '@/utils/runtime-control-presentation'
import { commandResultPresentation, isCommandResultItemVisible, resolveCommandResultSelection } from './slash-command-result'
import SendMorphIcon from './send-morph-icon.vue'
import { captureChatPaneSendContext, clearComposerPairDraft, composerRestoreForSendResult, composerHasNoModel as hasNoComposerModel, matchesChatPaneSendContext, pinnedSubagentModelId as resolvePinnedSubagentModelId, shouldRefreshACPComposerConfig, welcomeSendConsumedDraft } from './chat-pane-send'
import { onAuthSessionCleared } from '@/lib/auth-session'
import { useACPRuntime } from '@/composables/useACPRuntime'
import { useAgentModelCatalog } from '@/composables/useAgentModelCatalog'
import { useModelSelectionLabel } from '@/composables/useModelSelectionLabel'
import { useVirtualKeyboard } from '@/composables/useVirtualKeyboard'
import { isACPAgentConfigured } from '@/utils/acp'
import { BOT_AGENT_RUNTIME_ACP, BOT_AGENT_RUNTIME_CODEX, botAgentIcon, botAgentName, botAgentProvider, isDirectBotAgentConfigured, isDirectBotAgentRuntime, normalizeBotAgentRuntime } from '@/utils/bot-agent'
import { UserFacingError, isApiErrorCode, parseMemohError, resolveApiErrorMessage } from '@/utils/api-error'
import { hasBotPermission } from '@/utils/bot-permissions'
import { workspaceTargetAvailable } from '@/utils/workspace-target'
import { findLatestPendingChatDecision } from './chat-pending-decision'
import { useTaskRunAnchor } from '../composables/useTaskRunAnchor'
import type { TaskHistoryAnchor } from '@/utils/task-history-link'
import { revalidateTaskHistoryAnchor } from '@/utils/task-history-link'
import {
  runtimeCommandComposerText,
  composerLocalQuickActionID,
  visibleRuntimeCommands,
  type RuntimeCommand,
} from '@/utils/runtime-slash-commands'

const props = withDefaults(defineProps<{
  // Stable dockview panel id (e.g. `chat:3`). Used for per-tab composer drafts and
  // the keep-alive key — it does NOT change when a draft acquires a real session.
  tabId?: string
  // The session this pane renders (null = unsaved draft). Decoupled from tabId so
  // a draft→real promotion never remounts this pane.
  sessionId?: string | null
  // Presentation intent from the resolved contact entry, scoped to this pane.
  // Task/history panes keep the unabridged transcript for the same session.
  contactView?: boolean
  taskAnchor?: TaskHistoryAnchor
  visible?: boolean
  active?: boolean
}>(), {
  tabId: 'chat',
  sessionId: null,
  contactView: false,
  taskAnchor: undefined,
  visible: true,
  active: true,
})

const harmonyPhotoInput = ref<HTMLInputElement>()
const harmonyAttachmentPicker = ref<InstanceType<typeof HarmonyAttachments>>()
const pendingNativeAttachments = ref<NativeAttachment[]>([])
const nativeAttachmentScope = computed(() => paneTarget.value.sessionId
  ? 'session:' + paneTarget.value.sessionId : 'draft:' + paneTarget.value.viewId)
const nativeAttachmentBusy = computed(() => !!harmonyAttachmentPicker.value?.busy)
const { t, te, locale } = useI18n()
const runtimeText = (key: string, fallback: string) => te(key) || te(key, 'en') ? t(key) : fallback
const router = useRouter()
const chatStore = useChatStore()
const workspaceTabs = useWorkspaceTabsStore()
const { pill: bgTaskPill, scrollToOffscreen, cleanup: cleanupBgTaskBeacons } = provideBgTaskBeacons()
onBeforeUnmount(cleanupBgTaskBeacons)
const {
  fileInput,
  pendingFiles,
  pendingPreviews,
  composerPreviewItems,
  composerPreviewIndex,
  composerPreviewOrigin,
  openComposerPreview,
  pastedViewerText,
  pastedViewerOpen,
  showAttachmentGrid,
  removeAttachment: removePendingAttachment,
  handleFileInputChange,
  handlePaste,
} = useComposerAttachments()
let preparingView: ReturnType<typeof chatStore.chatView> | undefined
let attachmentPreparationCancelled = false
const attachmentUploading = computed(() => !!paneView.value.attachmentPreparation.value)
function cancelAttachmentUpload() {
  const controller = preparingView?.attachmentPreparation.value
  if (controller) { attachmentPreparationCancelled = true; controller.abort() }
}
onBeforeUnmount(cancelAttachmentUpload)
function removeAttachment(index: number) {
  // The last card's visual collapse delays removal from pendingFiles.
  // Abort immediately, before that animation can race upload completion.
  cancelAttachmentUpload()
  removePendingAttachment(index)
}

const composerErrorText = ref('')
const composerFailure = shallowRef<SendMessageResult>()
const composerError = computed({
  get: () => composerErrorText.value,
  set: (value: string) => { composerErrorText.value = value; composerFailure.value = undefined },
})
function setComposerFailure(failure: Pick<SendMessageResult, 'error' | 'errorCode' | 'errorTurnId' | 'errorRunId'>) {
  composerError.value = failure.error || ''
  composerFailure.value = { ok: false, ...failure }
}
const forkDialogOpen = ref(false)
const pendingForkTurnId = ref('')
const modelPopoverOpen = ref(false)
const agentPopoverOpen = ref(false)
const hoveredAgentChoice = ref('')
watch(agentPopoverOpen, (open) => {
  if (!open) hoveredAgentChoice.value = ''
})
const agentChanging = ref(false)
const acpConfigChangeScope = ref('')

const {
  bots,
  loadingChats,
  hasExplicitSessionSelection,
} = storeToRefs(chatStore)
// The keyed panel owns this Bot until disposal; Dockview may flush child
// watchers after global selection changes but before removing the old pane.
const currentBotId = ref(chatStore.currentBotId)

const isActive = computed(() => props.active !== false)
const { welcomeDismissed } = useChatExamplesUi()
const isVisible = computed(() => props.visible !== false)
const paneTarget = computed(() => ({
  botId: currentBotId.value?.trim() ?? '',
  sessionId: props.sessionId?.trim() || null,
  viewId: props.tabId.trim() || 'chat',
}))
provideChatViewTarget(paneTarget)
// Resolved once per pane so every tool row below can mark a Connect-It call
// with its connector's logo without each row running its own lookup.
provideConnectorLogos(paneTarget)
const paneView = computed(() => chatStore.chatView(paneTarget.value))
const attachmentPreparing = computed(() => !!paneView.value.attachmentPreparation.value)
const messages = computed(() => paneView.value.transcript.visibleMessages.value)
const loadingMessages = computed(() => paneView.value.transcript.loadingMessages.value)
// Delayed skeleton reveal: local/fast loads finish within a few frames, and
// flashing the placeholder for a frame or two reads as a glitch. Mount it
// only when loading actually outlives the delay.
const skeletonVisible = ref(false)
watch(() => messages.value.length === 0 && loadingMessages.value, (pending, _prev, onCleanup) => {
  if (!pending) {
    skeletonVisible.value = false
    return
  }
  const timer = setTimeout(() => { skeletonVisible.value = true }, CHAT_SKELETON_REVEAL_DELAY_MS)
  onCleanup(() => clearTimeout(timer))
}, { immediate: true })
const loadingOlder = computed(() => paneView.value.transcript.loadingOlder.value)
const hasMoreOlder = computed(() => paneView.value.transcript.hasMoreOlder.value)
const streaming = computed(() => chatStore.isChatViewStreaming(paneTarget.value))
const creatingSession = computed(() => chatStore.isChatViewCreatingSession(paneTarget.value))
const activeChatTarget = computed(() => chatStore.chatTargetFor(paneTarget.value))
const activeSession = computed(() => activeChatTarget.value.session)
const activeChatReadOnly = computed(() => chatStore.chatReadOnlyFor(paneTarget.value))
const activeChatCanFork = computed(() => chatStore.chatCanForkFor(paneTarget.value))
// The composer pair lives on the shared ChatViewEntry: same-session tabs share
// one pair and repointing this pane swaps in the target view's own pair. Every
// rule that changes it is in useComposerPair (registered below, once its
// inputs exist); these accessors only bridge it to the template.
const overrideModelId = computed({
  get: () => paneView.value.pairModelId.value,
  set: (value: string) => { paneView.value.pairModelId.value = value },
})
const overrideReasoningEffort = computed({
  get: () => paneView.value.pairEffort.value,
  set: (value: string) => { paneView.value.pairEffort.value = value },
})

// Session creation briefly changes several pieces of the direct-runtime
// identity. That is one draft being promoted, not a switch to another chat.
let directDraftPromotionPending = false
const paneComposerScope = computed(() => {
  const botId = paneTarget.value.botId
  return botId ? `${botId}:${paneTarget.value.viewId}` : 'chat'
})
const startupSendFailure = computed(() => chatStore.startupSendFailureFor(
  paneTarget.value,
  paneComposerScope.value,
))
const hasRenderedSession = computed(() =>
  !!(paneTarget.value.sessionId || activeChatTarget.value.sessionId || '').trim(),
)
// The first message sent from this pane's draft, from Enter until it is an
// ordinary session (or failed). The store owns the phase; the pane only reads
// it. It is keyed by the pane's view id, so it outlives the draft -> session
// repoint.
const firstSendEntry = computed(() => chatStore.firstSendFor(paneTarget.value))
// From Enter on a draft until the server confirms the send. The pane stays on
// welcome with the input in a locked composer. draftSendStarting covers the
// part before the store has registered the send (attachment encoding, an
// External Agent's REST session creation).
const draftSendStarting = ref(false)
const firstSendAwaiting = computed(() =>
  draftSendStarting.value || (!!firstSendEntry.value && !firstSendEntry.value.revealed))
// A draft whose first message is in flight is committed to its setup (the
// folder travels with that message), even before a session id exists.
const draftSetupEditable = computed(() => !hasRenderedSession.value && !firstSendEntry.value && !draftSendStarting.value)

// A fresh, writable chat opens with the composer centred and a greeting above
// it. Read-only sessions (system / synced channel threads) hide the composer
// entirely, so they never reach this state. A first send stays on welcome
// until the server confirms it; from then on the pane is a chat even before
// a turn has rendered (a skill activation appends none of its own).
const isWelcome = computed(() => {
  if (!currentBotId.value || activeChatReadOnly.value || loadingChats.value) return false
  if (firstSendEntry.value?.revealed) return false
  return !hasRenderedSession.value && messages.value.length === 0
})

// During boot, "a draft that stays a draft" and "a draft about to be
// repointed to the most recent session" are indistinguishable until
// fetchSessions returns (bootstrap auto-picks at the END of the load).
// isWelcome waits out that window via !loadingChats — but rendering the
// docked posture meanwhile made a hard refresh of the welcome page flash
// bottom → center. While placement is undecidable, hide the composer
// instead: `invisible` keeps layout and the dock measurements alive,
// where v-if would unmount them. A session panel carries its sessionId
// from the first frame, so this gate never engages on session routes.
const composerPlacementPending = computed(() => loadingChats.value && !hasRenderedSession.value)
const composerPlacementEl = useTemplateRef<HTMLElement>('composerPlacementEl')
// Only a first send moves the composer, out of welcome when the server
// confirms it, together with the turns appearing. Any other flip is
// navigation, and the composer just lands with the rest of the pane.
useComposerPlacementMotion(composerPlacementEl, isWelcome, () => !!firstSendEntry.value?.revealed)

// Rotate the greeting per fresh chat so the entry point feels alive rather than
// a fixed banner; the pick stays stable while a single welcome screen is shown
// and re-rolls when a new empty chat (bot/session) is opened.
const WELCOME_GREETING_KEYS = [
  'chat.welcome.g1', 'chat.welcome.g2', 'chat.welcome.g3', 'chat.welcome.g4',
  'chat.welcome.g5', 'chat.welcome.g6', 'chat.welcome.g7', 'chat.welcome.g8',
  'chat.welcome.g9', 'chat.welcome.g10', 'chat.welcome.g11', 'chat.welcome.g12',
] as const

// Arkloop ChatSkeleton's width sequence, verbatim — percentages of the column,
// so they scale with Memoh's layout; heights/pitches above are derived from
// Memoh's own chat metrics, not copied.
const CHAT_SKELETON_BAR_WIDTHS = ['85%', '65%', '90%', '55%', '75%', '60%', '80%', '50%', '70%', '40%'] as const
// Loading shorter than this never shows the placeholder at all.
const CHAT_SKELETON_REVEAL_DELAY_MS = 200
function pickWelcomeGreetingIndex() {
  return Math.floor(Math.random() * WELCOME_GREETING_KEYS.length)
}
const welcomeGreetingIndex = ref(pickWelcomeGreetingIndex())
const welcomeGreeting = computed(() => {
  // A draft under a working folder names its destination instead of the
  // generic rotation — the greeting doubles as the binding's visibility.
  const folderName = draftWorkingFolder.value?.name?.trim()
  if (folderName) return t('chat.welcome.folder', { name: folderName })
  return t(WELCOME_GREETING_KEYS[welcomeGreetingIndex.value] ?? WELCOME_GREETING_KEYS[0])
})
watch([isWelcome, currentBotId, () => activeSession.value?.id], ([welcome]) => {
  // A first send that failed before confirmation never left this welcome, so
  // the greeting stays: its failure is still on screen with the input.
  if (welcome && !startupSendFailure.value) welcomeGreetingIndex.value = pickWelcomeGreetingIndex()
})

const pendingDecision = computed(() => findLatestPendingChatDecision(messages.value))
const pendingUserInput = computed<UIUserInput | null>(() => (
  pendingDecision.value?.kind === 'user_input'
    ? pendingDecision.value.userInput
    : null
))

const { items: pendingApprovals } = usePendingApprovals(messages)

const hasPendingToolApproval = computed(() => pendingApprovals.value.length > 0)

// A direct runtime's turn says itself whether it can anchor a fork
// (runtimeForkable, below): only turns whose runtime recorded an anchor can.
const canForkAssistant = computed(() =>
  !streaming.value
  && !loadingMessages.value
  && !activeChatReadOnly.value
  && activeChatCanFork.value
  && (activeChatTarget.value.runtimeType === 'model'
    || isDirectBotAgentRuntime(activeChatTarget.value.runtimeType)),
)

// A freshly committed turn can arrive before older history rows are refetched.
// Keep the latest-only policy effective across that live transition as well.
const latestRuntimeForkTurn = computed(() => messages.value.findLast(message =>
  message.role === 'assistant' && message.runtimeForkable === true,
))
function isForkableTurn(message: ChatMessage): boolean {
  return canForkAssistant.value && message.role === 'assistant'
    && (activeChatTarget.value.runtimeType === 'model' || message.runtimeForkable === true)
    && (!runtimeControls.controls.value?.capabilities?.fork_latest_only
      || message === latestRuntimeForkTurn.value)
}

// Retry/edit rewrite persisted history and replay it, which only runtimes
// whose context Memoh itself assembles can honor.
const activeSupportsTurnReplacement = computed(() => activeChatTarget.value.runtimeType === 'model')

// The turn id, not a message id: a turn carries it from admission, so the
// affordance is live the moment the round exists rather than after the
// database twin of that round has been fetched back.
const latestRetryableAssistantTurnId = computed(() => {
  if (streaming.value || loadingMessages.value || activeChatReadOnly.value) return ''
  if (!activeSupportsTurnReplacement.value) return ''
  for (let i = messages.value.length - 1; i >= 0; i--) {
    const message = messages.value[i]
    if (message?.role === 'assistant' && !message.streaming && !message.__optimistic) {
      return message.turnId?.trim() ?? ''
    }
  }
  return ''
})

const latestEditableUserTurnId = computed(() => {
  if (streaming.value || loadingMessages.value || activeChatReadOnly.value) return ''
  if (!activeSupportsTurnReplacement.value) return ''
  for (let i = messages.value.length - 1; i >= 0; i--) {
    const message = messages.value[i]
    if (message?.role === 'user' && !message.streaming && !message.__optimistic) {
      return message.turnId?.trim() ?? ''
    }
  }
  return ''
})

// Both halves of a round share one turn id, so the role decides which
// affordance a message gets: retry belongs to the reply, edit to the request.
function originalFailedRunId(message: ChatMessage): string | undefined {
  if (message.role !== 'assistant') return
  if (message.runtimeRunId) return message.runtimeRunId
  const observation = chatStore.runtimeObservationFor(currentBotId.value || '', activeSessionId.value || '')
  const run = observation.run
  return observation.synchronized && run?.status === 'errored' && !!message.turnId && run.turn_id === message.turnId ? run.run_id : undefined
}

function isRetryableTurn(message: ChatMessage): boolean {
  const turnId = latestRetryableAssistantTurnId.value
  return message.role === 'assistant' && turnId !== '' && turnId === (message.turnId?.trim() ?? '')
}

function isEditableTurn(message: ChatMessage): boolean {
  const turnId = latestEditableUserTurnId.value
  return message.role === 'user' && turnId !== '' && turnId === (message.turnId?.trim() ?? '')
}

const { data: botSettings, isLoading: botSettingsLoading } = useQuery({
  key: () => ['bot-settings', currentBotId.value],
  query: async () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data } = await (getBotsByBotIdSettings as any)({
      path: { bot_id: currentBotId.value! },
      throwOnError: true,
    })
    return data as import('@memohai/sdk').SettingsSettings | undefined
  },
  enabled: () => !!currentBotId.value,
})

const { data: acpProfileData, isLoading: acpProfilesLoading } = useQuery({
  key: () => ['acp-profiles'],
  query: async () => {
    const { data } = await getAcpProfiles({ throwOnError: true })
    return data
  },
})

const { data: botAgentData, isLoading: botAgentsLoading } = useQuery({
  key: () => ['bot-agents', currentBotId.value],
  query: async () => {
    const { data } = await getBotsByBotIdAgents({
      path: { bot_id: currentBotId.value! },
      throwOnError: true,
    })
    return data
  },
  enabled: () => !!currentBotId.value,
})

const currentBot = computed(() => bots.value.find(bot => bot.id === currentBotId.value) ?? null)
const canWorkspaceRead = computed(() => (
  hasBotPermission(currentBot.value?.current_user_permissions, 'workspace_read')
))

type ValidWorkspaceTarget = WorkspaceWorkspaceTarget & {
  target_id: string
  kind: string
}

const {
  data: workspaceTargetsResponse,
  error: workspaceTargetsError,
  isLoading: workspaceTargetsLoading,
  refetch: refetchWorkspaceTargets,
} = useQuery({
  key: () => ['bot-workspace-targets', currentBotId.value ?? ''],
  query: async () => {
    const { data } = await getBotsByBotIdWorkspaceTargets({
      path: { bot_id: currentBotId.value! },
      throwOnError: true,
    })
    return data
  },
  enabled: () => !!currentBotId.value && canWorkspaceRead.value,
  refetchOnMount: 'always',
  refetchOnWindowFocus: true,
})

const workspaceTargets = computed<ValidWorkspaceTarget[]>(() => (
  (workspaceTargetsResponse.value?.targets ?? []).filter((target): target is ValidWorkspaceTarget => (
    typeof target.target_id === 'string'
    && target.target_id.length > 0
    && typeof target.kind === 'string'
    && target.kind.length > 0
  ))
))
const primaryWorkspaceTarget = computed(() => (
  workspaceTargets.value.find(target => target.primary)
  ?? workspaceTargets.value.find(target => target.target_id === 'native')
  ?? null
))
const workspaceTargetsInitialLoading = computed(() => (
  workspaceTargetsLoading.value && !workspaceTargetsResponse.value
))
const workspaceTargetsLoadFailed = computed(() => (
  !!workspaceTargetsError.value && !workspaceTargetsResponse.value
))

// A third-party synced thread (Telegram/Discord/...) is a multi-participant
// group conversation rather than the local 1:1 chat. The message list switches
// to a group layout for these: every turn is left-aligned with an avatar +
// sender name + channel badge, including the bot's own replies.
const channelPlatform = computed(() => (activeSession.value?.channel_type ?? '').trim().toLowerCase())
const isChannelThread = computed(() => !!channelPlatform.value && channelPlatform.value !== 'local')

interface ForkSourceMeta {
  sessionId: string
  title: string
  sourceMessageId?: string
  forkMessageId?: string
}

const acpProfiles = computed<AcpprofilePublicProfile[]>(() => acpProfileData.value?.items ?? [])
const botAgents = computed<BotagentsBotAgent[]>(() => botAgentData.value?.items ?? [])
const enabledBotAgents = computed(() => botAgents.value.filter(agent => agent.enabled !== false && !!agent.id))

const activeSessionMetadata = computed<Record<string, unknown>>(() => activeChatTarget.value.metadata)
const forkSource = computed<ForkSourceMeta | null>(() => {
  const raw = activeSessionMetadata.value.forked_from
  if (!raw || typeof raw !== 'object') return null
  const record = raw as Record<string, unknown>
  const sessionId = String(record.session_id ?? '').trim()
  if (!sessionId) return null
  const title = String(record.title ?? '').trim() || t('chat.unknownSession')
  const sourceMessageId = String(record.message_id ?? '').trim()
  const forkMessageId = String(record.fork_message_id ?? '').trim()
  return {
    sessionId,
    title,
    ...(sourceMessageId ? { sourceMessageId } : {}),
    ...(forkMessageId ? { forkMessageId } : {}),
  }
})
const forkSourceTitle = computed(() => forkSource.value?.title ?? '')
const openingForkSource = ref(false)
const forkSourceDividerAfterIndex = computed<number | null>(() => {
  const source = forkSource.value
  if (!source || messages.value.length === 0) return null
  const forkMessageId = source.forkMessageId?.trim()
  if (!forkMessageId) return null
  const index = messages.value.findIndex(messageMatchesForkSource)
  return index >= 0 ? index : null
})
const activeIsPendingExternalAgent = computed(() => activeChatTarget.value.isPendingExternalAgent)
const activeIsExternalAgent = computed(() => activeChatTarget.value.isExternalAgent)
const activeUsesExternalAgentComposer = computed(() => activeIsPendingExternalAgent.value || activeIsExternalAgent.value)
// ---- workdir binding ----
// A session bound to a bot workdir (or a draft under the bot's working
// folder) has its workspace target pinned by that binding: the computer
// label reflects the folder target, and sends carry no
// explicit workspace_target_id — the backend derives it from the binding.
const workdirsStore = useWorkdirsStore()
watch(() => currentBotId.value, (botId) => {
  if (botId) void workdirsStore.ensureWorkdirs(botId)
}, { immediate: true })
const activeSessionWorkdirId = computed(() => (activeSession.value?.workdir_id ?? '').trim())
const draftWorkingFolder = computed(() => {
  if (activeSession.value || !currentBotId.value) return null
  const workdir = workdirsStore.workingWorkdirFor(currentBotId.value)
  if (!workdir) return null
  // External Agent sessions can only bind native-workspace workdirs; a remote working
  // workdir is skipped at creation, so don't pretend it applies here.
  if (activeUsesExternalAgentComposer.value && workdir.target_kind === 'remote') return null
  return workdir
})
// Direct runtimes display their folder binding in the context row. Only drafts
// may change it; existing sessions keep their creation-time directory.
const runtimeProject = computed<BotWorkdir | null>(() => {
  if (!activeSessionWorkdirId.value) return draftWorkingFolder.value
  return workdirsStore.workdirById(currentBotId.value, activeSessionWorkdirId.value) ?? {
    id: activeSessionWorkdirId.value,
    name: t('chat.folderUnavailable'),
    path: String(activeSessionMetadata.value.project_path ?? ''),
  }
})
const composerFolderLocked = computed(() => (
  !!activeSessionWorkdirId.value || !!draftWorkingFolder.value
))
const composerFolderName = computed(() => {
  if (activeSessionWorkdirId.value) {
    const workdir = workdirsStore.workdirById(currentBotId.value, activeSessionWorkdirId.value)
    return workdir?.name?.trim() || t('chat.folderUnavailable')
  }
  return draftWorkingFolder.value?.name?.trim() || t('chat.folderUnavailable')
})
// Folders a draft may bind to. External agents run only in the native workspace, so a
// remote folder is left out rather than offered as a choice that binds nothing.
const selectableFolders = computed(() => {
  const folders = workdirsStore.workdirsFor(currentBotId.value).filter(folder => !folder.archived && !!folder.id)
  if (activeUsesExternalAgentComposer.value) return folders.filter(folder => folder.target_kind !== 'remote')
  return folders
})
// The picker only makes sense before the session exists; an empty folder list
// falls through to the locked entry (or to nothing at all).
const composerFolderPickable = computed(() => !activeSession.value && selectableFolders.value.length > 0)

function selectWorkingFolder(folder: BotWorkdir) {
  if (activeSession.value) return
  workdirsStore.setWorkingWorkdir(currentBotId.value, folder.id ?? null)
}

function clearWorkingFolder() {
  if (activeSession.value) return
  workdirsStore.setWorkingWorkdir(currentBotId.value, null)
}

// Sends from a folder-bound chat carry no explicit workspace_target_id: the
// binding decides the target, and a lingering earlier selection would be
// rejected by the backend as a target conflict.
const sendWorkspaceTargetId = computed(() => (
  composerFolderLocked.value ? '' : selectedWorkspaceTargetId.value
))

const showComputersMenu = computed(() => (
  !activeIsExternalAgent.value
  && !activeIsPendingExternalAgent.value
  && canWorkspaceRead.value
))
const computerSwitchLocked = computed(() => (
  streaming.value
  || creatingSession.value
  || loadingMessages.value
  || agentChanging.value
  || hasPendingToolApproval.value
  || !!pendingUserInput.value
))
const workspaceTargetSelection = computed(() => (
  chatStore.workspaceTargetSelectionFor(paneTarget.value)
))
const selectedWorkspaceTargetId = computed(() => workspaceTargetSelection.value.targetId)
const selectedWorkspaceTarget = computed(() => (
  workspaceTargets.value.find(target => target.target_id === selectedWorkspaceTargetId.value) ?? null
))
const selectedWorkspaceTargetMissing = computed(() => (
  !!selectedWorkspaceTargetId.value
  && !selectedWorkspaceTarget.value
  && !workspaceTargetsInitialLoading.value
))

// A folder owns its target. Display that target without overwriting the free
// draft selection, so clearing the folder restores the previous computer.
const composerComputerTargetId = computed(() => composerFolderLocked.value
  ? runtimeProject.value?.workspace_target_id?.trim() || ''
  : selectedWorkspaceTargetId.value)
const composerComputerTargetMissing = computed(() => composerFolderLocked.value
  ? !workspaceTargetsInitialLoading.value && !workspaceTargets.value.some(target => target.target_id === composerComputerTargetId.value)
  : selectedWorkspaceTargetMissing.value)
const composerComputerSnapshotName = computed(() => {
  if (!composerFolderLocked.value) return workspaceTargetSelection.value.snapshot?.name ?? ''
  const snapshot = workspaceTargetFromSessionMetadata(activeSessionMetadata.value)
  return snapshot?.target_id === composerComputerTargetId.value ? snapshot.name ?? '' : ''
})

function snapshotForWorkspaceTarget(target: ValidWorkspaceTarget): ChatWorkspaceTargetSnapshot {
  return {
    target_id: target.target_id,
    kind: target.kind,
    name: target.name,
  }
}

function workspaceTargetFromSessionMetadata(metadata: Record<string, unknown>): ChatWorkspaceTargetSnapshot | null {
  const rawSnapshot = metadata.workspace_target
  const snapshot = rawSnapshot && typeof rawSnapshot === 'object'
    ? rawSnapshot as Record<string, unknown>
    : {}
  const targetId = String(metadata.workspace_target_id ?? snapshot.target_id ?? '').trim()
  if (!targetId) return null
  const value = (key: string) => {
    const raw = snapshot[key]
    return typeof raw === 'string' && raw.trim() ? raw.trim() : undefined
  }
  return {
    target_id: targetId,
    kind: value('kind'),
    name: value('name'),
  }
}

function selectWorkspaceTarget(target: ValidWorkspaceTarget) {
  if (composerFolderLocked.value || computerSwitchLocked.value || !workspaceTargetAvailable(target)) return
  chatStore.setWorkspaceTargetSelection(
    paneTarget.value,
    target.target_id,
    snapshotForWorkspaceTarget(target),
  )
}

watch([
  activeIsExternalAgent,
  activeIsPendingExternalAgent,
  activeSessionMetadata,
  workspaceTargets,
  paneTarget,
], () => {
  if (activeIsExternalAgent.value || activeIsPendingExternalAgent.value) {
    chatStore.resetWorkspaceTargetSelection(paneTarget.value)
    return
  }
  const sessionTarget = paneTarget.value.sessionId
    ? workspaceTargetFromSessionMetadata(activeSessionMetadata.value)
    : null
  if (sessionTarget) {
    chatStore.initializeWorkspaceTargetSelection(
      paneTarget.value,
      sessionTarget.target_id,
      sessionTarget,
      'session',
    )
    return
  }
  const primary = primaryWorkspaceTarget.value
  if (!primary) return
  chatStore.initializeWorkspaceTargetSelection(
    paneTarget.value,
    primary.target_id,
    snapshotForWorkspaceTarget(primary),
    'default',
  )
}, { immediate: true })
const activeBotAgentID = computed(() =>
  activeSession.value?.bot_agent_id?.trim()
  || chatStore.pendingExternalAgentStateFor(paneTarget.value)?.input.botAgentId?.trim()
  || '',
)
const activeUsesACPRuntime = computed(() => (
  activeUsesExternalAgentComposer.value && activeChatTarget.value.runtimeType === 'acp_agent'
))
const activeDirectRuntime = computed(() => {
  if (!activeUsesExternalAgentComposer.value) return ''
  const runtime = activeChatTarget.value.runtimeType
  return isDirectBotAgentRuntime(runtime) ? runtime : ''
})
const activeUsesDirectRuntime = computed(() => activeDirectRuntime.value !== '')
// For external agents Memoh only sees the part of the context it injects, so
// a reading built from that would understate the real window; they get no
// entry until a runtime reports its own current context usage.
const showSessionInfoRing = computed(() => !isWelcome.value && !!activeSession.value && !activeUsesExternalAgentComposer.value)
const activeACPAgentId = computed(() => normalizeAgentID(activeSessionMetadata.value.acp_agent_id))
const composerAgent = computed(() => {
  if (!activeUsesExternalAgentComposer.value) return null
  return botAgents.value.find(agent => agent.id === activeBotAgentID.value) ?? {
    runtime: activeDirectRuntime.value || BOT_AGENT_RUNTIME_ACP,
    metadata: { provider: activeDirectRuntime.value || activeACPAgentId.value },
  }
})
const composerAgentIcon = computed(() => composerAgent.value ? botAgentIcon(composerAgent.value) : MemohIcon)
const composerAgentName = computed(() => composerAgent.value
  ? botAgentName(composerAgent.value)
  : t('chat.agentMemoh'))
const activeACPProjectPath = computed(() => String(activeSessionMetadata.value.project_path ?? '').trim())
const activeACPProjectMode = computed(() => String(activeSessionMetadata.value.acp_project_mode ?? '').trim())
const acpOperationScope = computed(() => JSON.stringify([
  paneTarget.value.botId,
  paneTarget.value.sessionId,
  paneTarget.value.viewId,
  activeACPAgentId.value,
  activeACPProjectPath.value,
  activeACPProjectMode.value,
]))
const acpConfigChanging = computed(() => acpConfigChangeScope.value === acpOperationScope.value)
function messageMatchesForkSource(message: ChatMessage): boolean {
  const forkMessageId = forkSource.value?.forkMessageId?.trim()
  if (!forkMessageId) return false
  const candidates = [
    message.serverId,
    message.id,
    message.role === 'system' ? undefined : message.externalMessageId,
  ]
  return candidates.some(candidate => candidate?.trim() === forkMessageId)
}

function showForkSourceDividerAfter(message: ChatMessage, index: number): boolean {
  return Boolean(forkSource.value)
    && index === forkSourceDividerAfterIndex.value
    && messages.value[index] === message
}

function showForkSourceDividerBefore(index: number): boolean {
  return Boolean(forkSource.value)
    && (!forkSource.value?.forkMessageId || forkSourceDividerAfterIndex.value === null)
    && index === 0
}

const activeSessionId = computed(() => paneTarget.value.sessionId ?? activeSession.value?.id ?? '')
const queueLocalRefresh = ref(0)
// The queue list refreshes on runtime boundaries instead of polling. A steer
// or follow-up continuation user turn changes this signature; a local enqueue
// bumps the counter. The composable keeps a slow fallback timer for a missed
// event.
//
// Only the newest queue turn is part of the key: queue inputs are consumed in
// order, so the latest one is the only boundary that can still move. Scanning
// from the end keeps this computed constant-time for long transcripts instead
// of filtering and joining every queue turn on each message change.
const queueRefreshKey = computed(() => {
  let latestQueueTurn = ''
  for (let index = messages.value.length - 1; index >= 0; index -= 1) {
    const message = messages.value[index]!
    if (message.role !== 'user') continue
    if (isRuntimeSteerUserTurn(message) || isRuntimeContinuationUserTurn(message)) {
      latestQueueTurn = `${message.id}\u0000${message.turnId ?? ''}`
      break
    }
  }
  return `${streaming.value ? 'live' : 'idle'}\u0000${latestQueueTurn}\u0000${queueLocalRefresh.value}`
})
const requestedSkills = ref<RequestedSkillSelection[]>([])
const slashPanelSuppressedPrefix = ref('')
const skillSlashEnabled = computed(() => !activeIsExternalAgent.value && !activeIsPendingExternalAgent.value)
const { data: safeSkillCatalog, isLoading: safeSkillCatalogLoading } = useQuery({
  key: () => ['bot-safe-skills-catalog', currentBotId.value ?? ''],
  query: () => fetchSafeSkillCatalog(currentBotId.value!),
  enabled: () => !!currentBotId.value && skillSlashEnabled.value,
  refetchOnWindowFocus: false,
})
const safeSkills = computed(() => skillSlashEnabled.value ? safeSkillCatalog.value ?? [] : [])

function requestedSkillKey(skill: Pick<RequestedSkillSelection, 'name'>): string {
  return skill.name.trim()
}

function addRequestedSkill(skill: RequestedSkillSelection) {
  if (!skillSlashEnabled.value) return
  const name = skill.name?.trim()
  if (!name) return
  const key = requestedSkillKey({ name })
  if (requestedSkills.value.some(item => requestedSkillKey(item) === key)) return
  requestedSkills.value = [...requestedSkills.value, {
    name,
    display_name: skill.display_name?.trim() || undefined,
    description: skill.description?.trim() || undefined,
    source_kind: skill.source_kind?.trim() || undefined,
    state: skill.state?.trim() || undefined,
  }]
  if (inputText.value.trimStart().startsWith('/')) {
    inputText.value = ''
    saveInputDraft(inputDraftKey.value, '')
  }
  clearCurrentCommandEvent()
  void nextTick(focusTextarea)
}

function removeRequestedSkill(skill: RequestedSkillSelection) {
  const key = requestedSkillKey(skill)
  requestedSkills.value = requestedSkills.value.filter(item => requestedSkillKey(item) !== key)
  void nextTick(focusTextarea)
}

watch([currentBotId, activeSessionId], () => {
  requestedSkills.value = []
  slashPanelSuppressedPrefix.value = ''
  clearCurrentCommandEvent()
})

watch(skillSlashEnabled, (enabled) => {
  if (enabled) return
  requestedSkills.value = []
  clearCurrentCommandEvent()
})

const slashQuickActions = computed(() => [
  {
    id: 'help',
    label: '/help',
    description: t('chat.slash.helpDescription'),
    icon: HelpCircle,
  },
  ...(skillSlashEnabled.value
    ? [{
        id: 'skill.list',
        label: '/skill list',
        description: t('chat.slash.skillListDescription'),
        icon: List,
      }]
    : []),
  {
    id: 'new',
    label: '/new',
    description: t('chat.slash.newDescription'),
    icon: SquarePen,
  },
  ...((runtimeModes.value.length > 0 || (activeIsPendingExternalAgent.value && acpModes.value.length > 0))
    ? [{
        id: 'permission',
        label: '/permission',
        description: runtimeModeLabel.value,
        icon: ShieldCheck,
      }]
    : []),
  ...(goalCommandAvailable.value
    ? [{ id: 'goal', label: '/goal', description: goalExecutionBlockedReason.value || t('chat.goal.description'), icon: Target }]
    : []),
  ...(planModeSupported.value
    ? [{
        id: 'plan',
        label: '/plan',
        description: t(planModeEnabled.value ? 'chat.planMode.disable' : 'chat.planMode.enable'),
        icon: Lightbulb,
      }]
    : []),
  ...(!activeIsExternalAgent.value && !activeIsPendingExternalAgent.value
    ? [{
        id: 'model',
        label: '/model',
        description: t('chat.slash.modelDescription', { model: selectedModelLabel.value }),
        icon: Package,
      }]
    : []),
])

const slashQuery = computed(() => {
  const text = inputText.value
  if (!text.trimStart().startsWith('/')) return ''
  const slashIndex = text.indexOf('/')
  return text.slice(slashIndex + 1).trim().toLowerCase()
})
const slashPanelOpen = computed(() =>
  isActive.value
  && !!currentBotId.value
  && !activeChatReadOnly.value
  && !loadingMessages.value
  && inputText.value.trimStart().startsWith('/')
  && !slashPanelSuppressedPrefix.value
  && !inputText.value.includes('\n')
  && !composerQueueCommand.value?.text,
)
function slashMatches(label: string, description = ''): boolean {
  const query = slashQuery.value
  if (!query) return true
  const haystack = `${label} ${description}`.toLowerCase()
  return haystack.includes(query)
}
const visibleSlashQuickActions = computed(() =>
  slashQuickActions.value.filter(action => slashMatches(action.label, action.description)),
)
const visibleSlashSkills = computed(() =>
  safeSkills.value.filter(skill => slashMatches(skill.name, skill.description ?? '')),
)
const runtimeControls = useRuntimeControls({
  botId: currentBotId,
  sessionId: computed(() => paneTarget.value.sessionId),
  visible: computed(() => isVisible.value && activeUsesExternalAgentComposer.value),
  draftAgentId: computed(() => activeIsPendingExternalAgent.value && !activeUsesACPRuntime.value ? activeBotAgentID.value : ''),
})
// Only a ChatGPT sign-in has usage windows; an API-key Codex Agent is billed per token.
const codexUsageAgentId = computed(() => {
  if (activeDirectRuntime.value !== BOT_AGENT_RUNTIME_CODEX) return ''
  const agent = botAgents.value.find(item => item.id === activeBotAgentID.value)
  return agent?.metadata?.auth === 'chatgpt' && agent.agent_credential_id ? agent.id ?? '' : ''
})
const codexUsage = useCodexUsage({
  botId: computed(() => currentBotId.value ?? ''),
  botAgentId: codexUsageAgentId,
  enabled: () => isVisible.value,
})
watch(streaming, (now, was) => {
  if (was && !now && codexUsageAgentId.value && isVisible.value) void codexUsage.refetch()
})
// Dismissal holds until the window resets: a new reset time is a new key.
const dismissedCodexUsageNotices = useLocalStorage<Record<string, string>>('memoh:codex-usage-dismissed', {})
const codexUsageNoticeState = computed(() => {
  const notice = codexUsageNotice(codexUsage.data.value)
  return notice ? { notice, key: codexUsageNoticeKey(codexUsageAgentId.value, notice) } : null
})
const composerUsageNotice = computed(() => {
  const state = codexUsageNoticeState.value
  if (!state) return null
  const { exhausted, window } = state.notice
  if (!exhausted && dismissedCodexUsageNotices.value[codexUsageAgentId.value] === state.key) return null
  const params = {
    window: codexUsageWindowLabel(window.window_minutes, t),
    percent: window.used_percent,
    time: window.resets_at ? codexUsageResetTime(window.resets_at, locale.value) : '',
  }
  const message = exhausted
    ? t(window.resets_at ? 'chat.codexUsage.exhausted' : 'chat.codexUsage.exhaustedNoReset', params)
    : t(window.resets_at ? 'chat.codexUsage.warning' : 'chat.codexUsage.warningNoReset', params)
  return { exhausted, message }
})
function dismissCodexUsageNotice() {
  const state = codexUsageNoticeState.value
  if (!state || !codexUsageAgentId.value) return
  dismissedCodexUsageNotices.value = { ...dismissedCodexUsageNotices.value, [codexUsageAgentId.value]: state.key }
}
const rawRuntimeControlSnapshot = computed(() => activeIsPendingExternalAgent.value && activeUsesACPRuntime.value ? pendingRuntimeControls.value : runtimeControls.controls.value)
const runtimeControlSnapshot = computed(() => localizeRuntimeControls(rawRuntimeControlSnapshot.value, runtimeText))
const composerRuntimeCommands = computed(() =>
  activeIsPendingExternalAgent.value && !activeUsesACPRuntime.value ? [] : runtimeControlSnapshot.value?.commands ?? [],
)
const runtimeModes = computed(() => runtimeControlSnapshot.value?.modes?.available_modes ?? [])
const runtimeModeLabel = computed(() => t(runtimeControlSnapshot.value?.modes?.kind === 'permission' ? 'chat.permissionMode' : 'chat.sessionMode'))
const currentRuntimeModeId = computed(() =>
  chatStore.pendingExternalAgentStateFor(paneTarget.value)?.input.permissionMode
  || runtimeControlSnapshot.value?.modes?.current_mode_id
  || '',
)
const runtimeGoalError = computed(() => runtimeControls.goalError.value
  ? resolveApiErrorMessage(runtimeControls.goalError.value, t('errors.runtime_control.failed'))
  : '')
const goalSupported = computed(() => runtimeControlSnapshot.value?.capabilities?.goal === true)
// A native /goal command is enough for the shared goal composer. Live goal
// state and pause/resume controls require the separate runtime capability.
const goalCommandAvailable = computed(() => runtimeControlSnapshot.value?.commands?.some(command => command.name === 'goal' && command.kind === 'turn') === true)
const goalDraftScope = ref('')
const goalDraftEnabled = computed(() => goalCommandAvailable.value && goalDraftScope.value === runtimeModeScope.value)
const goalExecutionBlockedReason = computed(() => goalSupported.value && planModeEnabled.value ? t('errors.runtime_control.goal_requires_default_mode') : '')
const goalSubmissionBlocked = computed(() => {
  if (streaming.value || !goalSupported.value || !goalExecutionBlockedReason.value) return false
  const text = inputText.value.trim()
  return /^\/goal(?:\s|$)/i.test(text) || (goalDraftEnabled.value && !text.startsWith('/'))
})
const goalRequests = reactive(new Map<string, symbol>())
const goalChanging = computed(() => goalRequests.has(runtimeModeScope.value))
const goalControlsDisabled = computed(() => activeChatReadOnly.value || !paneTarget.value.sessionId || loadingMessages.value || goalChanging.value)
const goalResumeDisabled = computed(() => !!goalExecutionBlockedReason.value || !!runtimeModeUnavailableReason.value || streaming.value || creatingSession.value || composerConfigPending.value || composerHasNoModel.value || isCompactingSession.value)

async function controlGoal(action: 'pause' | 'clear' | 'resume') {
  if (goalControlsDisabled.value || !runtimeControls.goal.value) return
  if (action === 'resume' && goalResumeDisabled.value) return
  const scope = runtimeModeScope.value
  const request = Symbol()
  goalRequests.set(scope, request)
  const releaseRequest = () => {
    if (goalRequests.get(scope) === request) goalRequests.delete(scope)
  }
  const pairSend = action === 'resume' ? composerPair.captureSend() : undefined
  composerError.value = ''
  try {
    if (pairSend) {
      const result = await chatStore.sendMessage('/goal resume', undefined, {
        target: paneTarget.value,
        modelId: pairSend.pair.modelId,
        reasoningEffort: pairSend.pair.reasoningEffort,
        restoreDraftOnFailure: false,
        onBeforeMessageSend: () => pairSend.begin(),
        onModelPreferenceSettled: () => pairSend.finish(false),
        // sendMessage waits for the entire run. Once dispatched, streaming
        // guards resume; pause and clear must become available immediately.
        onBeforeTurnAppend: releaseRequest,
      })
      pairSend.finish(result.messageSent === true || result.stage === 'stream')
      if (!result.ok && scope === runtimeModeScope.value) composerError.value = result.error ?? t('chat.sendFailed')
    } else if (action !== 'resume') {
      await runtimeControls.controlGoal(action)
    }
  } catch (error) {
    if (scope === runtimeModeScope.value) composerError.value = resolveApiErrorMessage(error, t('errors.runtime_control.failed'))
  } finally {
    pairSend?.finish(false)
    pairSend?.releaseReads()
    releaseRequest()
    if (action === 'resume' && scope === runtimeModeScope.value) void runtimeControls.refresh()
  }
}

const planModeSupported = computed(() => runtimeControlSnapshot.value?.capabilities?.plan_mode === true)
const planModeEnabled = computed(() => planModeSupported.value && (
  chatStore.pendingExternalAgentStateFor(paneTarget.value)?.input.planMode
  ?? (runtimeControlSnapshot.value?.plan_mode?.current_mode_id === 'plan')
))
const currentRuntimeMode = computed(() => runtimeModes.value.find(mode => mode.id === currentRuntimeModeId.value))
const runtimeModeRequestScope = ref('')
const runtimeModeScope = computed(() => JSON.stringify([paneTarget.value, activeBotAgentID.value]))
const runtimeModeChanging = computed(() => runtimeModeRequestScope.value === runtimeModeScope.value)
const runtimeModeDisabled = computed(() => activeChatReadOnly.value || streaming.value || creatingSession.value || loadingMessages.value || agentChanging.value || runtimeModeChanging.value)
const visibleRuntimeAgentCommands = computed(() =>
  visibleRuntimeCommands(composerRuntimeCommands.value, slashQuery.value).filter(command => command.name !== 'goal' || !goalCommandAvailable.value),
)
const slashPanelHasResults = computed(() =>
  visibleSlashQuickActions.value.length > 0
  || visibleRuntimeAgentCommands.value.length > 0
  || visibleSlashSkills.value.length > 0,
)

// Runtime-owned compaction (an external Agent's own compact command) shares
// the session's compaction lock and feedback. Shares the query key with
// SessionInfoRing/panel, so this adds no extra fetch.
const sessionFallbackContextWindow = computed(() => activeModel.value?.config?.context_window ?? null)
const {
  isCompacting: isCompactingSession,
  runCompaction: runSessionCompaction,
} = useSessionInfo({
  botId: computed(() => paneTarget.value.botId),
  sessionId: computed(() => paneTarget.value.sessionId),
  visible: isVisible,
  overrideModelId,
  fallbackContextWindow: sessionFallbackContextWindow,
})

// Client-side quick actions run an existing UI affordance directly instead of
// round-tripping text through send: /model opens the composer's model
// picker. Everything
// else keeps the type-and-send flow (the store intercepts /new; /help and
// /skill list execute server-side).
async function runPendingPermission(text: string) {
  if (runtimeModeDisabled.value) return
  const modeId = text.trim().replace(/^\/permission(?:\s+|$)/i, '').trim()
  if (unavailableRuntimeModes.value.includes(modeId)) {
    composerError.value = t('chat.runtimeModeModelUnavailable')
    return
  }
  const operationScope = runtimeModeScope.value
  const complete = chatStore.beginCommandEvent({
    type: 'command_result', terminal: false, action_id: 'permission',
    result: { kind: 'runtime_command', title: '/permission', text_key: 'common.loading' },
  }, currentPaneCommandScope())
  try {
    if (modeId) await setRuntimeMode(modeId)
    else if (activeUsesACPRuntime.value) await ensureACPRuntime()
    const modes = rawRuntimeControlSnapshot.value?.modes
    if (runtimeModeScope.value !== operationScope || !modes) {
      complete(null)
      return
    }
    const currentModeId = currentRuntimeModeId.value
    complete({
      type: 'command_result',
      action_id: 'permission',
      terminal: true,
      result: {
        kind: modeId ? 'permission_mode_changed' : 'permission_modes',
        items: (modes.available_modes ?? []).flatMap((mode): CommandActionListItem[] => {
          const id = mode.id ?? ''
          if (!id) return []
          return [{
            id,
            i18n_key: mode.i18n_key,
            title: mode.name || (mode.i18n_key ? '' : id),
            description: mode.description,
            kind: id === currentModeId ? 'runtime_mode_current' : 'runtime_mode',
          }]
        }),
      },
    })
  } catch (error) {
    complete({ type: 'command_error', terminal: true, code: parseMemohError(error)?.code || 'runtime_control.failed', message: resolveApiErrorMessage(error, t('chat.modeSwitchFailed')) })
  }
}

function runLocalQuickAction(id: string, text = ''): boolean {
  if (id === 'goal' && goalCommandAvailable.value) {
    if (goalExecutionBlockedReason.value) {
      composerError.value = goalExecutionBlockedReason.value
      return true
    }
    if (!runtimeModeDisabled.value) goalDraftScope.value = goalDraftEnabled.value ? '' : runtimeModeScope.value
    return true
  }
  if (id === 'plan' && planModeSupported.value) {
    void togglePlanMode()
    return true
  }
  if (id === 'model') {
    modelPopoverOpen.value = true
    return true
  }
  if (id === 'permission' && activeIsPendingExternalAgent.value) {
    void runPendingPermission(text || '/permission')
    return true
  }
  return false
}

function localQuickActionBlocked(): boolean {
  if (pendingFiles.value.length > 0) {
    composerError.value = t('chat.slash.attachmentsUnsupported')
    return true
  }
  if (requestedSkills.value.length > 0) {
    composerError.value = t('errors.slash.skill_syntax_invalid')
    return true
  }
  return false
}

function selectSlashQuickAction(action: { id: string, label: string }) {
  slashPanelSuppressedPrefix.value = ''
  if (localQuickActionBlocked()) return
  if (runLocalQuickAction(action.id, action.label)) {
    inputText.value = ''
    saveInputDraft(inputDraftKey.value, '')
    void nextTick(focusTextarea)
    return
  }
  sendSlashCommandText(action.label)
}

function sendSlashCommandText(text: string) {
  slashPanelSuppressedPrefix.value = ''
  inputText.value = text
  saveInputDraft(inputDraftKey.value, text)
  void nextTick(() => {
    focusTextarea()
    void handleSend()
  })
}

function selectRuntimeCommand(command: RuntimeCommand) {
  const text = runtimeCommandComposerText(command)
  if (!text) return
  slashPanelSuppressedPrefix.value = text.trimEnd()
  inputText.value = text
  saveInputDraft(inputDraftKey.value, text)
  void nextTick(focusTextarea)
}

// Typed forms of the client-side quick actions ("/model") — must
// be intercepted before the store send path, which would otherwise classify
// them as skill activation and fail with slash.skill_not_found.
function localQuickActionIDForSlash(text: string): string {
  if (activeIsPendingExternalAgent.value && /^\/permission(?:\s|$)/i.test(text.trim())) return 'permission'
  return composerLocalQuickActionID(
    text,
    activeIsExternalAgent.value || activeIsPendingExternalAgent.value,
    planModeSupported.value,
    goalCommandAvailable.value,
  )
}

function currentPaneCommandScope() {
  const activeBotId = paneTarget.value.botId
  const renderedSessionId = paneTarget.value.sessionId ?? ''
  const paneScope = paneComposerScope.value
  return renderedSessionId
    ? { botId: activeBotId || undefined, sessionId: renderedSessionId, composerScope: paneScope }
    : { botId: activeBotId || undefined, composerScope: paneScope }
}

function clearCurrentCommandEvent() {
  chatStore.clearCommandEvent(currentPaneCommandScope())
}

const commandPanelEvent = computed(() => chatStore.commandEventForScope(currentPaneCommandScope()))
const commandResult = computed(() => commandPanelEvent.value?.type === 'command_result' ? commandPanelEvent.value.result : null)
const commandError = computed(() => commandPanelEvent.value?.type === 'command_error' ? commandPanelEvent.value : null)
const commandPanelActionID = computed(() => commandPanelEvent.value?.action_id?.trim() ?? '')
const commandPanelIsError = computed(() => !!commandError.value)
const presentedCommandResult = computed(() => commandResult.value
  ? commandResultPresentation(localizeRuntimeCommandResult(commandResult.value, runtimeText, locale.value, commandPanelActionID.value), {
      modesTitle: runtimeModeLabel.value,
      modesText: t('chat.slash.permissionModesText'),
      changedTitle: t('chat.slash.permissionModeChangedTitle'),
      changedText: t(runtimeControlSnapshot.value?.modes?.apply_on_next_turn ? 'chat.runtimeModeNextTurn' : 'chat.slash.permissionModeChangedText'),
      currentMode: t('chat.slash.permissionCurrentMode'),
    })
  : null)
const commandPanelTitle = computed(() => {
  if (commandError.value) return t('chat.slash.commandError')
  return presentedCommandResult.value?.title || t('chat.slash.commandResult')
})
// The chat store's command_error copy, read through vue-i18n so the panel
// follows a locale switch.
function localizedCommandErrorMessage(error: CommandEventResponse): string {
  return resolveCommandErrorMessage(error, key => te(key) || te(key, 'en') ? t(key) : '')
}

const commandPanelText = computed(() => commandError.value ? localizedCommandErrorMessage(commandError.value) : presentedCommandResult.value?.text || '')
const commandResultItems = computed(() =>
  (presentedCommandResult.value?.items ?? []).filter(item => isCommandResultItemVisible(item, commandPanelActionID.value)),
)

// Pre-digested view model for the panel's command section; the raw event and
// the filtered items stay local because the composer keyboard arbitration
// (Escape / arrows / Enter) reads them too.
const composerCommandPanel = computed(() => {
  if (!commandPanelEvent.value) return null
  return {
    isError: commandPanelIsError.value,
    title: commandPanelTitle.value,
    text: commandPanelText.value,
    items: commandResultItems.value,
    data: presentedCommandResult.value?.data,
  }
})

function selectCommandResultItem(item: CommandActionListItem) {
  const selection = resolveCommandResultSelection(item, commandPanelActionID.value)
  if (!selection) return
  if (selection.kind === 'quick_action') {
    clearCurrentCommandEvent()
    selectSlashQuickAction({
      id: selection.id,
      label: selection.text,
    })
    return
  }
  if (selection.kind === 'runtime_permission') {
    clearCurrentCommandEvent()
    void onRuntimeModeSelected(selection.modeId)
    return
  }
  if (!skillSlashEnabled.value) return
  addRequestedSkill({
    name: selection.id,
    display_name: selection.title,
    description: selection.description,
  })
}
const {
  runtime: acpCapabilityRuntime,
  controls: pendingRuntimeControls,
  modes: acpModes,
  models: acpModels,
  currentModelId: currentACPModelId,
  reasoningEfforts: acpReasoningEfforts,
  currentReasoningEffort: currentACPReasoningEffort,
  isEnsuring: acpRuntimeEnsuring,
  isPreparing: acpConfigPreparing,
  ensure: ensureACPRuntime,
  setMode: setACPMode,
  setModel: setACPModel,
  setReasoning: setACPReasoning,
} = useACPRuntime({
  target: paneTarget,
  pending: activeIsPendingExternalAgent,
  enabled: computed(() => activeUsesACPRuntime.value && !!currentBotId.value),
  agentId: activeACPAgentId,
  projectPath: activeACPProjectPath,
})

const acpModelsLoading = computed(() =>
  activeUsesACPRuntime.value
  && !acpCapabilityRuntime.value?.models
  && (agentChanging.value || acpRuntimeEnsuring.value),
)
const {
  catalog: composerModelCatalog,
  nativeModels: models,
  isLoading: composerModelsLoading,
  error: composerModelCatalogError,
  refresh: refreshComposerModelCatalog,
} = useAgentModelCatalog({
  botId: currentBotId,
  botAgentId: activeBotAgentID,
  runtime: computed(() => activeChatTarget.value.runtimeType),
  selectedModelId: overrideModelId,
  projectPath: computed(() => runtimeProject.value?.path || activeACPProjectPath.value),
  acpModels,
  acpCurrentModelId: currentACPModelId,
  acpReasoningEfforts,
  acpCurrentReasoningEffort: currentACPReasoningEffort,
  acpLoading: computed(() => acpModelsLoading.value || acpConfigPreparing.value),
  refreshACP: () => refreshACPComposerConfig(),
})

const directRuntimeAuthRequired = computed(() =>
  !!activeDirectRuntime.value
  && (
    isApiErrorCode(composerModelCatalogError.value, 'external_runtime.auth_required')
    || isApiErrorCode(composerModelCatalogError.value, 'agent_credential.not_found')
    || isApiErrorCode(composerModelCatalogError.value, 'agent_credential.reauthorization_required')
  ),
)
// Native catalogs keep the last loaded list on a failed refresh, so the menu
// only reports a failure it has nothing to show for.
const modelCatalogMenuError = computed(() => {
  if (activeUsesDirectRuntime.value) return directModelCatalogError.value
  if (!composerModelCatalogError.value || composerModels.value.length) return ''
  return resolveApiErrorMessage(composerModelCatalogError.value, t('common.loadFailed'))
})
const directModelCatalogError = computed(() => {
  if (!activeUsesDirectRuntime.value || !composerModelCatalogError.value) return ''
  return resolveApiErrorMessage(composerModelCatalogError.value, t('bots.agent.modelsLoadFailed'))
})

const composerAgentConfigPending = computed(() => activeUsesExternalAgentComposer.value && (
  agentChanging.value || (activeUsesACPRuntime.value && (acpConfigChanging.value || acpConfigPreparing.value))
))
// Mode persistence blocks conflicting actions without Button.loading: even
// manual loading paints hover chrome. Keep opacity only, with no busy chrome
// or model/Agent preparation spinner.
const composerConfigPending = computed(() => composerAgentConfigPending.value || runtimeModeChanging.value)
const canAddAgent = computed(() => !!currentBotId.value && hasBotPermission(currentBot.value?.current_user_permissions, 'manage'))
const canChangeAgent = computed(() => !!currentBotId.value
  && !hasRenderedSession.value
  && !activeChatReadOnly.value
  && !loadingMessages.value
  && voiceInputState.value === 'idle'
  && !streaming.value
  && !creatingSession.value
  && !composerConfigPending.value
  && messages.value.length === 0)

const composerModels = computed(() => composerModelCatalog.value.models)
const unavailableRuntimeModes = computed(() => composerModelCatalog.value.unavailablePermissionModes ?? [])
const runtimeModeUnavailableReason = computed(() => unavailableRuntimeModes.value.includes(currentRuntimeModeId.value)
  ? t('chat.runtimeModeModelUnavailable')
  : '')
// What the dock's error line shows. Standing reasons (goal blocked by plan
// mode, runtime mode without a usable model) win over the transient
// composerError, matching their precedence before dismissal existed.
watchVisibleComposerFailure(() => composerFailure.value, () => messages.value, () => { composerError.value = '' })
const rawComposerPanelError = computed(() => goalSubmissionBlocked.value
  ? goalExecutionBlockedReason.value
  : runtimeModeUnavailableReason.value || (runtimeFailureAlreadyVisible(composerFailure.value, messages.value) ? '' : composerError.value))
// Every error line can be dismissed, standing reasons included: a user who
// already understands the reason should not be forced to keep reading it.
// Dismissal hides that exact message only — a different message, or the same
// one returning after it went away, shows again. The underlying state (and
// the send button's disabled state) is untouched.
const dismissedComposerPanelError = ref('')
const composerPanelError = computed(() => rawComposerPanelError.value === dismissedComposerPanelError.value ? '' : rawComposerPanelError.value)
watch(rawComposerPanelError, (message) => {
  if (!message) dismissedComposerPanelError.value = ''
})
function dismissComposerPanelError() {
  dismissedComposerPanelError.value = rawComposerPanelError.value
  // A transient error is consumed outright; a standing reason only gets hidden.
  if (composerError.value === dismissedComposerPanelError.value) composerError.value = ''
}
const dismissedRuntimeGoalError = ref('')
const visibleRuntimeGoalError = computed(() => runtimeGoalError.value === dismissedRuntimeGoalError.value ? '' : runtimeGoalError.value)
watch(runtimeGoalError, (message) => {
  if (!message) dismissedRuntimeGoalError.value = ''
})
const composerModelProviders = computed(() => composerModelCatalog.value.providers)

// "Default" alone tells the user nothing — resolve what it actually means:
// the runtime's configured model for direct runtimes, the bot's chat model
// for the native composer. Falls back to the bare label while the catalog is
// still loading (or, for Claude Code, when the runtime keeps its default to
// itself).
const composerDefaultModelId = computed(() => activeUsesDirectRuntime.value
  ? composerModelCatalog.value.configuredModelId || composerModelCatalog.value.defaultModelId
  : !activeUsesExternalAgentComposer.value ? botSettings.value?.chat_model_id ?? '' : '')
const { label: nativeDefaultModelLabel } = useModelSelectionLabel(
  composerDefaultModelId,
  composerModels,
  () => !activeUsesExternalAgentComposer.value,
)
const composerDefaultModelName = computed(() => {
  if (!activeUsesExternalAgentComposer.value) return nativeDefaultModelLabel.value
  const id = composerDefaultModelId.value.trim()
  // Claude may advertise only its opaque `default` alias; that real model
  // option already supplies the Default row, without a second empty option.
  if (!id || id === 'default') return ''
  const model = composerModels.value.find(m => m.id === id || m.model_id === id)
  return model?.name || model?.model_id || id
})
const composerDefaultModelLabel = computed(() =>
  composerDefaultModelName.value
    ? t('chat.modelDefaultNamed', { model: composerDefaultModelName.value })
    : t('chat.modelDefault'))
// Resolve inherited values for display without turning them into user overrides.
const composerModelId = computed(() => {
  const id = overrideModelId.value || (activeUsesDirectRuntime.value ? composerDefaultModelId.value : '')
  // A session can remember the resolved ID while the picker uses an alias.
  // Normalize only the displayed selection; the stored preference stays intact.
  return composerModels.value.find(model => model.id === id || model.model_id === id)?.id || id
})
const composerReasoningEffort = computed(() => {
  if (!activeUsesDirectRuntime.value || overrideReasoningEffort.value) return overrideReasoningEffort.value
  const catalog = composerModelCatalog.value
  return catalog.configuredReasoningEffort || catalog.defaultReasoningEffort
})
const composerReasoningOptions = computed(() => {
  const efforts = composerModelCatalog.value.reasoningEfforts
  if (!efforts) return undefined
  const options = efforts.flatMap((effort) => {
    const value = effort.id?.trim() ?? ''
    if (!value) return []
    const runtimeLabel = effort.name?.trim() ?? ''
    const translatedLabel = EFFORT_LABELS[value] ? t(EFFORT_LABELS[value]) : value
    return [{
      value,
      label: runtimeLabel && runtimeLabel !== value ? runtimeLabel : translatedLabel,
      description: effort.description?.trim() || undefined,
    }]
  })
  // A Codex model without a default level sends none until one is picked, so
  // the menu needs a way back to that state.
  if (activeDirectRuntime.value === BOT_AGENT_RUNTIME_CODEX && options.length && !composerModelCatalog.value.defaultReasoningEffort) {
    options.unshift({ value: '', label: t('chat.modelDefault'), description: undefined })
  }
  return options
})

function openAgentSettings(addAgent: boolean) {
  if (addAgent && !canAddAgent.value) return
  const botName = currentBot.value?.name || currentBot.value?.id || currentBotId.value
  if (!botName) return
  modelPopoverOpen.value = false
  agentPopoverOpen.value = false
  void router.push({
    name: 'bot-detail',
    params: { botName },
    query: { tab: 'agents', ...(addAgent ? { addAgent: currentBotId.value } : {}) },
  })
}

function retryDirectModelCatalog() {
  void refreshComposerModelCatalog()
}

const activeModel = computed(() => {
  const id = overrideModelId.value || botSettings.value?.chat_model_id || ''
  return models.value.find((m) => m.id === id)
})

// PDFs reach the model natively only when it carries the file-input
// capability; without it the file lands in the workspace as a path the model
// cannot open. Warn at attach time so the user is not surprised mid-turn.
// External Agent sessions are exempt — Claude Code / Codex read PDFs themselves.
const isPdfFile = (file: File) =>
  file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')

// Mirrors the backend's nativeAttachmentMaxBinaryBytes: larger PDFs are demoted
// to the workspace-path fallback even when the model supports file-input.
const nativePdfMaxBytes = 12 * 1024 * 1024

watch(() => pendingFiles.value.length, (len, prevLen) => {
  if (len <= (prevLen ?? 0)) return
  if (activeUsesExternalAgentComposer.value) return
  const model = activeModel.value
  if (!model) return
  const added = pendingFiles.value.slice(prevLen ?? 0)
  if (!model.config?.compatibilities?.includes('file-input')) {
    if (added.some(isPdfFile)) {
      toast.warning(t('chat.pdfUnsupportedByModel'))
    }
    return
  }
  if (added.some((file) => isPdfFile(file) && file.size > nativePdfMaxBytes)) {
    toast.warning(t('chat.pdfTooLargeForNative'))
  }
})

// Dropping files on the conversation is the Paperclip by another route: they
// land in the same pending tray, so the attachment cards, previews, and the PDF
// warning above all follow with no extra wiring. Nothing is sent — the user
// still writes the message that goes with the files.
async function handleFilesDrop(transfer: DataTransfer) {
  const { files, skippedFolders } = await readDroppedFiles(transfer)
  for (const file of files) pendingFiles.value.push(file)
  // An attachment is one file, so a folder has nothing to become here. Warned
  // even when loose files DID land in the same drop: the cards would otherwise
  // read as "everything arrived" while the folder vanished silently.
  if (skippedFolders > 0) {
    toast.warning(t('chat.dropFolderUnsupported'))
  }
}

// Same conditions that disable the Paperclip: no bot, a read-only or streaming
// turn, history still loading. A disabled zone keeps the overlay dark, so the
// OS no-drop cursor answers instead of a drop that goes nowhere.
const fileDropDisabled = () => !currentBotId.value || activeChatReadOnly.value || streaming.value || loadingMessages.value

// Root element, exposed through the drop-target registry so the page-level base
// zone can anchor its overlay over THIS pane (a global drag points at the
// composer it will land in) instead of floating a third, window-centred anchor.
const rootEl = useTemplateRef<HTMLElement>('rootEl')

const { active: dropActive, bounds: dropBounds, handlers: dropHandlers } = useFileDropZone({
  disabled: fileDropDisabled,
  onDrop: transfer => void handleFilesDrop(transfer),
})

// While this pane is the focused dock panel it is also the page-level target:
// files dropped outside every region zone (e.g. the sidebar on a non-Files
// view) are forwarded by the base zone in main-section into THIS composer's
// tray. Cleanup runs on blur and on unmount (watcher stop), and the registry's
// identity guard makes focus handoff between splits order-safe.
watch(isActive, (focused) => {
  if (!focused) return
  onWatcherCleanup(registerChatFileDropTarget({
    onDrop: transfer => void handleFilesDrop(transfer),
    disabled: fileDropDisabled,
    hostEl: () => rootEl.value,
  }))
}, { immediate: true })

type DefaultExternalAgentSettings = {
  default_bot_agent_id?: string
  chat_runtime?: string
  chat_acp_agent_id?: string
  chat_acp_project_path?: string
  chat_acp_project_mode?: string
}

type DefaultExternalAgentAvailability = {
  input: ExternalAgentSessionInput | null
  messageKey: string
  loading: boolean
}

const defaultExternalAgentAvailability = computed<DefaultExternalAgentAvailability>(() => {
  const settings = botSettings.value as (DefaultExternalAgentSettings | undefined)
  if (!settings) {
    return { input: null, messageKey: '', loading: !!currentBotId.value && botSettingsLoading.value }
  }
  if (!isAgentRuntimeType(settings.chat_runtime)) return { input: null, messageKey: '', loading: false }
  if (!hasBotPermission(currentBot.value?.current_user_permissions, 'workspace_exec')) {
    return { input: null, messageKey: 'chat.defaultAgentNoWorkspaceExec', loading: false }
  }
  const botAgentId = settings.default_bot_agent_id?.trim() ?? ''
  if (!botAgentId) return { input: null, messageKey: 'chat.defaultAgentMissing', loading: false }
  if (!botAgentData.value) {
    return {
      input: null,
      messageKey: botAgentsLoading.value ? 'chat.defaultExternalAgentLoading' : 'chat.defaultAgentUnavailable',
      loading: botAgentsLoading.value,
    }
  }
  const agent = botAgents.value.find(item => item.id === botAgentId)
  if (!agent || agent.enabled === false) {
    return { input: null, messageKey: 'chat.defaultAgentDisabled', loading: false }
  }
  const agentId = botAgentProvider(agent)
  const directConfigured = isDirectBotAgentConfigured(agent)
  if (directConfigured === false) {
    return { input: null, messageKey: 'chat.defaultAgentNotConfigured', loading: false }
  }
  if (directConfigured === null) {
    if (!acpProfileData.value) {
      return {
        input: null,
        messageKey: acpProfilesLoading.value ? 'chat.defaultExternalAgentLoading' : 'chat.defaultAgentUnavailable',
        loading: acpProfilesLoading.value,
      }
    }
    const profile = acpProfiles.value.find(item => normalizeAgentID(item.id) === agentId)
    if (!profile) return { input: null, messageKey: 'chat.defaultAgentUnavailable', loading: false }
    if (!isACPAgentConfigured(agent, profile)) {
      return { input: null, messageKey: 'chat.defaultAgentNotConfigured', loading: false }
    }
  }
  return {
    input: {
      botAgentId,
      runtime: normalizeBotAgentRuntime(agent.runtime) || BOT_AGENT_RUNTIME_ACP,
      agentId,
      projectPath: settings.chat_acp_project_path?.trim() || EXTERNAL_AGENT_DEFAULT_PROJECT_PATH,
      projectMode: settings.chat_acp_project_mode?.trim() || EXTERNAL_AGENT_DEFAULT_PROJECT_MODE,
    },
    messageKey: '',
    loading: false,
  }
})
const defaultExternalAgentSessionInput = computed(() => defaultExternalAgentAvailability.value.input)
const defaultExternalAgentUnavailableMessage = computed(() =>
  defaultExternalAgentAvailability.value.messageKey ? t(defaultExternalAgentAvailability.value.messageKey) : '',
)
const defaultExternalAgentLoading = computed(() => defaultExternalAgentAvailability.value.loading)
const defaultExternalAgentComposerError = ref('')

function clearDefaultExternalAgentComposerError() {
  if (defaultExternalAgentComposerError.value && composerError.value === defaultExternalAgentComposerError.value) {
    composerError.value = ''
  }
  defaultExternalAgentComposerError.value = ''
}

const activeModelReasoning = computed(() => activeModel.value?.reasoning)

const activeModelSupportsReasoning = computed(() => activeModelReasoning.value?.supported === true)

// A native composer with no chat model cannot answer, so the trigger says so
// ("None") instead of the old "Default" placeholder, which named a model that
// does not exist.
const composerHasNoModel = computed(() =>
  hasNoComposerModel(activeUsesExternalAgentComposer.value, overrideModelId.value),
)

const { label: nativeSelectedModelLabel, isUnavailable: nativeModelUnavailable } = useModelSelectionLabel(
  composerModelId,
  composerModels,
  () => !activeUsesExternalAgentComposer.value,
)

const selectedModelLabel = computed(() => {
  if (!activeUsesExternalAgentComposer.value && composerModelId.value) return nativeSelectedModelLabel.value
  const current = composerModels.value.find(model => model.id === composerModelId.value)
  if (current?.name || current?.model_id) return current.name || current.model_id
  // A configured-but-missing id still shows the raw id rather than "None": the
  // model list can lag behind settings, and a transient gap must not read as
  // "unconfigured".
  if (composerModelId.value) return composerModelId.value
  if (activeDirectRuntime.value === BOT_AGENT_RUNTIME_CODEX) {
    return composerModelsLoading.value ? t('common.loading') : t('chat.modelOverride')
  }
  return composerHasNoModel.value ? t('common.none') : composerDefaultModelLabel.value
})

const nativeDisplayedEffort = computed(() => displayedEffort(overrideReasoningEffort.value, activeModelReasoning.value))

const selectedReasoningLabel = computed(() => {
  if (activeUsesExternalAgentComposer.value) {
    const current = composerReasoningEffort.value
    return composerReasoningOptions.value?.find(option => option.value === current)?.label || current
  }
  const v = nativeDisplayedEffort.value
  return t(EFFORT_LABELS[v] ?? 'chat.modelDefault')
})

const reasoningActive = computed(() =>
  activeUsesExternalAgentComposer.value
    ? Boolean(
        composerReasoningEffort.value
        && composerReasoningOptions.value?.some(option => option.value === composerReasoningEffort.value),
      )
    : Boolean(nativeDisplayedEffort.value)
      && nativeDisplayedEffort.value !== REASONING_EFFORT_DISABLE,
)

const modelTriggerLabel = computed(() =>
  reasoningActive.value && (activeUsesExternalAgentComposer.value || !nativeModelUnavailable.value)
    ? `${selectedModelLabel.value} · ${selectedReasoningLabel.value}`
    : selectedModelLabel.value,
)

// A subagent runs on the model it was pinned to when it was spawned, recorded
// on its session at creation. The composer has to open on that model: it sends
// model_id with every message, so defaulting to the bot's chat model would move
// the agent onto another model the moment a human talks to it — silently, since
// the picker would still read as "the default".
const pinnedSubagentModelId = computed(() => resolvePinnedSubagentModelId(
  activeSession.value?.type,
  activeSessionMetadata.value,
  models.value
    .map(model => model.id)
    .filter((id): id is string => !!id),
))

// Everything that names the namespace of the pair's model IDs. A change under
// the same view (Agent / runtime switch on an open session, staging an external
// Agent on a draft) drops the old pair; a plain repoint does not, since each
// view carries its own pair.
const pairRuntimeIdentity = computed(() => JSON.stringify([
  activeChatTarget.value.runtimeType,
  activeUsesExternalAgentComposer.value,
  activeBotAgentID.value,
  activeACPAgentId.value,
  activeACPProjectPath.value,
  activeACPProjectMode.value,
]))
// Registered before the ACP config watchers below so a reset lands before
// reconcile re-seeds from the new runtime's own state.
const composerPair = useComposerPair({
  view: paneView,
  target: paneTarget,
  visible: isVisible,
  botId: currentBotId,
  activeSession,
  botSettings,
  pinnedSubagentModelId,
  usesExternalAgentComposer: activeUsesExternalAgentComposer,
  usesDirectRuntime: activeUsesDirectRuntime,
  usesACPRuntime: activeUsesACPRuntime,
  runtimeIdentity: pairRuntimeIdentity,
  directCatalog: composerModelCatalog,
  draftPromotionPending: () => directDraftPromotionPending,
  onPreferenceConflict: (error) => {
    composerError.value = resolveApiErrorMessage(error, t('errors.session.model_preference_conflict'))
  },
})

// Switching models can strand the composer's override on a tier the new model
// does not offer. An empty override is left alone: it means "inherit the bot's
// setting", not a stranded value.
watch(activeModelReasoning, (options) => {
  if (activeUsesExternalAgentComposer.value) return
  const current = overrideReasoningEffort.value
  if (!current || !options?.supported) return
  const next = reconcileStoredEffort(current, options)
  if (next && next !== current) overrideReasoningEffort.value = next
}, { immediate: true })

function reconcileACPComposerConfig() {
  const runtime = acpCapabilityRuntime.value
  if (!activeUsesACPRuntime.value || !runtime) return

  if (runtime.models !== undefined) {
    const availableModels = new Set(
      acpModels.value.map(model => model.id?.trim() ?? '').filter(Boolean),
    )
    const selectedModel = overrideModelId.value.trim()
    if (!selectedModel || !availableModels.has(selectedModel)) {
      const currentModel = currentACPModelId.value.trim()
      overrideModelId.value = availableModels.has(currentModel) ? currentModel : ''
      composerPair.setSource('session')
    }
  }

  if (runtime.reasoning !== undefined) {
    const availableEfforts = new Set(
      acpReasoningEfforts.value.map(effort => effort.id?.trim() ?? '').filter(Boolean),
    )
    const selectedEffort = overrideReasoningEffort.value.trim()
    if (!selectedEffort || !availableEfforts.has(selectedEffort)) {
      const currentEffort = currentACPReasoningEffort.value.trim()
      overrideReasoningEffort.value = availableEfforts.has(currentEffort) ? currentEffort : ''
      composerPair.setSource('session')
    }
  } else {
    overrideReasoningEffort.value = ''
  }
}

watch(acpCapabilityRuntime, () => {
  if (!acpConfigPreparing.value) reconcileACPComposerConfig()
}, { immediate: true })

watch(
  () => activeUsesACPRuntime.value && isVisible.value ? acpOperationScope.value : '',
  (scope) => {
    if (!scope || !activeACPAgentId.value) return
    void refreshACPComposerConfig().catch((error) => {
      composerError.value = resolveApiErrorMessage(error, t('chat.agentSwitchFailed'))
    })
  },
  { immediate: true },
)

async function refreshACPComposerConfig(): Promise<void> {
  if (!activeUsesACPRuntime.value) return
  const desiredModelId = overrideModelId.value.trim()
  const runtime = await ensureACPRuntime(true, desiredModelId)
  if (!runtime || !activeUsesACPRuntime.value) return
  reconcileACPComposerConfig()
}

async function refreshACPComposerConfigAfterSelectionError(result: SendMessageResult): Promise<void> {
  if (!shouldRefreshACPComposerConfig(result, activeUsesACPRuntime.value)) return

  const operationScope = acpOperationScope.value
  acpConfigChangeScope.value = operationScope
  try {
    await refreshACPComposerConfig()
  } catch {
    // Preserve the original selection error. This refresh is best-effort
    // recovery so a secondary failure must not replace the actionable cause.
  } finally {
    if (acpConfigChangeScope.value === operationScope) acpConfigChangeScope.value = ''
  }
}

function pendingMatchesDefaultExternalAgent(input: ExternalAgentSessionInput): boolean {
  return activeChatTarget.value.kind === 'draft-external-agent'
    && chatStore.pendingExternalAgentMatchesInput(input, paneTarget.value)
}

// The Bot's default External Agent only applies to an empty draft. A pane that
// already renders a Session keeps it: staging a default there would clear the
// selection behind the tab the user is looking at.
watch([defaultExternalAgentUnavailableMessage, defaultExternalAgentLoading, currentBotId, hasExplicitSessionSelection, isActive], ([message, loading, _bot, _explicit, focused]) => {
  if (!focused) return
  clearDefaultExternalAgentComposerError()
  if (hasRenderedSession.value) return
  if (!message || !currentBotId.value) return
  if (hasExplicitSessionSelection.value) return
  if (!loading) {
    chatStore.resetToEmptyComposer({}, paneTarget.value)
  }
  defaultExternalAgentComposerError.value = message
  composerError.value = message
}, { immediate: true })

watch([defaultExternalAgentSessionInput, defaultExternalAgentLoading, currentBotId, hasExplicitSessionSelection, activeChatTarget, isActive], ([input, loading, _bot, _explicit, _target, focused]) => {
  if (!focused) return
  if (!currentBotId.value) return
  if (!input) {
    if (!loading) {
      chatStore.cacheDefaultExternalAgentSession(null)
    }
    if (!loading && !hasExplicitSessionSelection.value && !hasRenderedSession.value && activeIsPendingExternalAgent.value) {
      chatStore.resetToEmptyComposer({}, paneTarget.value)
    }
    return
  }
  chatStore.cacheDefaultExternalAgentSession(input)
  if (hasExplicitSessionSelection.value || hasRenderedSession.value) return
  clearDefaultExternalAgentComposerError()
  if (pendingMatchesDefaultExternalAgent(input)) return
  chatStore.stageDefaultExternalAgentSession(input, paneTarget.value)
}, { immediate: true })

watch([modelPopoverOpen, activeUsesACPRuntime, acpOperationScope], ([open, usesExternalAgent]) => {
  if (!open || !usesExternalAgent) return
  void refreshACPComposerConfig().catch((error) => {
    composerError.value = resolveApiErrorMessage(error, t('chat.agentSwitchFailed'))
  })
})

watch([slashPanelOpen, activeUsesACPRuntime, acpOperationScope], ([open, usesExternalAgent]) => {
  if (!open || !usesExternalAgent) return
  void ensureACPRuntime().catch((error) => {
    composerError.value = resolveApiErrorMessage(error, t('chat.agentSwitchFailed'))
  })
})

// Starting an ACP runtime (spawning the agent process + protocol handshake) has
// no server-side deadline, so a wedged agent would leave the composer spinning
// indefinitely — the user's only escape was a full page reload. Bound the switch
// on the client so the controls re-enable and a retry hint surfaces instead.
const AGENT_SWITCH_TIMEOUT_MS = 30_000

class AgentSwitchTimeout extends Error {}

function withAgentSwitchTimeout<T>(work: Promise<T>): Promise<T> {
  // Keep a detached handler so a late settle (after the race is decided) never
  // bubbles up as an unhandled rejection.
  void work.catch(() => {})
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new AgentSwitchTimeout()), AGENT_SWITCH_TIMEOUT_MS)
    work.then(
      (value) => { clearTimeout(timer); resolve(value) },
      (error) => { clearTimeout(timer); reject(error) },
    )
  })
}

function agentSwitchErrorMessage(error: unknown): string {
  return error instanceof AgentSwitchTimeout
    ? t('chat.agentSwitchTimeout')
    : resolveApiErrorMessage(error, t('chat.agentSwitchFailed'))
}

async function selectBotAgent(agent: BotagentsBotAgent) {
  const botAgentId = agent.id?.trim() ?? ''
  const agentId = botAgentProvider(agent)
  const runtime = normalizeBotAgentRuntime(agent.runtime) || BOT_AGENT_RUNTIME_ACP
  if (!botAgentId || !agentId || agentChanging.value || !canChangeAgent.value) return
  agentPopoverOpen.value = false
  if (activeUsesExternalAgentComposer.value && botAgentId === activeBotAgentID.value) return
  agentChanging.value = true
  composerError.value = ''
  try {
    chatStore.stageExternalAgentSession({
      botAgentId,
      runtime,
      agentId,
    }, {}, paneTarget.value)
    if (runtime === BOT_AGENT_RUNTIME_ACP) {
      await withAgentSwitchTimeout(chatStore.ensurePendingACPRuntime(paneTarget.value))
    }
  } catch (error) {
    composerError.value = agentSwitchErrorMessage(error)
  } finally {
    agentChanging.value = false
  }
}

function selectMemohAgent() {
  if (agentChanging.value || !canChangeAgent.value) return
  agentPopoverOpen.value = false
  chatStore.resetToEmptyComposer({ explicitSelection: true }, paneTarget.value)
  clearDefaultExternalAgentComposerError()
  composerError.value = ''
  pendingFiles.value = []
}

function onModelSelected() {
  // Switching models replaces the WHOLE pair (spec v2 P6′): the effort lands
  // on the new model's default tier and is never carried across models.
  if (!activeModelSupportsReasoning.value) {
    overrideReasoningEffort.value = REASONING_EFFORT_DISABLE
    return
  }
  overrideReasoningEffort.value = activeModelReasoning.value?.default_effort?.trim() ?? ''
}

async function onComposerModelValueSelected(value: string) {
  if (activeUsesACPRuntime.value && acpConfigChanging.value) return
  const previous = composerPair.snapshot()
  if (!composerPair.selectModel(value)) return
  if (!activeUsesExternalAgentComposer.value) {
    onModelSelected() // the effort follows the new model before the pair is persisted
    composerPair.persist()
    return
  }
  if (activeUsesDirectRuntime.value) {
    composerPair.persist()
    return
  }

  const modelId = value.trim()
  if (!modelId) {
    composerPair.restore(previous)
    return
  }
  const operationScope = acpOperationScope.value
  acpConfigChangeScope.value = operationScope
  composerError.value = ''
  try {
    const runtime = await setACPModel(modelId)
    if (runtime && acpOperationScope.value === operationScope) reconcileACPComposerConfig()
  } catch (error) {
    if (
      activeUsesExternalAgentComposer.value
      && acpOperationScope.value === operationScope
      && overrideModelId.value === value
    ) {
      composerPair.restore(previous)
      composerError.value = resolveApiErrorMessage(error, t('chat.modelSwitchFailed'))
    }
  } finally {
    if (acpConfigChangeScope.value === operationScope) acpConfigChangeScope.value = ''
  }
}

async function setRuntimeMode(modeId: string, modeKind: 'permission' | 'plan' = 'permission') {
  const scope = runtimeModeScope.value
  runtimeModeRequestScope.value = scope
  try {
    if (activeIsPendingExternalAgent.value) {
      if (modeKind === 'permission' && activeUsesACPRuntime.value) await setACPMode(modeId)
      else {
        const modes = modeKind === 'plan' ? runtimeControlSnapshot.value?.plan_mode?.available_modes ?? [] : runtimeModes.value
        if (!modes.some(mode => mode.id === modeId)) throw new UserFacingError(t('errors.runtime_control.mode_unavailable'))
        chatStore.setPendingRuntimeMode(modeId, paneTarget.value, modeKind)
      }
    } else await runtimeControls.setMode(modeId, modeKind)
  } finally {
    if (runtimeModeRequestScope.value === scope) runtimeModeRequestScope.value = ''
  }
}

async function togglePlanMode() {
  if (!planModeSupported.value || runtimeModeDisabled.value) return
  const scope = runtimeModeScope.value
  composerError.value = ''
  clearCurrentCommandEvent()
  try {
    await setRuntimeMode(planModeEnabled.value ? 'default' : 'plan', 'plan')
  } catch (error) {
    if (scope === runtimeModeScope.value) composerError.value = resolveApiErrorMessage(error, t('chat.planMode.changeFailed'))
  }
}

async function onRuntimeModeSelected(value: unknown) {
  if (typeof value !== 'string' || !value || runtimeModeDisabled.value || value === currentRuntimeModeId.value) return
  if (unavailableRuntimeModes.value.includes(value)) return
  const scope = currentPaneCommandScope()
  composerError.value = ''
  try {
    await setRuntimeMode(value)
  } catch (error) {
    if (scope.botId === paneTarget.value.botId && (scope.sessionId ?? '') === (paneTarget.value.sessionId ?? '') && scope.composerScope === paneComposerScope.value) composerError.value = resolveApiErrorMessage(error, t('chat.modeSwitchFailed'))
  }
}

async function onComposerReasoningEffortSelected(value: string) {
  if (activeUsesACPRuntime.value && acpConfigChanging.value) return
  const previous = composerPair.snapshot()
  if (activeUsesDirectRuntime.value && !overrideModelId.value) overrideModelId.value = composerModelId.value
  overrideReasoningEffort.value = value
  composerPair.setSource('user')
  if (!activeUsesACPRuntime.value) {
    composerPair.persist()
    return
  }

  const effort = value.trim()
  if (!effort) {
    composerPair.restore(previous)
    return
  }
  const operationScope = acpOperationScope.value
  acpConfigChangeScope.value = operationScope
  composerError.value = ''
  try {
    const runtime = await setACPReasoning(effort)
    if (runtime && acpOperationScope.value === operationScope) reconcileACPComposerConfig()
  } catch (error) {
    if (
      activeUsesExternalAgentComposer.value
      && acpOperationScope.value === operationScope
      && overrideReasoningEffort.value === value
    ) {
      composerPair.restore(previous)
      composerError.value = resolveApiErrorMessage(error, t('chat.reasoningSwitchFailed'))
    }
  } finally {
    if (acpConfigChangeScope.value === operationScope) acpConfigChangeScope.value = ''
  }
}

const {
  items: galleryItems,
  openIndex: galleryOpenIndex,
  setOpenIndex: gallerySetOpenIndex,
  openBySrc: galleryOpenBySrc,
  origin: galleryOrigin,
} = useMediaGallery(messages)

const inputText = ref('')
const queueSubmissionGate = new SessionQueueSubmissionGate()
const composerQueueCommand = computed(() => parseSessionQueueCommand(inputText.value, composerRuntimeCommands.value))
const composerPlaceholder = computed(() => {
  if (activeChatReadOnly.value) return t('chat.readonlyHint')
  if (!streaming.value) return t(goalDraftEnabled.value ? 'chat.goal.placeholder' : planModeEnabled.value ? 'chat.planMode.placeholder' : 'chat.inputPlaceholder')
  return t('chat.inputPlaceholder')
})
watch(inputText, (text) => {
  const prefix = slashPanelSuppressedPrefix.value
  if (!prefix || text === prefix || text.startsWith(`${prefix} `)) return
  slashPanelSuppressedPrefix.value = ''
})
const {
  textareaEl,
  focusTextarea,
  modelTriggerMaxWidth,
} = useComposerLayout()

useUnfocusedComposerInput({
  textarea: textareaEl,
  // Settings keeps the dock mounted underneath its full-screen layer.
  enabled: () => (router.currentRoute.value.name === 'home' || router.currentRoute.value.name === 'bot')
    && isActive.value && isVisible.value && !attachmentPreparing.value,
  onPaste: handlePaste,
})

const showSend = computed(() => Boolean(inputText.value.trim()) || pendingFiles.value.length > 0 || pendingNativeAttachments.value.length > 0 || requestedSkills.value.length > 0)

// TODO(voice-input): shelved until a default transcription model ships —
// today the mic dead-ends users into a settings detour. The whole path (mic
// button, MediaRecorder/transcription plumbing, the mic⇄send cross-fade)
// stays in place behind this flag; a disabled send-styled placeholder holds
// the inactive slot meanwhile. Once the default model lands, open an issue
// to restore voice input: flip this to true and delete the placeholder.
const voiceInputEnabled = false

// Whether the trailing slot shows the send button (vs. its inactive
// occupant — see inactiveSlotVisible just below, its exact complement).
// Keep the one action slot visible during a run: send for a draft, stop
// only when the existing content predicate says the composer is empty.
const sendButtonVisible = computed(() => showSend.value || streaming.value)

// The slot's inactive occupant: a grayed send stand-in while voice input is
// shelved, the mic itself once voiceInputEnabled flips back on (nothing to
// send is exactly when voice input is the useful affordance there). Exact
// complement of sendButtonVisible so the two can never both show (or both
// hide).
const inactiveSlotVisible = computed(() => !sendButtonVisible.value)

// Voice input: MediaRecorder → the bot's configured transcription model →
// transcript appended into the draft. The recorder/stream live outside
// reactivity (plain module lets) because MediaRecorder is stateful and must
// never be proxied. voiceRequestVersion + voiceSourceBotId guard the async
// edges: a bot switch or cancel mid-record/mid-transcribe invalidates the
// in-flight request so a late transcript can't land in the wrong pane.
//
// While recording/transcribing the composer itself becomes the voice
// surface: the input row swaps to live level bars + elapsed time, and the
// trailing slot swaps mic/send for a ✗/✓ pair. Cancel also aborts an
// in-flight transcription, so a hung upstream can never strand the pane.
type VoiceInputState = 'idle' | 'recording' | 'transcribing'

const voiceInputState = ref<VoiceInputState>('idle')

useComposerKeyboardFocus({
  textarea: textareaEl,
  enabled: () => isActive.value && isVisible.value,
  available: () => (router.currentRoute.value.name === 'home' || router.currentRoute.value.name === 'bot')
    && !!currentBotId.value && !activeChatReadOnly.value
    && voiceInputState.value === 'idle',
  ready: () => !loadingMessages.value && !composerPlacementPending.value,
  owner: () => `${paneTarget.value.botId}:${paneTarget.value.viewId}:${paneTarget.value.sessionId ?? ''}`,
  request: () => workspaceTabs.pendingChatInputFocus?.panelId === props.tabId
    && workspaceTabs.pendingChatInputFocus.botId === paneTarget.value.botId
    && workspaceTabs.pendingChatInputFocus.sessionId === paneTarget.value.sessionId,
  consumeRequest: () => { workspaceTabs.pendingChatInputFocus = null },
})

const voiceInputLabel = computed(() => {
  if (voiceInputState.value === 'recording') return t('chat.voiceInput.stop')
  if (voiceInputState.value === 'transcribing') return t('chat.voiceInput.transcribing')
  return t('chat.voiceInput.start')
})
const voiceInputDisabled = computed(() =>
  !currentBotId.value
  || activeChatReadOnly.value
  || loadingMessages.value
  || streaming.value
  || botSettingsLoading.value
  || voiceInputState.value === 'transcribing',
)

let voiceRecorder: MediaRecorder | null = null
let voiceStream: MediaStream | null = null
let voiceChunks: Blob[] = []
let discardVoiceRecording = false
let voiceSourceBotId = ''
let voiceRequestVersion = 0
let voiceTranscribeAbort: AbortController | null = null

// Live meters for the voice surface: an AnalyserNode samples mic RMS into a
// window of bars (~80ms cadence), a 1s timer tracks elapsed time. The window
// length follows the strip's measured width so the history always fills the
// row exactly. AudioContext / rAF ids are plain lets — never proxied.
const VOICE_BAR_STRIDE_PX = 5 // one 2px bar + its 3px gap
// Keep in sync with the h-8 strip: 32px track minus a hair of headroom.
const VOICE_BAR_MAX_PX = 30
// Below this level a bar reads as quiet history (muted dot), not live voice.
const VOICE_BAR_ACTIVE_LEVEL = 0.06
const voiceStripEl = ref<HTMLElement | null>(null)
const { width: voiceStripWidth } = useElementSize(voiceStripEl)
const voiceBarCount = computed(() => Math.max(1, Math.floor(voiceStripWidth.value / VOICE_BAR_STRIDE_PX)))
const voiceBars = ref<number[]>([])
const voiceSeconds = ref(0)
let voiceAudioCtx: AudioContext | null = null
let voiceMeterFrame = 0
let voiceTimer: ReturnType<typeof setInterval> | null = null

// Resize the history window in place when the strip changes width: keep the
// newest samples, pad quiet dots on the left when the row grows.
watch(voiceBarCount, (count) => {
  const bars = voiceBars.value
  if (bars.length === count) return
  voiceBars.value = bars.length > count
    ? bars.slice(bars.length - count)
    : [...Array(count - bars.length).fill(0), ...bars]
})

const formattedVoiceSeconds = computed(() => {
  const minutes = Math.floor(voiceSeconds.value / 60)
  const rest = voiceSeconds.value % 60
  return `${minutes}:${String(rest).padStart(2, '0')}`
})

function startVoiceMeters(stream: MediaStream) {
  voiceBars.value = Array(voiceBarCount.value).fill(0)
  voiceSeconds.value = 0
  const audioCtx = new AudioContext()
  // The mic-permission prompt can outlast transient activation (and Safari
  // starts suspended regardless) — without resume() the bars stay flat dots
  // for the whole session. Everything else works either way.
  void audioCtx.resume().catch(() => {})
  const analyser = audioCtx.createAnalyser()
  analyser.fftSize = 1024
  analyser.smoothingTimeConstant = 0.5
  audioCtx.createMediaStreamSource(stream).connect(analyser)
  voiceAudioCtx = audioCtx
  const dataArray = new Float32Array(analyser.fftSize)
  let lastSample = 0
  const tick = (now: number) => {
    if (voiceAudioCtx !== audioCtx) return
    analyser.getFloatTimeDomainData(dataArray)
    if (now - lastSample >= 80) {
      lastSample = now
      let sum = 0
      for (const sample of dataArray) sum += sample ** 2
      const rms = Math.sqrt(sum / dataArray.length)
      voiceBars.value = [...voiceBars.value.slice(1), Math.min(1, rms * 8)]
    }
    voiceMeterFrame = requestAnimationFrame(tick)
  }
  voiceMeterFrame = requestAnimationFrame(tick)
  voiceTimer = setInterval(() => { voiceSeconds.value += 1 }, 1000)
}

function stopVoiceMeters() {
  cancelAnimationFrame(voiceMeterFrame)
  if (voiceTimer) {
    clearInterval(voiceTimer)
    voiceTimer = null
  }
  const audioCtx = voiceAudioCtx
  voiceAudioCtx = null
  if (audioCtx) void audioCtx.close().catch(() => {})
}

function releaseVoiceStream() {
  voiceStream?.getTracks().forEach(track => track.stop())
  voiceStream = null
}

function preferredVoiceMimeType(): string {
  if (typeof MediaRecorder === 'undefined') return ''
  const candidates = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/mp4',
    'audio/ogg;codecs=opus',
  ]
  return candidates.find(type => MediaRecorder.isTypeSupported(type)) ?? ''
}

function voiceFileExtension(mimeType: string): string {
  if (mimeType.includes('mp4')) return 'm4a'
  if (mimeType.includes('ogg')) return 'ogg'
  return 'webm'
}

function openTranscriptionSettings() {
  const botName = currentBot.value?.name || currentBot.value?.id || currentBotId.value
  if (!botName) {
    // Voice is a scope of the Providers settings page now (no flat route).
    void router.push({ name: 'providers', query: { tab: 'voice' } })
    return
  }
  void router.push({
    name: 'bot-detail',
    params: { botName },
    query: { tab: 'general', section: 'multimedia' },
  })
}

async function transcribeVoiceInput(
  blob: Blob,
  mimeType: string,
  modelId: string,
  sourceBotId: string,
  requestVersion: number,
) {
  voiceInputState.value = 'transcribing'
  const file = new File(
    [blob],
    `voice-input.${voiceFileExtension(mimeType)}`,
    { type: mimeType || 'audio/webm' },
  )

  // Cancellable: ✗ aborts this request — without it a hung upstream would
  // hold the transcribing state until the edge times out.
  const controller = new AbortController()
  voiceTranscribeAbort = controller
  try {
    const { data } = await postTranscriptionModelsByIdTest({
      path: { id: modelId },
      body: { file },
      signal: controller.signal,
      throwOnError: true,
    })
    if (voiceRequestVersion !== requestVersion || currentBotId.value !== sourceBotId) return
    const transcript = data?.text?.trim() ?? ''
    if (!transcript) {
      toast.error(t('chat.voiceInput.empty'))
      return
    }
    const draft = inputText.value.trimEnd()
    inputText.value = draft ? `${draft} ${transcript}` : transcript
    // Leave the voice surface BEFORE focusing: the textarea only remounts
    // once the state is idle — focusing first hits a null ref and silently
    // does nothing (the finally would clear the state one tick too late).
    voiceInputState.value = 'idle'
    await nextTick()
    focusTextarea()
  } catch (error) {
    if (voiceRequestVersion !== requestVersion) return
    toast.error(resolveApiErrorMessage(error, t('chat.voiceInput.failed')))
  } finally {
    if (voiceTranscribeAbort === controller) voiceTranscribeAbort = null
    if (voiceRequestVersion === requestVersion) voiceInputState.value = 'idle'
  }
}

function stopVoiceInput() {
  if (voiceRecorder?.state !== 'recording') return
  voiceRecorder.stop()
}

function cancelVoiceInput() {
  voiceRequestVersion += 1
  discardVoiceRecording = true
  voiceTranscribeAbort?.abort()
  voiceTranscribeAbort = null
  if (voiceRecorder?.state === 'recording') {
    voiceRecorder.stop()
  } else {
    voiceRecorder = null
    voiceChunks = []
    releaseVoiceStream()
    stopVoiceMeters()
    voiceInputState.value = 'idle'
  }
}

async function startVoiceInput() {
  const modelId = botSettings.value?.transcription_model_id?.trim() ?? ''
  if (!modelId) {
    toast.info(t('chat.voiceInput.notConfigured'))
    openTranscriptionSettings()
    return
  }
  if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
    toast.error(t('chat.voiceInput.unsupported'))
    return
  }

  const requestVersion = ++voiceRequestVersion
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    })
    if (voiceRequestVersion !== requestVersion) {
      stream.getTracks().forEach(track => track.stop())
      return
    }
    const mimeType = preferredVoiceMimeType()
    // Publish the stream BEFORE constructing the recorder: if the
    // MediaRecorder constructor throws (Safari isTypeSupported/constructor
    // disagree), the catch can only stop tracks through voiceStream.
    voiceStream = stream
    const recorder = mimeType
      ? new MediaRecorder(stream, { mimeType })
      : new MediaRecorder(stream)

    voiceRecorder = recorder
    voiceChunks = []
    discardVoiceRecording = false
    voiceSourceBotId = currentBotId.value ?? ''

    recorder.ondataavailable = (event) => {
      if (event.data.size > 0) voiceChunks.push(event.data)
    }
    recorder.onerror = () => {
      discardVoiceRecording = true
      toast.error(t('chat.voiceInput.failed'))
      if (recorder.state === 'recording') {
        recorder.stop()
      } else {
        voiceRecorder = null
        voiceChunks = []
        releaseVoiceStream()
        stopVoiceMeters()
        voiceInputState.value = 'idle'
      }
    }
    recorder.onstop = () => {
      const chunks = voiceChunks
      const shouldDiscard = discardVoiceRecording || voiceRequestVersion !== requestVersion
      const sourceBotId = voiceSourceBotId
      const recordedType = recorder.mimeType || mimeType || 'audio/webm'
      voiceRecorder = null
      voiceChunks = []
      releaseVoiceStream()
      stopVoiceMeters()
      if (shouldDiscard || !chunks.length) {
        voiceInputState.value = 'idle'
        return
      }
      const audio = new Blob(chunks, { type: recordedType })
      void transcribeVoiceInput(audio, recordedType, modelId, sourceBotId, requestVersion)
    }

    recorder.start()
    startVoiceMeters(stream)
    voiceInputState.value = 'recording'
  } catch (error) {
    if (voiceRequestVersion !== requestVersion) return
    // recorder.start() succeeded but the meter setup threw right after: the
    // recorder is still capturing. Route it through onstop (flagged discard)
    // so it cleans up instead of transcribing behind the error toast.
    if (voiceRecorder?.state === 'recording') {
      discardVoiceRecording = true
      voiceRecorder.stop()
    } else {
      voiceRecorder = null
      voiceChunks = []
    }
    releaseVoiceStream()
    stopVoiceMeters()
    voiceInputState.value = 'idle'
    const denied = error instanceof DOMException
      && (error.name === 'NotAllowedError' || error.name === 'SecurityError')
    toast.error(denied ? t('chat.voiceInput.permissionDenied') : t('chat.voiceInput.failed'))
  }
}

function handleVoiceInput() {
  if (voiceInputState.value === 'recording') {
    stopVoiceInput()
    return
  }
  if (voiceInputState.value === 'idle') void startVoiceInput()
}

watch(currentBotId, cancelVoiceInput)
onBeforeUnmount(cancelVoiceInput)

const stopAuthSessionCleanup = onAuthSessionCleared(() => {
  cancelAttachmentUpload()
  clearAllDrafts()
  inputText.value = ''
  pendingFiles.value = []
  pendingNativeAttachments.value = []
  composerError.value = ''
})
const { inputDraftKey, saveInputDraft, clearAllDrafts } = useComposerDrafts({
  currentBotId,
  tabId: () => props.tabId,
  inputText,
})
// A pending batch belongs to its original Bot/session and File selection.
// Switching target, removing a file, or dropping another cancels that send.
watch(
  () => [paneTarget.value.botId, paneTarget.value.sessionId, paneTarget.value.viewId],
  cancelAttachmentUpload,
  { flush: 'sync' },
)
watch(() => pendingFiles.value.slice(), cancelAttachmentUpload, { flush: 'sync' })
watch(() => pendingNativeAttachments.value.slice(), cancelAttachmentUpload, { flush: 'sync' })
// Registered after useComposerDrafts so its draft restore runs first and
// cannot overwrite a prefilled prompt (usage examples, App "Try it").
const replaceDraftConfirm = useAsyncConfirm()
const { lastPrefilled } = useComposerPrefillConsumer({
  botId: () => paneTarget.value.botId,
  active: () => isActive.value,
  writable: () => !activeChatReadOnly.value,
  ready: () => !loadingChats.value,
  currentText: () => inputText.value,
  // Focus the composer first: the dialog returns focus to whatever held it
  // when it opened, so this keeps the caret in the composer either way.
  confirmReplace: () => {
    focusTextarea()
    return replaceDraftConfirm.ask()
  },
  apply: (text) => {
    inputText.value = text
    saveInputDraft(inputDraftKey.value, text)
    void nextTick(focusTextarea)
  },
})

// The welcome composer holds no text of the user's own: it is empty, or still
// exactly what a prefill last wrote. Only then may a suggestion preview into it
// and Enter pick one, since replacing it loses nothing. A first send in flight
// keeps its text locked in the composer, so nothing may replace it then.
const composerReplaceable = computed(() =>
  isWelcome.value && voiceInputState.value === 'idle' && !firstSendAwaiting.value
  && (inputText.value === '' || inputText.value === lastPrefilled.value))
// A welcome suggestion previews its prompt in the composer while it is hovered
// or focused (chat-example-suggestions.vue owns the value).
const composerPreview = ref<ComposerPreview | null>(null)
const composerPreviewShown = computed(() => !!composerPreview.value && composerReplaceable.value)
const composerPreviewBox = useComposerPreviewBox(textareaEl, () => composerPreviewShown.value)

// The dock owns ALL geometry/visibility orchestration (box-slot mutex,
// backdrop-mask height) — the pane only needs two readings back from it: the
// mask height for the full-width backdrop strip, and the dock's own height
// for the message column's bottom padding (so the last message can always
// scroll clear of whatever the dock currently shows — the static pb-28 this
// replaces only ever fit the bare composer).
const dockEl = useTemplateRef<InstanceType<typeof ComposerDock>>('dockEl')
const { height: dockHeight } = useElementSize(() => dockEl.value?.$el ?? null)
const dockMaskHeight = computed(() => dockEl.value?.maskHeight ?? `${COMPOSER_MASK_BELOW_PX}px`)

// Virtual-keyboard lift (iOS Safari; Android lifts via the resized layout
// viewport instead — see useVirtualKeyboard). The whole dock container rises
// by the keyboard height, and the message column's bottom padding grows by
// the same amount so follow-mode keeps the last message clear of the lifted
// composer. While the model picker is open its search field may itself hold
// focus: lifting then would yank the trigger out from under the popover and
// fight iOS's own scroll-to-caret, so the lift is suppressed until the picker
// closes (the plus menu has no focusable input and never hits this).
const virtualKeyboardHeight = useVirtualKeyboard()
const composerLiftPx = computed(() => (modelPopoverOpen.value ? 0 : virtualKeyboardHeight.value))
const messagesBottomPad = computed(() => `${dockHeight.value + COMPOSER_MASK_BELOW_PX + 24 + composerLiftPx.value}px`)

// The textarea belongs to the pane, so when the dock hands the input slot
// back after ask_user is resolved or canceled, it emits and we focus here.
function handleDockRevealComposer(opts: { focus?: boolean }) {
  if (opts.focus) void nextTick(focusTextarea)
}

watch([
  startupSendFailure,
  paneTarget,
  isVisible,
], ([failure]) => {
  if (!failure || !isVisible.value) return
  if (failure.botId && failure.botId !== paneTarget.value.botId) return
  const failureScope = failure.composerScope?.trim()
  const paneScope = inputDraftKey.value || 'chat'
  const renderedSessionId = paneTarget.value.sessionId ?? ''
  if (failureScope) {
    if (failureScope !== paneScope) return
    if (failure.sessionId) {
      if (renderedSessionId !== failure.sessionId) return
    } else if (renderedSessionId) return
  } else {
    if (failure.sessionId && failure.sessionId !== renderedSessionId) return
  }

  inputText.value = failure.restoreInput
  saveInputDraft(inputDraftKey.value, failure.restoreInput)
  pendingFiles.value = (failure.restoreAttachments ?? [])
    .map(attachmentToFile)
    .filter((file): file is File => file !== null)
  requestedSkills.value = skillSlashEnabled.value
    ? (failure.restoreRequestedSkills ?? []).map(skill => ({ ...skill }))
    : []
  setComposerFailure({ ...failure, error: failure.error ?? t('chat.sendFailed') })
  chatStore.clearStartupSendFailure(failure.id)
}, { immediate: true })

const elNode = useTemplateRef('scrollContainer')
// Resolve the real scrollable viewport via data-slot to avoid coupling to the
// child-index DOM shape of @felinic/ui's ScrollArea (which wraps reka-ui).
const scrollEl = computed<HTMLElement | null>(() => {
  const root = elNode.value?.$el as HTMLElement | undefined
  if (!root) return null
  return root.querySelector('[data-slot="scroll-area-viewport"]') as HTMLElement | null
})
const descEl = computed<HTMLElement | null>(() => {
  return (scrollEl.value?.firstElementChild as HTMLElement | null) ?? null
})
const loadMoreSentinel = useTemplateRef<HTMLElement>('loadMoreSentinel')

// The last turn's container. A function ref because template refs inside
// v-for collect into arrays — bind just the pinnable (last) turn by hand.
const lastTurnEl = ref<HTMLElement | null>(null)
function setLastTurnEl(el: unknown) {
  lastTurnEl.value = el as HTMLElement | null
}

// The message list rendered as TURNS: a user message opens a turn that holds
// everything up to the next user message (leading assistant/system rows before
// the first user message form their own head turn). Keyed by the opening
// message's id, which never changes for a given turn — so sending a new
// message APPENDS a fresh container and no previous turn's DOM is ever
// re-parented. This is load-bearing for scroll stability: re-parenting (the
// earlier "split at the last prompt into two chunks" design) remounts the
// whole previous turn on every send — markdown re-renders, code re-highlights
// async, expanded tool groups collapse — and the transient height collapse
// showed up as a hard scroll jump when sending from the bottom.
// `start` is each turn's offset into the flat list, for the fork-source
// dividers whose positions are flat-list indexes.
const messageTurns = computed(() => {
  const turns: { id: string, start: number, messages: ChatMessage[] }[] = []
  messages.value.forEach((msg, index) => {
    const last = turns[turns.length - 1]
    if (msg.role === 'user' || !last) {
      turns.push({ id: msg.id, start: index, messages: [msg] })
    } else {
      last.messages.push(msg)
    }
  })
  return turns
})
const lastMessageId = computed(() => messages.value[messages.value.length - 1]?.id ?? '')

const {
  isScrolling,
  highlightedMessageId,
  lockScroll,
  showJumpToBottom: showJumpToBottomFromScroll,
  scrollToBottom,
  scrollToMessage,
  suppressAutoScrollForPrepend,
  markEscaped,
  pinAfterSend,
  pinAfterSteer,
  pinAfterFollowUp,
  onActivatedRestoreScroll,
  onDeactivatedResetScroll,
  onMessageActive,
  startSmoothScroll,
  findMessageElement,
  messageJumpTarget,
  turnReserveStyle,
} = useChatScroll({
  scrollEl,
  contentEl: descEl,
  lastTurnEl,
  messages,
  isActive: isVisible,
  sessionId: computed(() => paneTarget.value.sessionId ?? `draft:${paneTarget.value.viewId}`),
})

const taskRunAnchor = useTaskRunAnchor({
  anchor: () => props.taskAnchor,
  session: () => props.sessionId,
  visible: () => isVisible.value,
  messages: () => messages.value,
  loading: () => loadingMessages.value,
  loadingOlder: () => loadingOlder.value,
  hasMore: () => hasMoreOlder.value,
  validate: anchor => revalidateTaskHistoryAnchor(anchor, currentBotId.value ?? '', props.sessionId ?? ''),
  loadOlder: () => chatStore.loadOlderMessages(paneTarget.value),
  scroll: scrollToMessage,
})

const readAloud = useChatReadAloud({
  botId: currentBotId,
  scope: computed(() => `${currentBotId.value}:${paneTarget.value.sessionId ?? paneTarget.value.viewId}`),
  enabled: computed(() => !!botSettings.value?.tts_model_id && isActive.value && isVisible.value
    && !chatStore.contactNavigationPending
    && (!props.taskAnchor || taskRunAnchor.status.value === 'located')
    && (router.currentRoute.value.name === 'home' || router.currentRoute.value.name === 'bot')),
  loading: computed(() => loadingMessages.value || loadingChats.value),
  draft: inputText,
  messages,
})

useQueueTurnAnchors(messages, pinAfterSteer, pinAfterFollowUp)
const showJumpToBottom = computed(() => showJumpToBottomFromScroll.value && !loadingChats.value)

// Rail navigation parks the reader on a chosen turn, so escape follow —
// otherwise the next streamed mutation would drag them back to the bottom.
// Landing uses the same rule as pin/entry/reply jumps (messageJumpTarget):
// the chosen turn arrives at the pin offset, identical to how it looked
// right after being sent.
function handleRailJump(seg: ScrollRailSegment) {
  void nextTick(() => {
    const root = scrollEl.value
    const target = findMessageElement(seg.id)
    if (!root || !target) return
    markEscaped()
    startSmoothScroll(root, () => messageJumpTarget(root, seg.id))
  })
}

onBeforeUnmount(() => {
  stopAuthSessionCleanup()
})

// Sentinel-based infinite scroll for older history. Position preservation
// across the prepend itself is owned by useChatScroll (see
// suppressAutoScrollForPrepend's doc comment for why no manual scrollTop
// correction is needed).
async function ensureOlderLoaded() {
  if (loadingOlder.value || !hasMoreOlder.value) return
  if (!messages.value.length) return
  suppressAutoScrollForPrepend()
  try {
    await chatStore.loadOlderMessages(paneTarget.value)
  } catch (error) {
    console.error('Failed to load older messages:', error)
  }
}

useIntersectionObserver(
  loadMoreSentinel,
  ([entry]) => {
    if (!isVisible.value) return
    if (!entry?.isIntersecting) return
    void ensureOlderLoaded()
  },
  {
    root: scrollEl,
    rootMargin: '200px 0px 0px 0px',
    threshold: 0,
  },
)

onActivated(() => {
  if (props.taskAnchor) {
    // The authorized execution anchor owns restoration in a task pane.
    // A remembered arbitrary position must not override its async scroll.
    lockScroll.value = false
    markEscaped()
  } else {
    onActivatedRestoreScroll(loadingMessages)
  }
})

onDeactivated(() => {
  cancelAttachmentUpload()
  onDeactivatedResetScroll()
})

async function handleReplyJump(messageId: string) {
  const target = messageId.trim()
  if (!target) return
  const localId = chatStore.findMessageIdByExternalId(target, paneTarget.value)
  if (localId && await scrollToMessage(localId)) return
  const locatedId = await chatStore.locateMessageByExternalId(target, paneTarget.value)
  if (locatedId) {
    await scrollToMessage(locatedId)
  }
}

async function handleForkSourceClick() {
  const source = forkSource.value
  const botId = currentBotId.value?.trim() ?? ''
  if (!source || !botId || openingForkSource.value) return
  const origin = { ...paneTarget.value }
  openingForkSource.value = true
  try {
    await fetchSession(botId, source.sessionId)
    workspaceTabs.openSessionChatFromView({
      viewId: origin.viewId,
      sessionId: source.sessionId,
      title: source.title,
      expectedSessionId: origin.sessionId,
      explicitSelection: true,
    })
  } catch {
    toast.error(t('chat.forkSourceUnavailable'))
  } finally {
    openingForkSource.value = false
  }
}

function handleForkMessage(turnId: string) {
  composerError.value = ''
  const id = turnId.trim()
  if (!id) return
  pendingForkTurnId.value = id
  forkDialogOpen.value = true
}

// Keyboard bridges into the two composer list surfaces (slash picker, command
// panel results). The composer textarea keeps focus the whole time — like
// reka's ListboxFilter, the bridge runs the listbox in virtual-highlight mode
// and the textarea forwards navigation keys to whichever surface is showing.
const slashPickerBridge = ref<InstanceType<typeof CommandKeyBridge> | null>(null)

function activeComposerListBridge() {
  if (slashPanelOpen.value && slashPanelHasResults.value) return slashPickerBridge.value
  if (commandPanelEvent.value && commandResultItems.value.length) return dockEl.value?.commandBridge ?? null
  return null
}

// The composer card's own padding/gaps are plain background, not covered by
// any child — @click.self missed them whenever a child element's box (even
// its invisible padding) sat on top of the pointer, which is most of the
// card. Focus the textarea for any click that isn't already on something
// interactive (button, link, form control, or a [role="button"] custom
// trigger like the model/agent pills) — mirrors a plain text field, where
// clicking anywhere in its box places the caret.
const COMPOSER_INTERACTIVE_SELECTOR = 'button, a, input, [role="button"], [contenteditable="true"]'
function handleComposerClick(e: MouseEvent) {
  const target = e.target as HTMLElement
  if (target.closest(COMPOSER_INTERACTIVE_SELECTOR)) return
  focusTextarea()
}

function handleComposerKeydown(e: KeyboardEvent) {
  if (e.isComposing || e.keyCode === 229) return
  if (e.key === 'Escape') {
    // Dismiss the command result panel; the slash picker is input-driven and
    // closes by editing the text, so Escape only targets the panel.
    if (!slashPanelOpen.value && commandPanelEvent.value) {
      e.preventDefault()
      clearCurrentCommandEvent()
    }
    return
  }
  const bridge = activeComposerListBridge()
  if (bridge && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
    e.preventDefault()
    bridge.navigate(e)
    return
  }
  if (e.key !== 'Enter' || e.shiftKey || e.ctrlKey || e.metaKey || e.altKey) return
  if (bridge?.hasHighlight) {
    e.preventDefault()
    bridge.select(e)
    return
  }
  e.preventDefault()
  handleSend()
}

async function handleRetryMessage(turnId: string) {
  if (composerConfigPending.value) return
  composerError.value = ''
  const { pair: sendPair, finish: finishPairSend } = composerPair.beginSend()
  const result = await chatStore.retryLatestAssistant(turnId, {
    target: paneTarget.value,
    modelId: sendPair.modelId,
    reasoningEffort: sendPair.reasoningEffort,
    workspaceTargetId: sendWorkspaceTargetId.value,
    onModelPreferenceSettled: () => finishPairSend(false),
  }).finally(() => finishPairSend(false))
  finishPairSend(result.ok || result.stage === 'stream')
  await refreshACPComposerConfigAfterSelectionError(result)
  if (!result.ok && result.error) {
    setComposerFailure(result)
  }
}

async function handleEditMessage(turnId: string, text: string, done?: (started: boolean) => void) {
  if (composerConfigPending.value) {
    done?.(false)
    return
  }
  composerError.value = ''
  const { pair: sendPair, finish: finishPairSend } = composerPair.beginSend()
  try {
    const result = await chatStore.editLatestUser(turnId, text, {
      target: paneTarget.value,
      modelId: sendPair.modelId,
      reasoningEffort: sendPair.reasoningEffort,
      workspaceTargetId: sendWorkspaceTargetId.value,
      onModelPreferenceSettled: () => finishPairSend(false),
    })
    finishPairSend(result.ok || result.stage === 'stream')
    await refreshACPComposerConfigAfterSelectionError(result)
    if (!result.ok && result.error) {
      setComposerFailure(result)
    }
    done?.(result.ok || result.stage === 'stream')
  } catch {
    done?.(false)
  } finally {
    finishPairSend(false)
  }
}

function stopReadAloudForNativeInput(event: PointerEvent) {
  if (event.target instanceof Element && event.target.closest('.harmony-voice-mic')) readAloud.stop()
}
function harmonyVoiceEditorTarget() {
  const resolve = () => {
    const node = textareaEl.value
    if (!node) return
    const rect = node.getBoundingClientRect()
    return { x: rect.x, y: rect.y, width: rect.width, height: rect.height, radius: Number.parseFloat(getComputedStyle(node).borderRadius) || 0 }
  }
  const bounds = resolve()
  return bounds ? { ...bounds, resolve } : undefined
}
function insertHarmonyVoiceText(text: string) {
  const field = textareaEl.value
  if (!field || !text.trim()) return
  const start = field.selectionStart, end = field.selectionEnd
  inputText.value = inputText.value.slice(0, start) + text + inputText.value.slice(end)
  void nextTick(() => field.setSelectionRange(start + text.length, start + text.length))
}
async function handleSend() { return sendComposer() }
async function sendComposer(voice?: VoiceSubmission) {
  if (paneView.value.attachmentPreparation.value) return
  readAloud.stop()
  if (!isActive.value || attachmentUploading.value || nativeAttachmentBusy.value || firstSendAwaiting.value) return
  if (!skillSlashEnabled.value && requestedSkills.value.length) {
    requestedSkills.value = []
  }
  const text = inputText.value.trim()
  const files = [...pendingFiles.value]
  const nativeFiles = [...pendingNativeAttachments.value]
  const attachmentScope = nativeAttachmentScope.value
  const skills = [...requestedSkills.value]
  if (goalSubmissionBlocked.value) {
    composerError.value = goalExecutionBlockedReason.value
    return
  }
  if (localQuickActionIDForSlash(text) === 'goal') {
    if (runtimeModeDisabled.value || localQuickActionBlocked()) return
    goalDraftScope.value = goalDraftEnabled.value ? '' : runtimeModeScope.value
    inputText.value = ''
    saveInputDraft(inputDraftKey.value, '')
    return
  }
  if (localQuickActionIDForSlash(text) === 'plan') {
    if (runtimeModeDisabled.value || localQuickActionBlocked()) return
    inputText.value = ''
    saveInputDraft(inputDraftKey.value, '')
    await togglePlanMode()
    return
  }
  const selector = text.startsWith('/') ? text.slice(1).split(/\s/, 1)[0] : ''
  const runtimeCommand = composerRuntimeCommands.value.find(command => command.name === selector)
  if (runtimeCommand && runtimeCommand.kind !== 'turn') {
    if (activeChatReadOnly.value || loadingMessages.value || localQuickActionBlocked()) return
    if (streaming.value && runtimeCommand.kind === 'operation') {
      composerError.value = t('errors.session_runtime.session_busy')
      return
    }
    if (runtimeCommand.kind === 'operation') {
      clearCurrentCommandEvent()
      composerError.value = ''
      inputText.value = ''
      saveInputDraft(inputDraftKey.value, '')
      await runSessionCompaction(() => runtimeControls.execute(runtimeCommand.name!))
      return
    }
    const draftKey = inputDraftKey.value
    const title = `/${runtimeCommand.name}`
    const complete = chatStore.beginCommandEvent({
      type: 'command_result', terminal: false, action_id: runtimeCommand.name,
      result: { kind: 'runtime_command', title, text: runtimeCommand.running_text, text_key: 'common.loading' },
    }, currentPaneCommandScope())
    inputText.value = ''
    saveInputDraft(draftKey, '')
    try {
      const result = await runtimeControls.execute(runtimeCommand.name!)
      complete({
        type: 'command_result', terminal: true, action_id: runtimeCommand.name,
        result: { kind: 'runtime_command', title, ...(Object.keys(result).length ? result : { text: runtimeCommand.completed_text, text_key: 'common.toast.success' }) },
      })
    } catch (error) {
      complete({ type: 'command_error', terminal: true, code: parseMemohError(error)?.code || 'runtime_control.failed', message: resolveApiErrorMessage(error, t('errors.runtime_control.failed')) })
    }
    return
  }
  const queueCommand = composerQueueCommand.value
  if (queueCommand) {
    if (files.length || nativeFiles.length || skills.length) {
      composerError.value = files.length || nativeFiles.length
        ? t('chat.slash.attachmentsUnsupported')
        : t('errors.slash.skill_syntax_invalid')
      return
    }
    if (!queueCommand.text || !activeSessionId.value) {
      composerError.value = t('errors.queue_request_invalid')
      return
    }
  }
  if (streaming.value || queueCommand) {
    // Until controls load, a slash input may be a runtime command.
    const runtimeCommandUnresolved = activeUsesExternalAgentComposer.value
      && !runtimeControlSnapshot.value
      && text.startsWith('/')
      && !queueCommand
    // The queue carries plain text only: a runtime turn command or a goal
    // draft would run as an ordinary message once dequeued.
    if (runtimeCommand || runtimeCommandUnresolved || (goalDraftEnabled.value && text && !text.startsWith('/'))) {
      composerError.value = t('errors.session_runtime.session_busy')
      return
    }
    if (!text || files.length || nativeFiles.length || skills.length || !currentBotId.value || !activeSessionId.value || activeChatReadOnly.value) return
    const botId = currentBotId.value
    const sessionId = activeSessionId.value
    const mode = queueCommand?.mode ?? 'follow-up'
    const queueText = queueCommand?.text ?? text
    const sentDraftKey = inputDraftKey.value
    const sentContext = captureChatPaneSendContext(
      paneTarget.value,
      inputDraftKey.value || 'chat',
    )
    const submission = queueSubmissionGate.begin({ botId, sessionId, mode, text: queueText })
    if (!submission) return

    composerError.value = ''
    inputText.value = ''
    saveInputDraft(sentDraftKey, '')
    try {
      const enqueue = mode === 'steer' ? enqueueSteerQueue : enqueueFollowUpQueue
      await enqueue(botId, sessionId, queueText, submission.invocationId)
      queueSubmissionGate.succeed(submission)
      queueLocalRefresh.value++
    } catch (error) {
      queueSubmissionGate.fail(submission)
      if (matchesChatPaneSendContext(
        sentContext,
        paneTarget.value,
        inputDraftKey.value || 'chat',
      )) {
        if (!inputText.value.trim()) {
          inputText.value = text
          saveInputDraft(sentDraftKey, text)
        }
        composerError.value = resolveApiErrorMessage(error, t('chat.sendFailed'))
      }
    }
    return
  }
  if (
    (!text && !files.length && !nativeFiles.length && !skills.length && !voice)
    || loadingMessages.value
    || activeChatReadOnly.value
    || composerConfigPending.value
    // Keyboard send bypasses the disabled button, so the no-model gate is
    // repeated here rather than living only on the control.
    || composerHasNoModel.value
    || !!runtimeModeUnavailableReason.value
  ) return
  const localAction = localQuickActionIDForSlash(text)
  if (localAction && localQuickActionBlocked()) return
  if (localAction && runLocalQuickAction(localAction, text)) {
    inputText.value = ''
    saveInputDraft(inputDraftKey.value, '')
    return
  }
  const sentGoalScope = goalDraftScope.value
  const goalSend = goalDraftEnabled.value && !text.startsWith('/')
  const sendText = goalSend ? `/goal ${text}` : text
  if ((goalSend || /^\/goal(?:\s|$)/.test(text)) && (files.length || nativeFiles.length || skills.length)) {
    composerError.value = t('chat.goal.textOnly')
    return
  }
  const isNewCommand = /^\/new(?:\s|$)/i.test(text)
  if (defaultExternalAgentComposerError.value && !hasExplicitSessionSelection.value && !isNewCommand) {
    composerError.value = defaultExternalAgentComposerError.value
    return
  }
  const sentDraftKey = inputDraftKey.value
  const sentContext = captureChatPaneSendContext(
    paneTarget.value,
    inputDraftKey.value || 'chat',
  )
  const sentInput = inputText.value
  const sentField = textareaEl.value
  const sentSelection = sentField ? {
    start: sentField.selectionStart,
    end: sentField.selectionEnd,
    direction: sentField.selectionDirection,
  } : null
  const pairSend = composerPair.captureSend()
  const sentModelId = pairSend.pair.modelId
  const sentReasoningEffort = pairSend.pair.reasoningEffort
  const sentWorkspaceTargetId = sendWorkspaceTargetId.value
  const preserveDirectDraftSelection = activeUsesDirectRuntime.value && !sentContext.target.sessionId
  composerError.value = ''
  // A draft's first send keeps its input on screen, locked, until the server
  // confirms it (onBeforeTurnAppend); a failure then leaves it where it is.
  const holdsInput = !sentContext.target.sessionId
  const clearSentInput = (onSentPane = true) => {
    saveInputDraft(sentDraftKey, '')
    if (!onSentPane) return
    inputText.value = ''
    pendingFiles.value = []
    pendingNativeAttachments.value = []
    requestedSkills.value = []
  }
  if (holdsInput) draftSendStarting.value = true

  attachmentPreparationCancelled = false
  preparingView = paneView.value
  const nativeSubmission = prepareSubmission(sentContext.target.botId, files, voice, { scope: attachmentScope, files: nativeFiles })
  const attachments = nativeSubmission.attachments

  // Arm the pin only once the store has passed command handling and session
  // setup and is about to start a real turn. Command-only sends therefore do
  // not leave a latent pin behind; startup failures roll the arm back.
  let rollbackPin: (() => void) | null = null
  directDraftPromotionPending = preserveDirectDraftSelection
  const result = await chatStore.sendMessage(sendText, attachments, {
    prepareAttachments: nativeSubmission.prepareAttachments,
    target: sentContext.target,
    modelId: sentModelId,
    reasoningEffort: sentReasoningEffort,
    workspaceTargetId: sentWorkspaceTargetId,
    requestedSkills: skills,
    composerScope: sentContext.composerScope,
    onBeforeMessageSend: () => pairSend.begin(),
    onModelPreferenceSettled: () => pairSend.finish(false),
    onBeforeTurnAppend: (target) => {
      // The confirmed target carries the session the send created; a draft
      // pane that was promoted to it is still the pane that sent.
      const onSentPane = matchesChatPaneSendContext(
        { ...sentContext, target },
        { ...paneTarget.value, sessionId: paneView.value.sessionId },
        inputDraftKey.value || 'chat',
      )
      clearSentInput(onSentPane)
      if (holdsInput) {
        draftSendStarting.value = false
      }
      if (goalSend && goalDraftScope.value === sentGoalScope) goalDraftScope.value = ''
      if (preserveDirectDraftSelection) {
        void nextTick(() => { directDraftPromotionPending = false })
      }
      if (!onSentPane) return
      rollbackPin = pinAfterSend()
    },
    onTurnAppendAborted: () => {
      rollbackPin?.()
      rollbackPin = null
    },
  }).finally(() => {
    draftSendStarting.value = false
    directDraftPromotionPending = false
    pairSend.finish(false)
    pairSend.releaseReads()
  })
  rollbackPin = null
  if (result.messageSent === true) await nativeSubmission.consumeNative()
  pairSend.finish(result.messageSent === true || result.stage === 'stream')
  await refreshACPComposerConfigAfterSelectionError(result)
  const restore = composerRestoreForSendResult(result, text, t('chat.sendFailed'))
  if (restore) {
    // Selection/lifecycle cancellation leaves the live composer untouched.
    if (attachmentPreparationCancelled) return
    if (!matchesChatPaneSendContext(
      sentContext,
      paneTarget.value,
      inputDraftKey.value || 'chat',
    )) return
    inputText.value = sentInput
    saveInputDraft(sentDraftKey, sentInput)
    pendingFiles.value = nativeSubmission.files
    pendingNativeAttachments.value = nativeSubmission.nativeFiles
    requestedSkills.value = skills
    if (commandPanelEvent.value?.type !== 'command_error') {
      composerError.value = restore.error
    }
    await nextTick()
    if (sentSelection && inputText.value === sentInput
      && matchesChatPaneSendContext(sentContext, paneTarget.value, inputDraftKey.value || 'chat')) {
      textareaEl.value?.setSelectionRange(sentSelection.start, sentSelection.end, sentSelection.direction)
    }
    return
  }
  // The draft is consumed only here: a welcome send succeeded, so the pair
  // now lives server-side (spec P2′). Clearing any earlier — e.g. on a
  // welcome→session repoint — would wipe an unsent pick when the user merely
  // opens a historical session; a failed send keeps the draft for the retry.
  if (welcomeSendConsumedDraft(sentContext.target, result)) {
    clearComposerPairDraft(sentContext.target.botId)
  }
}

let lastSendButtonActivation = -Infinity
function handleSendButton(event?: MouseEvent) {
  if (paneView.value.attachmentPreparation.value && !showSend.value) {
    paneView.value.attachmentPreparation.value.abort()
    return
  }
  // A first send waits for the server to confirm it.
  if (firstSendAwaiting.value) return
  const now = performance.now()
  if ((event?.detail ?? 0) > 1) return
  if (streaming.value && !showSend.value) {
    // Clearing a sent draft changes this same button into stop. Keep mouse
    // multi-clicks, rapid taps and keyboard repeats in that send gesture.
    if (now - lastSendButtonActivation < 500) {
      lastSendButtonActivation = now
      return
    }
    chatStore.abort(paneTarget.value)
    return
  }
  lastSendButtonActivation = now
  void handleSend()
}

</script>
