import type { BotsBot } from '@memohai/sdk'

export type Bot = BotsBot

export interface SessionSummary {
  id: string
  bot_id: string
  bot_agent_id?: string
  route_id?: string
  channel_type?: string
  type?: string
  session_mode?: string
  runtime_type?: string
  title: string
  metadata?: Record<string, unknown>
  runtime_metadata?: Record<string, unknown>
  parent_session_id?: string
  /** Immutable bot-workdir binding; empty for unbound sessions. */
  workdir_id?: string
  created_at?: string
  updated_at?: string
  route_metadata?: Record<string, unknown>
  route_conversation_type?: string
  /** Session's persisted (model, effort) pair (issue #879); empty = no memory. */
  preferred_external_model_id?: string
  model_preference_revision?: string
  preferred_chat_model_id?: string
  preferred_reasoning_effort?: string
}

// Bot-wide activity SSE: `/bots/{bot_id}/sessions/events`. Carries identifier
// + minimal metadata for sidebar live-sort; never includes message bodies.
export interface SessionTouchedEvent {
  type: 'session_touched'
  session_id: string
  updated_at?: string
  /** A persisted background notification may arrive without a live turn. */
  reason?: 'background_task'
}

export interface SessionTitleChangedEvent {
  type: 'session_title_changed'
  session_id: string
  title: string
}

export interface SessionCreatedEvent {
  type: 'session_created'
  session_id: string
  // `type` here is the session kind (chat | discuss | schedule | acp_agent),
  // already filtered server-side to user-visible sessions.
  session_type?: string
  title?: string
}

export interface ScheduleChangedEvent {
  type: 'schedule_changed'
  schedule_id: string
  /** Kept empty by the server for compatibility with older activity clients. */
  session_id?: string
}

export interface BotSessionActivityDroppedEvent {
  type: 'dropped'
  count?: number
}

export interface BotSessionActivityPingEvent {
  type: 'ping'
}

export interface SessionCompactionEvent {
  type: 'session_compaction'
  /** Complete, permission-filtered set of sessions currently compacting. */
  session_ids: string[]
}

export type BotSessionActivityEvent =
  | { type: 'activity_ready', cache_invalidation: boolean }
  | { type: 'session_invalidated', session_id: string }
  | SessionTouchedEvent
  | SessionTitleChangedEvent
  | SessionCreatedEvent
  | ScheduleChangedEvent
  | BotSessionActivityDroppedEvent
  | BotSessionActivityPingEvent
  | SessionCompactionEvent

export interface FetchMessagesOptions {
  limit?: number
  before?: string
  beforeMessageId?: string
  session_id?: string
}

export interface ChatAttachment {
  type: string
  base64?: string
  content_hash?: string
  mime?: string
  name?: string
  size?: number
}

export interface RequestedSkillSelection {
  name: string
  display_name?: string
  description?: string
  source_kind?: string
  state?: string
}

export interface RequestedSkillRequest {
  name: string
}

export interface CommandActionListItem {
  i18n_key?: string
  id?: string
  title: string
  description?: string
  kind?: string
}

export interface CommandActionResult {
  data?: unknown
  notice?: string
  text_key?: string
  kind: string
  title?: string
  text?: string
  items?: CommandActionListItem[]
}

export interface CommandEventResponse {
  type: 'command_result' | 'command_error'
  invocation_id?: string
  composer_scope?: string
  session_id?: string
  action_id?: string
  terminal: boolean
  result?: CommandActionResult
  // A command_error's catalog or slash-command code, and the server's text.
  code?: string
  message?: string
}

export interface UIAttachment {
  id?: string
  type: string
  path?: string
  url?: string
  base64?: string
  name?: string
  content_hash?: string
  bot_id?: string
  mime?: string
  size?: number
  storage_key?: string
  metadata?: Record<string, unknown>
}

export interface UIReplyRef {
  message_id?: string
  sender?: string
  preview?: string
  attachments?: UIAttachment[]
}

export interface UIForwardRef {
  message_id?: string
  from_user_id?: string
  from_conversation_id?: string
  sender?: string
  date?: number
}

export interface UITextMessage {
  id: number
  type: 'text'
  content: string
}

export interface UIReasoningMessage {
  id: number
  type: 'reasoning'
  content: string
  reasoning_timing?: UIReasoningTiming
}

export interface UIReasoningTiming {
  duration_ms: number
}

export interface UIToolMessage {
  id: number
  type: 'tool'
  name: string
  input: unknown
  output?: unknown
  tool_call_id: string
  running: boolean
  progress?: unknown[]
  /** Last elapsed time reported by the executing runtime. */
  elapsed_time_seconds?: number
  approval?: UIToolApproval
  execution_location?: UIExecutionLocation
  user_input?: UIUserInput
  background_task?: UIBackgroundTask
  // UI-only unified diff attached to the tool call at execution time
  // (edit/write tools). Never part of the model-facing tool result.
  diff?: string
}

export interface UIExecutionLocation {
  kind: string
  name: string
}

export interface UIBackgroundTask {
  event?: string
  task_id?: string
  bot_id?: string
  session_id?: string
  command?: string
  agent_id?: string
  agent_session_id?: string
  status?: string
  stream?: string
  chunk?: string
  tail?: string
  output_file?: string
  output_tail?: string
  exit_code?: number
  duration?: string
  stalled?: boolean
}

/** One agent-provided answer to a permission request, preserved verbatim. */
export interface UIToolApprovalOption {
  id: string
  name?: string
  kind?: 'allow_once' | 'allow_always' | 'reject_once' | 'reject_always' | (string & {})
}

export interface UIToolApproval {
  approval_id: string
  short_id?: number
  status: string
  decision_reason?: string
  can_approve?: boolean
  options?: UIToolApprovalOption[]
  selected_option_id?: string
}

export interface UIUserInput {
  user_input_id: string
  short_id?: number
  status: string
  questions?: UIUserInputQuestion[]
  answers?: UIUserInputAnswer[]
  can_respond?: boolean
}

export interface UIUserInputAnswer {
  question_id: string
  question: string
  selected?: UIUserInputOption[]
  custom_text?: string
  text?: string
  skipped?: boolean
}

export interface UIUserInputQuestion {
  id: string
  text: string
  kind: 'single_select' | 'multi_select' | 'text'
  options?: UIUserInputOption[]
  allow_custom?: boolean
  custom_exclusive?: boolean
  required?: boolean
  placeholder?: string
}

export interface UIUserInputOption {
  label_key?: string
  id: string
  label: string
  description?: string
}

export interface UIAttachmentsMessage {
  id: number
  type: 'attachments'
  attachments: UIAttachment[]
}

export interface UIErrorMessage {
  id: number
  type: 'error'
  code?: string
  content: string
  // Machine-readable parameters of the feedback behind `code` (e.g. dep_id,
  // required_version, install_task_id for agent_dependency_missing).
  args?: Record<string, string>
}

// Runtime degradation notice (tools unavailable, an interaction declined).
// `name` carries the machine code, `content` the human-readable text.
export interface UINoticeMessage {
  id: number
  type: 'notice'
  name?: string
  content: string
  // Machine-readable parameters of the notice (the runtime_notice event's
  // string metadata), for renderers that act on a specific `name`.
  args?: Record<string, string>
}

export interface UICommandMessage {
  id: number
  type: 'command'
  name?: string
  content: string
}

export interface UIStatusMessage {
  id: number
  type: 'status'
  name?: string
  args?: Record<string, string>
}

export type UIMessage = UITextMessage | UIReasoningMessage | UIToolMessage | UIAttachmentsMessage | UIErrorMessage | UINoticeMessage | UICommandMessage | UIStatusMessage

export interface UISkillActivationSkill {
  name: string
  display_name?: string
  description?: string
  source_kind?: string
  state?: string
}

export interface UISkillActivation {
  skills?: UISkillActivationSkill[]
  prompt?: string
}

export interface UIUserTurn {
  turn_id: string
  // Immutable turn-level sequence reserved at admission. Present on both the
  // settled (REST history) path and live runtime frames: the runtime stamps
  // the position it allocated onto the run's request turn, and a steer's turn
  // arrives already numbered from history once its step commits.
  turn_position?: number
  role: 'user'
  text: string
  user_message_kind?: string
  skill_activation?: UISkillActivation
  attachments?: UIAttachment[]
  reply?: UIReplyRef
  forward?: UIForwardRef
  timestamp: string
  platform?: string
  sender_display_name?: string
  sender_avatar_url?: string
  sender_user_id?: string
  external_message_id?: string
  id?: string
}

export interface UIAssistantTurn {
  runtime_forkable?: boolean
  turn_id: string
  turn_position?: number
  role: 'assistant'
  messages: UIMessage[]
  timestamp: string
  platform?: string
  external_message_id?: string
  id?: string
}

export interface UISystemTurn {
  turn_id: string
  turn_position?: number
  role: 'system'
  kind?: 'background_task' | string
  background_task?: UIBackgroundTask
  timestamp: string
  platform?: string
  id?: string
}

export type UITurn = UIUserTurn | UIAssistantTurn | UISystemTurn

// Turn events are named by the server's run_id. Events that precede the run —
// acceptance, rejection, session creation, and validation errors — are named by
// the invocation_id the client sent, since that is the only name shared yet.
export interface UIStreamRunAcceptedEvent {
  type: 'run_accepted'
  run_id: string
  invocation_id: string
  session_id: string
  turn_id: string
  // The sequence admission drew for turn_id. Carried with the id so a locally
  // rendered turn is ordered by the same key the settled page will use, rather
  // than by when it happened to arrive.
  turn_position?: number
  // A replay reserved no new observable position; its subscription snapshot is
  // authoritative, so duplicate acceptances may omit the cursor.
  epoch?: string
  seq?: number
  // Set when this acceptance names a run the invocation had already started,
  // which is how a redelivered send avoids producing a second turn.
  duplicate?: boolean
}

export interface UIStreamRunRejectedEvent {
  type: 'run_rejected'
  invocation_id: string
  session_id: string
  code: string
  message: string
}

export interface UIStreamErrorEvent {
  type: 'error'
  run_id?: string
  invocation_id?: string
  session_id?: string
  code?: string
  message: string
  args?: Record<string, string>
}

export interface UIStreamSessionCreatedEvent {
  type: 'session_created'
  invocation_id: string
  session_id: string
  /** The workdir the session was actually born bound to; absent when it has
   *  none. A backend that predates in-band workdir binding never sends it. */
  workdir_id?: string
}

export type RuntimeRunStatus =
  | 'admitting'
  | 'running'
  | 'waiting_decision'
  | 'aborting'
  | 'finishing'
  | 'completed'
  | 'aborted'
  | 'errored'
  | 'lost'

export interface RuntimeCursor {
  epoch: string
  seq: number
}


export interface RuntimeRunOperation {
  kind: 'retry' | 'edit'
  replace_from_message_id: string
  replacement_user_turn?: UIUserTurn
}

export interface RuntimeCurrentRunView {
  configuration_only?: boolean
  run_id: string
  turn_id: string
  // Immutable sequence of turn_id, allocated at admission. Present on every
  // live frame so a running turn orders against settled history by position
  // instead of falling back to timestamps.
  turn_position?: number
  // The originating send's client-issued id, echoed so live frames can be
  // matched to the local optimistic turn by reading, not by timing inference.
  invocation_id?: string
  generation: string
  status: RuntimeRunStatus
  owner_id?: string
  owner_lease_expires_at?: string
  started_at: string
  updated_at: string
  messages: UIMessage[]
  request_user_turn?: UIUserTurn
  // Ordered inputs already admitted into this run. The first entry is the
  // request turn when present; later entries are applied steers.
  user_turns?: UIUserTurn[]
  // Live steer claims projected at their exact assistant-message
  // boundary. Claimed entries are provisional; applied entries reference the
  // settled history turn that replaces them.
  steer_turns?: RuntimeSteerTurnView[]
  // The catalog code of the run's failure. The run view carries no error text;
  // the client shows the copy for the code.
  error_code?: string
  proposed_terminal_status?: RuntimeRunStatus
  finish_proposed_at?: string
  operation?: RuntimeRunOperation
  // Present while the model call waits to be retried; cleared by the next
  // visible output or when the run leaves execution.
  retry?: RuntimeRunRetry
}

export type RuntimeRetryReason = 'rate_limited' | 'server_error' | 'stream_incomplete' | 'network'

export interface RuntimeRunRetry {
  attempt: number
  max_attempt: number
  delay_ms: number
  reason?: RuntimeRetryReason
  // Server time the next attempt is planned for, for countdowns.
  retry_at: string
}

export interface RuntimeSteerTurnView {
  item_id: string
  status: 'claimed' | 'applied'
  text: string
  // The durable turn this input opens, drawn when it was claimed. Present from
  // the first claimed frame, so the live bubble and the settled one share an
  // identity instead of rendering side by side until the step commits.
  turn_id?: string
  turn_position?: number
  after_message_id: number
  timestamp: string
}

export interface RuntimeSnapshot {
  bot_id: string
  session_id: string
  epoch: string
  seq: number
  current_run_view?: RuntimeCurrentRunView
  updated_at: string
}

export interface RuntimeCurrentRunPatch {
  run_id: string
  status?: RuntimeRunStatus
  error_code?: string
  updated_at?: string
  owner_lease_expires_at?: string
  // retry replaces the run's retry state, clear_retry removes it; with
  // neither the state is unchanged.
  retry?: RuntimeRunRetry
  clear_retry?: boolean
}

export interface RuntimeMessageAppend {
  id: number
  type: 'text' | 'reasoning'
  content: string
}

export interface RuntimeProgressAppend {
  id: number
  progress: unknown
  input?: unknown
}

export interface RuntimeDelta {
  current_run_view?: RuntimeCurrentRunView
  run?: RuntimeCurrentRunPatch
  user_turn_upserts?: UIUserTurn[]
  steer_turn_upserts?: RuntimeSteerTurnView[]
  steer_turn_removals?: string[]
  message_appends?: RuntimeMessageAppend[]
  progress_appends?: RuntimeProgressAppend[]
  message_upserts?: UIMessage[]
  reset_messages?: boolean
}

export interface UIRuntimeSnapshotEvent {
  type: 'runtime_snapshot'
  session_id: string
  epoch: string
  seq: number
  snapshot: RuntimeSnapshot
}

export interface UIRuntimeDeltaEvent {
  type: 'runtime_delta'
  session_id: string
  epoch: string
  seq: number
  delta: RuntimeDelta
}

export interface UIRuntimeDroppedEvent {
  type: 'runtime_dropped'
  session_id: string
  epoch: string
  seq: number
  message?: string
}

export interface UIControlAckEvent {
  type: 'control_ack'
  session_id: string
  run_id: string
  control: 'abort' | 'tool_approval_response' | 'user_input_response'
  control_id: string
  applied: boolean
  code?: string
}

export type UIRuntimeEvent =
  | UIRuntimeSnapshotEvent
  | UIRuntimeDeltaEvent
  | UIRuntimeDroppedEvent

export interface UIStreamModelPreferenceSettledEvent {
  type: 'model_preference_settled'
  invocation_id: string
  run_id: string
  session_id: string
}

export type UIStreamEvent =
  | UIStreamModelPreferenceSettledEvent
  | UIStreamRunAcceptedEvent
  | UIStreamRunRejectedEvent
  | UIStreamErrorEvent
  | UIStreamSessionCreatedEvent
  | UIRuntimeEvent
  | UIControlAckEvent
  | CommandEventResponse

export type UIStreamEventHandler = (event: UIStreamEvent) => void
